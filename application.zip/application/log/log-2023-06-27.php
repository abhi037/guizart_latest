<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-27 07:18:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 10:09:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 10:09:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 12:13:47 --> 404 Page Not Found: Git/config
ERROR - 2023-06-27 12:14:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 14:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:42 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-27 14:30:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-27 14:31:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-27 14:31:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-27 15:09:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 15:09:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 19:33:58 --> 404 Page Not Found: Git/config
ERROR - 2023-06-27 19:44:38 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-06-27 20:43:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 20:44:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 20:45:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 20:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-27 20:45:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-27 21:58:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
