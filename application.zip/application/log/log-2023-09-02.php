<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-02 00:27:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 00:57:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 00:57:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 01:17:05 --> 404 Page Not Found: Env/index
ERROR - 2023-09-02 01:17:05 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-02 02:04:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 02:21:42 --> 404 Page Not Found: Env/index
ERROR - 2023-09-02 02:21:44 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-02 02:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 02:22:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 02:29:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 02:29:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 02:29:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 02:32:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 02:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 02:32:35 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-02 02:32:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 03:38:58 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-02 03:44:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 03:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 04:13:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 04:13:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 04:14:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 05:04:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:04:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:09:35 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-09-02 05:09:39 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-09-02 05:09:42 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-09-02 05:09:46 --> 404 Page Not Found: Xl2023xphp/index
ERROR - 2023-09-02 05:09:52 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-02 05:09:57 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-09-02 05:10:02 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-09-02 05:10:06 --> 404 Page Not Found: Images/iR7SzrsOUEP.php
ERROR - 2023-09-02 05:10:12 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-02 05:10:17 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-02 05:10:23 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-02 05:10:26 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-02 05:10:33 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-09-02 05:10:37 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2023-09-02 05:10:42 --> 404 Page Not Found: Admin-headephp/index
ERROR - 2023-09-02 05:10:45 --> 404 Page Not Found: Cgi-bin/iR7SzrsOUEP.php
ERROR - 2023-09-02 05:10:51 --> 404 Page Not Found: Wp-content/xl2023.php
ERROR - 2023-09-02 05:10:54 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-02 05:11:04 --> 404 Page Not Found: IR7SzrsOUEPphp/index
ERROR - 2023-09-02 05:11:08 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-02 05:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 05:13:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:13:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 05:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 05:25:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:25:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 05:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 05:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:33:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 05:39:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:47:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:47:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 05:47:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 05:47:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 05:48:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:48:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:48:10 --> 404 Page Not Found: Home/LogIn
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 05:48:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:48:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 05:56:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 06:04:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 06:05:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 06:05:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 06:24:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 06:24:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 08:51:26 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-02 09:48:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 09:49:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 10:45:01 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-02 11:13:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 11:14:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 12:27:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 12:27:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 12:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 12:33:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 12:37:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 12:37:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 14:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 14:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 14:45:43 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-09-02 14:45:48 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-09-02 14:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 14:45:57 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-09-02 14:46:03 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-02 14:46:08 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-02 14:46:12 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-02 14:46:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 14:46:22 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-02 14:46:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 14:46:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 14:46:35 --> 404 Page Not Found: Home/Log In
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:46:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:46:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:46:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:46:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:47:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:47:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:48:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:48:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:03 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:49:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:49:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:50:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:50:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:50:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:50:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:50:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:51:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:51:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 14:51:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 14:51:55 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-09-02 14:51:55 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-02 15:46:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 16:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 17:16:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 17:16:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 17:16:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 17:16:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 17:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 17:17:01 --> 404 Page Not Found: Asset-manifestjson/index
ERROR - 2023-09-02 18:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 18:00:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 18:00:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 18:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-02 18:02:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 18:02:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 18:07:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 18:07:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 19:05:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 19:05:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 19:08:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 19:08:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 19:16:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 19:16:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-02 20:28:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 20:28:08 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b2e8b547949cad3c8c848d8f6af4160ffd58f94', '172.177.33.157', 1693666688, '__ci_last_regenerate|i:1693666688;cart_items|a:0:{}last_page|s:1:\"/\";')
ERROR - 2023-09-02 20:28:08 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('d350fdfdd0e878f6eabf39f76e8461a1') AS ci_session_lock
ERROR - 2023-09-02 21:33:47 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-09-02 21:33:47 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-09-02 21:33:47 --> 404 Page Not Found: 1php/index
ERROR - 2023-09-02 21:33:48 --> 404 Page Not Found: 404php/index
ERROR - 2023-09-02 21:33:48 --> 404 Page Not Found: 403php/index
ERROR - 2023-09-02 21:33:49 --> 404 Page Not Found: Initphp/index
ERROR - 2023-09-02 21:33:49 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-09-02 21:33:50 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-09-02 21:33:50 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-09-02 21:33:51 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-09-02 21:33:51 --> 404 Page Not Found: Docphp/index
ERROR - 2023-09-02 21:33:52 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-09-02 21:33:52 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-09-02 21:33:53 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-09-02 21:33:53 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-09-02 21:33:54 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-09-02 21:33:54 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-09-02 21:33:55 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-09-02 21:33:55 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-09-02 21:33:56 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-09-02 21:33:56 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-09-02 21:33:57 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-09-02 21:33:57 --> 404 Page Not Found: Upphp/index
ERROR - 2023-09-02 21:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-02 21:33:58 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-09-02 21:33:58 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-09-02 21:33:59 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-09-02 21:33:59 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-09-02 21:33:59 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-09-02 21:34:00 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-09-02 21:34:00 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-09-02 21:34:01 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-09-02 21:34:01 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-09-02 21:34:02 --> 404 Page Not Found: Mphp/index
ERROR - 2023-09-02 21:34:02 --> 404 Page Not Found: 503php/index
ERROR - 2023-09-02 21:34:03 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-09-02 21:34:03 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-09-02 21:34:04 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-09-02 21:34:04 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-09-02 21:34:05 --> 404 Page Not Found: Massphp/index
ERROR - 2023-09-02 21:34:05 --> 404 Page Not Found: 1337php/index
ERROR - 2023-09-02 21:34:06 --> 404 Page Not Found: 1877php/index
ERROR - 2023-09-02 21:34:06 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-09-02 21:34:07 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-09-02 21:34:07 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-09-02 21:34:08 --> 404 Page Not Found: Index2php/index
ERROR - 2023-09-02 21:34:08 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-09-02 21:34:09 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-09-02 21:34:09 --> 404 Page Not Found: Marphp/index
ERROR - 2023-09-02 21:34:10 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-09-02 21:34:10 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-09-02 21:34:11 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-09-02 21:34:11 --> 404 Page Not Found: Shphp/index
ERROR - 2023-09-02 21:34:11 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-09-02 21:34:12 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-09-02 21:34:12 --> 404 Page Not Found: Symphp/index
ERROR - 2023-09-02 21:34:13 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-09-02 21:34:13 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-09-02 21:34:14 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-09-02 21:34:14 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-09-02 21:34:15 --> 404 Page Not Found: Docs/_sidebar.md
ERROR - 2023-09-02 21:34:15 --> 404 Page Not Found: Anphp/index
ERROR - 2023-09-02 21:34:15 --> 404 Page Not Found: Staff/index
ERROR - 2023-09-02 21:34:15 --> 404 Page Not Found: Https:/www.quizart.co.in
ERROR - 2023-09-02 21:34:15 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-09-02 21:34:16 --> 404 Page Not Found: Xphp/index
ERROR - 2023-09-02 21:34:16 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-09-02 21:34:17 --> 404 Page Not Found: Byphp/index
ERROR - 2023-09-02 21:34:17 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-09-02 21:34:18 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-09-02 21:34:18 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-09-02 21:34:19 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-09-02 21:34:19 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-09-02 21:34:20 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-09-02 21:34:20 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-09-02 21:34:21 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-09-02 21:34:21 --> 404 Page Not Found: Userphp/index
ERROR - 2023-09-02 21:34:22 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-09-02 21:34:22 --> 404 Page Not Found: Zphp/index
ERROR - 2023-09-02 21:34:22 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-09-02 21:34:23 --> 404 Page Not Found: Chphp/index
ERROR - 2023-09-02 21:34:23 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-09-02 21:34:24 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-09-02 21:34:24 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-09-02 21:34:25 --> 404 Page Not Found: Madphp/index
ERROR - 2023-09-02 21:34:25 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-09-02 21:34:26 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-09-02 21:34:26 --> 404 Page Not Found: Tos/index
ERROR - 2023-09-02 21:34:26 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-09-02 21:34:27 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-09-02 21:34:27 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-09-02 21:34:28 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-09-02 21:34:28 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-09-02 21:34:29 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-09-02 21:34:29 --> 404 Page Not Found: Endphp/index
ERROR - 2023-09-02 21:34:30 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-09-02 21:34:30 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-09-02 21:34:31 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-09-02 21:34:31 --> 404 Page Not Found: __1975php/index
ERROR - 2023-09-02 21:34:32 --> 404 Page Not Found: Killphp/index
ERROR - 2023-09-02 21:34:32 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-09-02 21:34:33 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-09-02 21:34:33 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-09-02 21:34:33 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-09-02 21:34:34 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-09-02 21:34:35 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-09-02 21:34:35 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-09-02 21:34:36 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-09-02 21:34:36 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-09-02 21:34:37 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-09-02 21:34:37 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-09-02 21:34:38 --> 404 Page Not Found: Logphp/index
ERROR - 2023-09-02 21:34:38 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-09-02 21:34:39 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-09-02 21:34:39 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-09-02 21:34:40 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-09-02 21:34:40 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-09-02 21:34:40 --> 404 Page Not Found: Demophp/index
ERROR - 2023-09-02 21:34:41 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-09-02 21:34:41 --> 404 Page Not Found: Motophp/index
ERROR - 2023-09-02 21:34:42 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-09-02 21:34:42 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:34:43 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-09-02 21:34:43 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-09-02 21:34:44 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-09-02 21:34:44 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-09-02 21:34:45 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-02 21:34:45 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-09-02 21:34:46 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-09-02 21:34:46 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-09-02 21:34:47 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-09-02 21:34:47 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-09-02 21:34:48 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-09-02 21:34:48 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-09-02 21:34:49 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-09-02 21:34:49 --> 404 Page Not Found: 1975php/index
ERROR - 2023-09-02 21:34:50 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-09-02 21:34:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:34:51 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-09-02 21:34:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:34:52 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-09-02 21:34:53 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-09-02 21:34:53 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:34:54 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-09-02 21:34:54 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-09-02 21:34:55 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-09-02 21:34:55 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-09-02 21:34:56 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-09-02 21:34:56 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-02 21:34:57 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-09-02 21:34:57 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-09-02 21:34:58 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-09-02 21:34:58 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-09-02 21:34:58 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-09-02 21:34:59 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-09-02 21:34:59 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-09-02 21:35:00 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-09-02 21:35:00 --> 404 Page Not Found: Mephp/index
ERROR - 2023-09-02 21:35:01 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-09-02 21:35:01 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-09-02 21:35:02 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-09-02 21:35:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:03 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-09-02 21:35:03 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-09-02 21:35:04 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-09-02 21:35:04 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-09-02 21:35:05 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-09-02 21:35:05 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-09-02 21:35:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:06 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:35:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:09 --> 404 Page Not Found: Sites/all
ERROR - 2023-09-02 21:35:09 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-09-02 21:35:10 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-09-02 21:35:10 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-09-02 21:35:11 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-09-02 21:35:11 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-09-02 21:35:12 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-09-02 21:35:12 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-09-02 21:35:13 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-09-02 21:35:13 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-09-02 21:35:14 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-09-02 21:35:14 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-09-02 21:35:15 --> 404 Page Not Found: Termphp/index
ERROR - 2023-09-02 21:35:15 --> 404 Page Not Found: Textphp/index
ERROR - 2023-09-02 21:35:16 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-09-02 21:35:16 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-09-02 21:35:16 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-09-02 21:35:17 --> 404 Page Not Found: Homephp/index
ERROR - 2023-09-02 21:35:17 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-09-02 21:35:18 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-09-02 21:35:18 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-09-02 21:35:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:19 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:35:20 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-02 21:35:20 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:21 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-09-02 21:35:21 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-09-02 21:35:22 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:22 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-09-02 21:35:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:26 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-09-02 21:35:26 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-02 21:35:26 --> 404 Page Not Found: 406php/index
ERROR - 2023-09-02 21:35:27 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-02 21:35:27 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-02 21:35:28 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-02 21:35:29 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-09-02 21:35:29 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:35:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:31 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:31 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:32 --> 404 Page Not Found: D7php/index
ERROR - 2023-09-02 21:35:33 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-09-02 21:35:33 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-02 21:35:34 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-09-02 21:35:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:35 --> 404 Page Not Found: Eephp/index
ERROR - 2023-09-02 21:35:35 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-02 21:35:36 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-09-02 21:35:36 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-02 21:35:36 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-09-02 21:35:37 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-09-02 21:35:37 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-09-02 21:35:38 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-09-02 21:35:38 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-09-02 21:35:39 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-02 21:35:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 21:35:40 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-09-02 21:35:40 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-02 21:35:41 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-02 21:35:41 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-02 21:35:42 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-02 21:35:42 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-09-02 21:35:43 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 22:18:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 22:18:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-02 22:23:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 22:23:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-02 22:53:50 --> 404 Page Not Found: Admin/index.php
