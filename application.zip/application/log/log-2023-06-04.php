<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-04 00:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-04 00:10:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 02:16:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 02:16:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-04 02:16:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-04 02:17:06 --> 404 Page Not Found: Log/index
ERROR - 2023-06-04 02:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-04 02:17:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-04 02:17:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-04 02:48:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 02:48:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 02:53:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 02:53:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 04:55:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 04:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-04 07:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-04 07:44:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 20:55:45 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-04 20:55:45 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-04 23:28:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-04 23:28:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-04 23:28:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-04 23:43:36 --> 404 Page Not Found: Robotstxt/index
