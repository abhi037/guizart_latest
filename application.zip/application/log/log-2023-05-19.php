<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-19 00:18:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 03:32:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 03:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 03:43:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 03:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-19 07:21:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 09:42:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 10:35:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 14:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-19 14:08:56 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-19 14:36:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 14:59:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 14:59:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 14:59:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:00:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:00:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:01:46 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 139
ERROR - 2023-05-19 15:01:46 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 139
ERROR - 2023-05-19 15:01:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-05-19 15:01:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 146
ERROR - 2023-05-19 15:01:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-05-19 15:01:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-19 15:02:01 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 139
ERROR - 2023-05-19 15:02:01 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 139
ERROR - 2023-05-19 15:02:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-05-19 15:02:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 146
ERROR - 2023-05-19 15:02:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-05-19 15:25:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:25:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:26:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:26:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:26:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:26:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:26:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:26:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:26:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:26:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:26:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-19 15:30:57 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-19 15:31:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:31:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:31:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:31:09 --> 404 Page Not Found: Log/index
ERROR - 2023-05-19 15:31:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:31:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:32:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:33:02 --> 404 Page Not Found: Log/index
ERROR - 2023-05-19 15:33:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:33:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:33:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:34:26 --> 404 Page Not Found: Log/index
ERROR - 2023-05-19 15:36:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:36:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:36:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:37:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:37:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:37:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:37:17 --> 404 Page Not Found: Log/index
ERROR - 2023-05-19 15:38:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:38:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:38:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-19 15:38:46 --> 404 Page Not Found: Log/index
ERROR - 2023-05-19 15:39:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:39:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:39:33 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-19 15:39:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:39:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-19 15:39:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-19 15:40:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 15:40:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:40:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:40:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:40:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:41:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-19 15:41:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:45:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:45:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:46:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-19 15:50:25 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-19 20:18:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-19 21:27:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
