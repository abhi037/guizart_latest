<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-19 00:02:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:03:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 00:19:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:19:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:22:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:23:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 00:23:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 00:23:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 00:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 00:29:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:37:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:37:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 00:38:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:39:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 00:39:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 00:40:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 01:01:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 01:01:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 01:37:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 01:37:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 01:52:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 01:52:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 01:59:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 01:59:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 02:35:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 02:35:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 02:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 02:50:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 02:50:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 02:57:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 02:57:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 03:06:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 03:06:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 04:20:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 04:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 04:57:03 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 04:57:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 05:47:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 05:47:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 05:47:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 05:47:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 06:13:33 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-19 06:30:26 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-19 06:42:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 06:42:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 06:42:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:17:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:17:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:19:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:21:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:21:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 07:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 07:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 07:22:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 07:28:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 08:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 08:20:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 08:22:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 08:22:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 08:36:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 08:36:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 08:54:14 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 08:54:14 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 09:00:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 09:00:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 10:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 10:35:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 10:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 10:50:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 10:50:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 10:51:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 10:51:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 11:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 11:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 11:49:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 11:50:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 11:50:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 13:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 13:32:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 13:32:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 13:36:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 13:36:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 14:02:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 14:03:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 14:31:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 14:32:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 14:39:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 14:39:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 14:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 14:52:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-19 14:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 14:55:09 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-19 15:00:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 15:04:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 15:04:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 15:09:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 15:09:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 15:29:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:05:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:05:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:07:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 17:11:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:20:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:58:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 17:58:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 17:58:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-19 18:26:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 18:26:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-19 18:53:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 18:53:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 18:53:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 18:53:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 21:14:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 21:14:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 21:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 21:15:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 21:25:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 21:25:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 22:06:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 22:06:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:11:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:11:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:11:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:12:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:12:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:17:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:17:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:24:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:24:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-19 22:25:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:26:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:29:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:44:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:44:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:55:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 22:55:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:55:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:55:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 22:55:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 23:14:23 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-19 23:15:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 23:29:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 23:29:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 23:29:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-19 23:29:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-19 23:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
