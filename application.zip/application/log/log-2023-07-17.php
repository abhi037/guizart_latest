<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 03:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-17 03:21:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 03:21:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 03:21:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 03:23:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 03:23:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 03:23:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 05:37:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 06:53:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 07:50:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 07:56:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-17 09:05:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 09:05:27 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-07-17 09:05:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 15:49:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 20:33:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 20:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-17 20:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 21:52:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:07:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:07:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:07:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:07:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:07:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:07:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-17 23:07:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:07:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:07:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:07:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:09:09 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:09:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:09:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:09:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:09:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:09:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:09:19 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:09:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:09:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:11:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:11:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:11:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:11:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:12:15 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:12:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:12:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:12:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:12:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:12:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:13:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:13:30 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:13:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:13:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:13:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:13:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:15:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:15:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:15:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:15:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:15:33 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:15:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:15:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:15:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:16:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:16:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:17:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:17:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:17:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:17:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:17:37 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:17:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:17:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:18:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:19:47 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-17 23:19:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:19:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:19:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:19:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:19:51 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:20:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:54 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:20:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:20:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:20:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:21:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:21:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:21:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:21:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:21:12 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:21:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-17 23:21:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-17 23:21:21 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-17 23:21:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:22:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:22:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:22:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:24:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:24:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:24:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:24:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:24:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:24:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:24:59 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-17 23:24:59 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-17 23:24:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-07-17 23:24:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 149
ERROR - 2023-07-17 23:24:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-07-17 23:25:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:25:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:25:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:25:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:25:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:26:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:26:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:26:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:26:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:28:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:28:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:28:30 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-17 23:28:30 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-17 23:28:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-07-17 23:28:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 149
ERROR - 2023-07-17 23:28:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-07-17 23:29:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:29:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:29:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:30:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-17 23:30:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-17 23:30:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-17 23:30:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:30:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:30:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:30:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:30:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:31:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:31:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:31:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:32:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:32:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:32:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:36:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:36:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:36:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:36:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:36:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:37:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:37:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-17 23:37:25 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-17 23:37:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-17 23:37:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-17 23:38:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:38:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:38:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:38:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:38:11 --> 404 Page Not Found: Log/index
ERROR - 2023-07-17 23:38:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:38:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:51:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-17 23:51:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:51:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-17 23:51:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
