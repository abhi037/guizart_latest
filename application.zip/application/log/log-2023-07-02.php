<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-02 00:56:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 02:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-02 02:23:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 02:30:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 02:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-02 04:18:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 04:18:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:18:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 04:20:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:20:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:30:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 04:30:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:31:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 04:31:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 04:31:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-02 08:47:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 12:36:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:31:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-02 20:31:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:32:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-02 20:33:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-02 20:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-02 20:34:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
