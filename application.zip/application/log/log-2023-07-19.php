<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-19 04:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-19 05:10:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 05:17:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 07:11:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:41:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:41:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:41:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:41:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:41:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:41:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:42:00 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:42:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:42:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:42:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:42:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:42:08 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:43:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:43:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:43:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:43:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:43:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:43:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:43:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:43:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:43:39 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:44:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:44:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:44:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:44:49 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:44:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:44:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:44:59 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:45:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:45:22 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:45:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:45:28 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:45:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:45:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:45:32 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:45:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:45:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:45:40 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:45:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:45:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:45:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:45:56 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:46:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:46:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:46:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:46:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:12 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:47:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:47:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:24 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:47:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:29 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:47:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:47:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:47:45 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:47:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:47:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:47:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:48:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:48:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:48:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:48:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:48:09 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:48:49 --> Severity: Notice --> Undefined variable: instructor_list /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:49 --> Severity: Notice --> Undefined variable: instructor_list /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:51 --> Severity: Notice --> Undefined variable: instructor_list /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:51 --> Severity: Notice --> Undefined variable: instructor_list /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-07-19 09:48:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:48:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:48:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:48:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:49:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:50:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:50:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:50:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:50:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:08 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:51:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:51:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:51:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:51:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:51:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:51:48 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:52:04 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:52:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:52:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:52:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:23 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:54:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:54:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:54:48 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:55:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 09:55:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:55:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:55:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:55:11 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:55:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:55:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:55:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:55:16 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:55:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:55:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:55:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:55:38 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:55:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:55:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:55:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:56:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:56:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:56:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:56:06 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:56:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:56:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:56:19 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:56:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:57:13 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:57:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:57:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:57:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:57:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:57:20 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:57:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:57:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:57:33 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:57:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:57:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:57:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:57:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:57:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:57:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:57:56 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:58:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:58:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:58:05 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:58:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:58:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:58:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:58:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:58:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:58:43 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:59:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:05 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:59:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:09 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:59:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:20 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:59:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:59:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:59:26 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:59:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:59:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:59:37 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 09:59:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 09:59:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 09:59:46 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 09:59:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 09:59:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 09:59:51 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 10:00:31 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 10:00:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 10:00:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:00:36 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 10:00:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 10:00:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:01:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 10:01:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:01:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:01:03 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 10:01:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 10:01:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:01:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 10:01:50 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-19 10:01:50 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-19 10:01:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-07-19 10:01:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 149
ERROR - 2023-07-19 10:01:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-07-19 10:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 10:12:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 13:31:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 13:31:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 13:31:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 13:31:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 13:31:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 13:32:09 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-19 13:32:09 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-19 13:32:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-07-19 13:32:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 149
ERROR - 2023-07-19 13:32:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-07-19 13:32:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 15:40:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 17:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-19 17:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 20:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 20:52:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 21:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 21:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 23:12:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:16:34 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-07-19 23:30:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:31:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:31:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:31:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:31:05 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 23:31:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-19 23:31:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:31:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:31:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:31:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:31:19 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 23:31:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 23:31:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 23:31:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 23:31:49 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-19 23:31:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:32:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:33:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:33:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:33:45 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 23:34:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:34:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:34:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:34:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:34:13 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 23:36:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-19 23:36:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:36:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-19 23:36:43 --> 404 Page Not Found: Log/index
ERROR - 2023-07-19 23:36:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-19 23:36:56 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-07-19 23:36:56 --> 404 Page Not Found: Assets/backend
