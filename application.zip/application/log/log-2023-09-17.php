<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-17 00:53:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:05:47 --> 404 Page Not Found: Wp-json/wp
ERROR - 2023-09-17 01:05:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:06:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:06:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 01:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 01:15:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:15:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 01:33:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:33:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 01:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:36:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:36:31 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-17 01:36:31 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-17 01:36:32 --> 404 Page Not Found: Old1/index
ERROR - 2023-09-17 01:36:33 --> 404 Page Not Found: Old2/index
ERROR - 2023-09-17 01:36:33 --> 404 Page Not Found: OLDSITE/index
ERROR - 2023-09-17 01:36:34 --> 404 Page Not Found: Beta/index
ERROR - 2023-09-17 01:36:34 --> 404 Page Not Found: Staging/index
ERROR - 2023-09-17 01:36:35 --> 404 Page Not Found: BKP/index
ERROR - 2023-09-17 01:36:35 --> 404 Page Not Found: Old-site/index
ERROR - 2023-09-17 01:36:36 --> 404 Page Not Found: Oldwebsite/index
ERROR - 2023-09-17 01:36:36 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-17 01:36:37 --> 404 Page Not Found: Dev/index
ERROR - 2023-09-17 01:36:37 --> 404 Page Not Found: Test/index
ERROR - 2023-09-17 01:36:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:36:39 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-09-17 01:36:39 --> 404 Page Not Found: Old_files/index
ERROR - 2023-09-17 01:36:40 --> 404 Page Not Found: Old/index
ERROR - 2023-09-17 01:36:40 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-17 01:36:42 --> 404 Page Not Found: BAK/index
ERROR - 2023-09-17 01:37:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:37:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 01:39:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 01:39:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 02:00:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 02:00:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 02:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 02:06:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 02:08:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 02:08:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 02:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 02:31:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 02:31:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 02:44:15 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-17 03:53:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 03:56:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 05:21:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 05:22:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 06:21:33 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-17 08:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 08:03:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:07:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:07:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 08:09:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 08:10:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:10:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 08:27:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:27:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 08:29:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:42:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 08:42:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 09:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 10:55:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-17 11:03:23 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 11:03:23 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-17 11:09:51 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 11:09:51 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 11:26:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 11:26:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 11:30:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-17 11:52:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 12:14:13 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-17 12:14:15 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-17 12:14:17 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-17 12:14:23 --> 404 Page Not Found: New/index
ERROR - 2023-09-17 12:14:25 --> 404 Page Not Found: Test/index
ERROR - 2023-09-17 12:14:30 --> 404 Page Not Found: Temp/index
ERROR - 2023-09-17 12:14:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 12:25:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 14:29:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-17 14:29:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-17 14:29:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-17 14:29:51 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-17 14:30:28 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-17 14:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 14:34:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 14:39:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 14:39:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 14:41:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 14:41:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 14:48:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 14:48:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 16:08:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-17 16:08:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-17 16:08:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 16:08:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-17 17:39:12 --> 404 Page Not Found: Wp-content/admin.php
ERROR - 2023-09-17 17:39:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-17 17:39:15 --> 404 Page Not Found: Aykphp/index
ERROR - 2023-09-17 17:39:16 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-17 17:39:18 --> 404 Page Not Found: Gejuphp/index
ERROR - 2023-09-17 19:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 20:48:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 20:48:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 20:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-17 20:50:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 20:50:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 20:50:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 20:51:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 20:57:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 20:57:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 21:47:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 21:47:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-17 22:09:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 22:15:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 22:39:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 22:39:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 22:43:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-17 23:11:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-17 23:11:37 --> 404 Page Not Found: Adstxt/index
