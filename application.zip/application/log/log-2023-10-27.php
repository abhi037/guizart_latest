<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-27 00:10:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 00:17:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 00:18:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 00:25:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 00:25:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 00:30:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 00:30:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 00:48:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 00:48:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 00:48:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 01:00:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 01:20:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 01:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 01:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 01:47:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 01:47:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 01:48:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 01:48:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 02:20:30 --> 404 Page Not Found: Env/index
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 02:40:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 02:40:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 03:02:32 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-27 03:26:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 03:26:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 03:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 03:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 03:37:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 03:39:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 03:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 03:58:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 03:58:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 04:10:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 04:10:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 04:41:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 04:41:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 04:58:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 04:58:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 05:05:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 05:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 05:18:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 05:18:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 05:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 05:23:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 05:23:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 05:38:23 --> 404 Page Not Found: Wp-loadphp/index
ERROR - 2023-10-27 05:38:33 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-10-27 05:38:34 --> 404 Page Not Found: Wp-admin/style.php
ERROR - 2023-10-27 05:38:42 --> 404 Page Not Found: S_ephp/index
ERROR - 2023-10-27 05:39:07 --> 404 Page Not Found: S_nephp/index
ERROR - 2023-10-27 05:39:30 --> 404 Page Not Found: 1indexphp/index
ERROR - 2023-10-27 05:39:35 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-10-27 05:39:41 --> 404 Page Not Found: Docphp/index
ERROR - 2023-10-27 05:39:48 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-10-27 05:39:51 --> 404 Page Not Found: Beencephp/index
ERROR - 2023-10-27 05:39:59 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-10-27 05:40:04 --> 404 Page Not Found: Wp-signinphp/index
ERROR - 2023-10-27 05:40:07 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-10-27 05:40:12 --> 404 Page Not Found: Exportphp/index
ERROR - 2023-10-27 05:40:12 --> 404 Page Not Found: Wp-content/export.php
ERROR - 2023-10-27 05:40:18 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-10-27 05:40:21 --> 404 Page Not Found: Wp-includes/wp-atom.php
ERROR - 2023-10-27 05:40:34 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-10-27 05:40:34 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-10-27 05:40:42 --> 404 Page Not Found: Defau1tphp/index
ERROR - 2023-10-27 05:40:52 --> 404 Page Not Found: Modulessphp/index
ERROR - 2023-10-27 05:40:56 --> 404 Page Not Found: Wp-bookingphp/index
ERROR - 2023-10-27 05:41:04 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 05:41:11 --> 404 Page Not Found: Wp-content/mu-plugins
ERROR - 2023-10-27 05:41:16 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-10-27 05:41:20 --> 404 Page Not Found: Configbakphp/index
ERROR - 2023-10-27 05:41:20 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-27 05:41:25 --> 404 Page Not Found: Legionphp/index
ERROR - 2023-10-27 05:41:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 05:41:44 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-10-27 05:41:56 --> 404 Page Not Found: GankphpPhP/index
ERROR - 2023-10-27 05:42:05 --> 404 Page Not Found: Wp-content/db-cache.php
ERROR - 2023-10-27 05:42:09 --> 404 Page Not Found: Archivesphp/index
ERROR - 2023-10-27 05:42:22 --> 404 Page Not Found: Defau11php/index
ERROR - 2023-10-27 05:42:34 --> 404 Page Not Found: Wp-content/outcms.php
ERROR - 2023-10-27 05:42:51 --> 404 Page Not Found: System_logphp/index
ERROR - 2023-10-27 05:42:55 --> 404 Page Not Found: Wp-backup-sql-302php/index
ERROR - 2023-10-27 05:43:14 --> 404 Page Not Found: Errorphp/index
ERROR - 2023-10-27 05:43:19 --> 404 Page Not Found: ALFA_DATA/index
ERROR - 2023-10-27 05:43:21 --> 404 Page Not Found: Alfacgiapi/index
ERROR - 2023-10-27 05:43:22 --> 404 Page Not Found: Cgialfa/index
ERROR - 2023-10-27 05:43:26 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-27 05:43:27 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-27 05:43:29 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-27 05:43:31 --> 404 Page Not Found: Wp-includes/ALFA_DATA
ERROR - 2023-10-27 05:43:32 --> 404 Page Not Found: Wp-includes/alfacgiapi
ERROR - 2023-10-27 05:43:34 --> 404 Page Not Found: Wp-includes/cgialfa
ERROR - 2023-10-27 05:43:36 --> 404 Page Not Found: Wp-admin/ALFA_DATA
ERROR - 2023-10-27 05:43:37 --> 404 Page Not Found: Wp-admin/alfacgiapi
ERROR - 2023-10-27 05:43:39 --> 404 Page Not Found: Wp-admin/cgialfa
ERROR - 2023-10-27 05:43:41 --> 404 Page Not Found: Wp-content/ALFA_DATA
ERROR - 2023-10-27 05:43:42 --> 404 Page Not Found: Wp-content/alfacgiapi
ERROR - 2023-10-27 05:43:45 --> 404 Page Not Found: Wp-content/cgialfa
ERROR - 2023-10-27 05:43:47 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-10-27 05:43:49 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-10-27 05:43:51 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-10-27 05:43:53 --> 404 Page Not Found: Sites/default
ERROR - 2023-10-27 05:43:55 --> 404 Page Not Found: Sites/default
ERROR - 2023-10-27 05:43:57 --> 404 Page Not Found: Sites/default
ERROR - 2023-10-27 05:44:01 --> 404 Page Not Found: Admin/controller
ERROR - 2023-10-27 05:44:04 --> 404 Page Not Found: Admin/controller
ERROR - 2023-10-27 05:44:07 --> 404 Page Not Found: Admin/controller
ERROR - 2023-10-27 05:44:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 05:44:14 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-10-27 05:44:15 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-10-27 05:44:17 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-10-27 05:44:17 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-10-27 05:44:18 --> 404 Page Not Found: Upphp/index
ERROR - 2023-10-27 05:44:19 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-10-27 05:44:19 --> 404 Page Not Found: 1php/index
ERROR - 2023-10-27 05:44:21 --> 404 Page Not Found: Xphp/index
ERROR - 2023-10-27 05:44:21 --> 404 Page Not Found: Zphp/index
ERROR - 2023-10-27 05:44:22 --> 404 Page Not Found: Aphp/index
ERROR - 2023-10-27 05:44:23 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-10-27 05:44:24 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-10-27 05:44:24 --> 404 Page Not Found: Configphp/index
ERROR - 2023-10-27 05:44:25 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-10-27 05:44:25 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-10-27 05:44:26 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-10-27 05:51:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 05:57:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 05:57:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 06:02:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 06:02:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 06:02:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 06:05:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 06:05:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 06:08:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 06:08:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 06:08:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 06:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 06:13:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 06:15:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 07:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 07:22:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 07:24:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 07:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 07:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 07:25:49 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-27 07:26:03 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-27 07:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 07:26:15 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-27 07:26:24 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-27 07:26:32 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-27 07:26:40 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 07:36:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 07:36:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 07:36:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 08:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 08:01:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 08:01:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 08:16:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 08:16:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 08:16:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 08:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 08:40:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 08:40:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 09:01:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 09:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 10:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 10:13:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 10:13:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 10:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 10:41:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 10:42:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 10:43:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 10:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 11:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 11:09:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 11:10:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 11:13:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 11:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 11:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 11:26:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 11:27:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 11:39:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 11:39:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 11:39:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 11:45:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 11:45:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 12:09:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 12:09:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 12:12:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 12:12:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 12:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 12:16:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 12:23:54 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-27 13:43:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 13:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 15:12:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 15:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 15:42:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 15:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 15:49:06 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-27 15:49:06 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-27 15:49:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 15:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 15:53:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 16:01:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 16:01:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 16:01:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 16:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:29:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:29:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 16:30:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:31:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:34:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 16:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 16:46:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:46:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 16:46:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 16:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 17:00:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:00:09 --> 404 Page Not Found: Cjfunsphp/index
ERROR - 2023-10-27 17:00:10 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-10-27 17:00:10 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-10-27 17:00:10 --> 404 Page Not Found: Stphp/index
ERROR - 2023-10-27 17:00:11 --> 404 Page Not Found: My1php/index
ERROR - 2023-10-27 17:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 17:27:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:28:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 17:30:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:34:49 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-27 17:34:49 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 17:34:50 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-10-27 17:34:50 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-27 17:34:50 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-10-27 17:34:51 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-10-27 17:34:51 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-10-27 17:34:51 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-10-27 17:34:52 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-10-27 17:34:52 --> 404 Page Not Found: Eephp/index
ERROR - 2023-10-27 17:34:52 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-10-27 17:34:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 17:34:53 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-10-27 17:34:53 --> 404 Page Not Found: Installphp/index
ERROR - 2023-10-27 17:34:54 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-10-27 17:34:54 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-27 17:34:54 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-10-27 17:34:55 --> 404 Page Not Found: Css/install.php
ERROR - 2023-10-27 17:34:55 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-27 17:34:56 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-27 17:34:56 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-10-27 17:34:56 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-10-27 17:34:57 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-10-27 17:34:57 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-10-27 17:34:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-27 17:34:58 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-10-27 17:35:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:36:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:46:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:46:51 --> 404 Page Not Found: Env/index
ERROR - 2023-10-27 17:47:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 17:51:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 17:51:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 18:00:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 18:25:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 18:44:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 18:45:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 18:50:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 18:50:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 19:22:02 --> 404 Page Not Found: Env/index
ERROR - 2023-10-27 19:24:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:25:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:25:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 19:25:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 19:25:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:26:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:27:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:27:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:27:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:27:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:30:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 19:31:25 --> 404 Page Not Found: Env/index
ERROR - 2023-10-27 19:41:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-27 19:41:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-27 19:41:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 19:41:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-27 19:41:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 20:52:49 --> 404 Page Not Found: Env/index
ERROR - 2023-10-27 20:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 21:12:55 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-10-27 21:12:56 --> 404 Page Not Found: Feed/index
ERROR - 2023-10-27 21:12:56 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-10-27 21:12:56 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-10-27 21:12:56 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-10-27 21:12:57 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-10-27 21:12:57 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-10-27 21:12:57 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-10-27 21:12:57 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-10-27 21:12:58 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-10-27 21:12:58 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-10-27 21:12:58 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-10-27 21:12:58 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-10-27 21:12:58 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-10-27 21:12:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-10-27 22:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 22:58:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 23:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 23:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-27 23:33:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-27 23:52:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-27 23:52:09 --> 404 Page Not Found: Assets/frontend
