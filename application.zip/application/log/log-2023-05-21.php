<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-21 03:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-21 03:54:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-21 03:55:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-21 03:55:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-21 03:55:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-21 11:00:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-21 13:36:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-21 13:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-21 16:25:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-21 19:52:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-21 19:52:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
