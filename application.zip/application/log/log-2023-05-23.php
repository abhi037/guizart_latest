<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-23 01:05:43 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-05-23 05:45:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 05:45:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 05:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 05:53:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-23 05:53:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-23 06:10:21 --> 404 Page Not Found: Git/config
ERROR - 2023-05-23 07:38:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 11:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-23 11:44:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 13:19:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 14:42:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 14:49:29 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-05-23 14:49:30 --> 404 Page Not Found: Feed/index
ERROR - 2023-05-23 23:54:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 23:54:45 --> 404 Page Not Found: Public/home
ERROR - 2023-05-23 23:54:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-23 23:54:46 --> 404 Page Not Found: Static/admin
ERROR - 2023-05-23 23:54:46 --> 404 Page Not Found: Public/home
ERROR - 2023-05-23 23:54:47 --> 404 Page Not Found: Public/home
ERROR - 2023-05-23 23:54:47 --> 404 Page Not Found: Static/admin
ERROR - 2023-05-23 23:54:48 --> 404 Page Not Found: Static/admin
