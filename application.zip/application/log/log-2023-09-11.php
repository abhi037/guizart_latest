<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-11 00:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 00:15:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 00:15:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 00:40:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-11 01:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 02:52:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-11 02:52:57 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-09-11 02:53:07 --> 404 Page Not Found: View-source:/index
ERROR - 2023-09-11 02:53:17 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2023-09-11 03:38:07 --> 404 Page Not Found: Env/index
ERROR - 2023-09-11 03:38:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 03:38:14 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-11 03:38:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 03:38:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-11 03:44:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 03:44:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 06:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 06:18:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 06:22:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 06:31:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 06:39:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 06:54:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 06:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 07:28:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 07:36:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 07:36:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 07:36:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 08:07:45 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-11 08:07:47 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-11 08:07:49 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-11 08:07:53 --> 404 Page Not Found: New/index
ERROR - 2023-09-11 08:07:55 --> 404 Page Not Found: Test/index
ERROR - 2023-09-11 08:07:58 --> 404 Page Not Found: Temp/index
ERROR - 2023-09-11 08:08:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 08:18:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 08:18:09 --> 404 Page Not Found: Kgcebbbuza/index
ERROR - 2023-09-11 09:29:40 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-09-11 09:29:40 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-11 09:29:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 09:29:56 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-11 09:29:59 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-11 09:30:02 --> 404 Page Not Found: WP/index
ERROR - 2023-09-11 09:30:04 --> 404 Page Not Found: Shop/index
ERROR - 2023-09-11 09:30:08 --> 404 Page Not Found: STORE/index
ERROR - 2023-09-11 09:30:13 --> 404 Page Not Found: Forum/index
ERROR - 2023-09-11 09:30:16 --> 404 Page Not Found: FORUM/index
ERROR - 2023-09-11 09:30:19 --> 404 Page Not Found: Store/index
ERROR - 2023-09-11 09:30:22 --> 404 Page Not Found: SHOP/index
ERROR - 2023-09-11 09:30:25 --> 404 Page Not Found: WordPress/index
ERROR - 2023-09-11 09:30:28 --> 404 Page Not Found: WORDPRESS/index
ERROR - 2023-09-11 09:30:30 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-11 09:30:33 --> 404 Page Not Found: New/index
ERROR - 2023-09-11 09:30:38 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-11 09:30:43 --> 404 Page Not Found: Backup/index
ERROR - 2023-09-11 09:30:47 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-09-11 09:30:51 --> 404 Page Not Found: Test/index
ERROR - 2023-09-11 09:30:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 09:30:55 --> 404 Page Not Found: 2020/index
ERROR - 2023-09-11 09:30:57 --> 404 Page Not Found: 2019/index
ERROR - 2023-09-11 09:31:00 --> 404 Page Not Found: Site/index
ERROR - 2023-09-11 09:31:02 --> 404 Page Not Found: 2018/index
ERROR - 2023-09-11 09:31:06 --> 404 Page Not Found: 2017/index
ERROR - 2023-09-11 09:31:08 --> 404 Page Not Found: 2016/index
ERROR - 2023-09-11 09:31:13 --> 404 Page Not Found: 2015/index
ERROR - 2023-09-11 09:31:17 --> 404 Page Not Found: 2014/index
ERROR - 2023-09-11 09:31:19 --> 404 Page Not Found: 2013/index
ERROR - 2023-09-11 09:31:22 --> 404 Page Not Found: 2012/index
ERROR - 2023-09-11 09:31:26 --> 404 Page Not Found: 2010/index
ERROR - 2023-09-11 09:31:29 --> 404 Page Not Found: 2009/index
ERROR - 2023-09-11 09:31:34 --> 404 Page Not Found: BLOG/index
ERROR - 2023-09-11 09:31:39 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-11 09:31:42 --> 404 Page Not Found: NEW/index
ERROR - 2023-09-11 09:31:45 --> 404 Page Not Found: New/index
ERROR - 2023-09-11 09:31:51 --> 404 Page Not Found: DEMO/index
ERROR - 2023-09-11 09:31:54 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-11 09:42:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 10:04:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 11:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 11:51:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 11:51:35 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-11 11:51:37 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-11 11:51:38 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-09-11 11:51:39 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-09-11 11:51:41 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-11 11:51:42 --> 404 Page Not Found: New/index
ERROR - 2023-09-11 11:51:45 --> 404 Page Not Found: Newsite/index
ERROR - 2023-09-11 11:51:46 --> 404 Page Not Found: Test/index
ERROR - 2023-09-11 11:51:48 --> 404 Page Not Found: Core/index
ERROR - 2023-09-11 11:51:49 --> 404 Page Not Found: Testing/index
ERROR - 2023-09-11 11:51:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 12:31:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 12:59:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 13:10:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 13:35:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 13:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 13:51:25 --> 404 Page Not Found: Cdn-cgi/l
ERROR - 2023-09-11 14:19:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 14:19:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 14:35:43 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-11 14:35:44 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-11 14:38:54 --> 404 Page Not Found: Home/Log In
ERROR - 2023-09-11 16:06:29 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-11 16:35:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 16:35:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 17:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 17:01:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 17:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 17:24:43 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-11 17:52:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 17:52:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-11 18:34:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 18:34:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-11 18:59:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 18:59:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 19:00:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 19:12:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 19:12:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 19:34:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 19:34:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 20:29:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 21:38:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 21:38:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-11 21:50:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 21:50:09 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-11 21:50:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-11 21:50:12 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-09-11 21:50:13 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-11 21:50:14 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-09-11 21:50:16 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-11 21:50:17 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-09-11 21:50:19 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-09-11 21:50:20 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-09-11 21:50:21 --> 404 Page Not Found: Eephp/index
ERROR - 2023-09-11 21:50:22 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-09-11 21:50:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-11 21:50:26 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-09-11 21:50:29 --> 404 Page Not Found: Installphp/index
ERROR - 2023-09-11 21:50:32 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-09-11 21:50:33 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-11 21:50:35 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-09-11 21:50:38 --> 404 Page Not Found: Css/install.php
ERROR - 2023-09-11 21:50:39 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-11 21:50:41 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-11 21:50:42 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-09-11 21:50:44 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-09-11 21:50:45 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-09-11 21:50:46 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-09-11 21:50:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-11 21:50:49 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-09-11 21:50:50 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-11 21:50:52 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-09-11 21:50:53 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-11 21:50:54 --> 404 Page Not Found: Wp-admin/about.php
ERROR - 2023-09-11 21:50:55 --> 404 Page Not Found: Wp-content/about.php
ERROR - 2023-09-11 21:50:57 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-11 21:50:58 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-11 21:50:59 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-11 21:51:00 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-11 21:51:01 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-11 21:51:02 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-09-11 21:51:04 --> 404 Page Not Found: Congphp/index
ERROR - 2023-09-11 21:51:05 --> 404 Page Not Found: Wp-admin/cong.php
ERROR - 2023-09-11 21:51:06 --> 404 Page Not Found: Stphp/index
ERROR - 2023-09-11 21:51:08 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-09-11 21:51:12 --> 404 Page Not Found: Cgi-bin/wp-signup.php
ERROR - 2023-09-11 21:51:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-11 22:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 22:08:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 22:08:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 22:08:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-11 22:09:07 --> 404 Page Not Found: Assets/frontend
