<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-22 01:19:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 01:26:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 03:47:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 04:29:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 04:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-22 04:47:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-22 04:53:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-22 04:53:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-22 04:54:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-22 04:54:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-22 10:37:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 10:37:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-22 10:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-22 11:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-22 11:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 11:38:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 12:10:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 15:51:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 16:35:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 16:35:25 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-22 20:12:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 20:12:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 20:12:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-22 20:12:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 20:12:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-22 20:12:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 23:12:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 23:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-22 23:46:12 --> 404 Page Not Found: Robotstxt/index
