<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-15 00:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 00:26:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 00:26:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 00:36:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 00:36:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 00:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 00:49:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 00:49:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 00:50:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 00:50:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 00:51:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 00:51:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 01:00:12 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 01:00:18 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 01:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 01:28:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 01:28:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 01:36:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 01:36:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 01:36:32 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-15 01:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 02:03:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 02:03:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 02:28:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 02:28:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 02:30:49 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 02:30:54 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 03:01:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 03:01:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 03:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 03:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 04:04:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 04:04:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 04:05:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-15 04:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 05:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 05:08:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 05:08:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 05:09:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 05:09:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 05:42:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 05:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:21 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:43:42 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 05:43:42 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:43:42 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 05:43:42 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:12 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:44:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 05:45:34 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 05:45:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:45:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 05:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 06:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 06:18:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 06:31:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 06:31:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 06:34:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 06:37:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 06:37:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 06:43:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 06:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 07:03:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 07:04:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 07:04:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 07:35:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 07:35:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 07:43:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 07:43:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 07:43:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 07:43:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 07:48:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 08:01:07 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-15 08:01:13 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-10-15 08:01:24 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-10-15 08:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 08:03:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 08:33:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 08:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 10:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 10:19:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 10:19:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:02:05 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:02:05 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:06:08 --> 404 Page Not Found: Upload/server
ERROR - 2023-10-15 11:06:10 --> 404 Page Not Found: Admin/server
ERROR - 2023-10-15 11:06:11 --> 404 Page Not Found: Fileupload/server
ERROR - 2023-10-15 11:30:04 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-10-15 11:32:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 11:32:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 11:32:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 11:35:49 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-15 11:37:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 11:37:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 11:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 11:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 11:47:53 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-15 11:47:58 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-15 11:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 11:48:04 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-15 11:48:11 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-15 11:48:16 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-15 11:48:24 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-15 11:48:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 11:48:39 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-15 11:48:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 11:48:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 11:49:02 --> 404 Page Not Found: Home/Log In
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:49:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:49:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:49:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:49:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:49:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:49:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:50:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:50:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:50:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:50:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:50:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:50:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:51:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:51:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:51:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:51:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:51:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:52:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:52:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:52:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:52:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:52:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:53:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:53:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:53:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:53:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:53:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:53:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:44 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:54:59 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:54:59 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 11:55:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:55:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 11:55:23 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-15 11:55:23 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-15 12:49:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 12:49:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 12:52:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 13:07:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 13:07:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 13:09:30 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-15 13:09:30 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-15 13:15:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 13:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 13:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 13:20:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 13:20:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 13:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 13:48:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 13:48:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 14:02:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 14:06:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 14:06:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 14:15:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 14:15:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 14:54:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 15:45:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 15:45:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 16:09:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 16:09:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 16:51:14 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-15 16:51:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 16:51:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 17:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 17:57:46 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-10-15 17:58:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-15 18:13:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:18:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:18:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 18:18:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 18:18:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:29:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:29:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 18:39:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 18:55:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 18:55:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 19:05:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:40 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:05:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:05:41 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 19:05:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:01 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:01 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:01 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:01 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 19:06:01 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:02 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:05 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:05 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:05 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:05 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:05 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:31 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 19:06:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:52 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:06:53 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 19:06:54 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:42 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:07:45 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:45 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 19:07:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 19:21:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 19:21:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 19:24:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 19:24:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 19:30:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 19:30:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 19:55:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 19:55:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 20:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 20:27:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 20:27:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 20:28:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 20:28:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:05 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:05 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 20:29:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:29:38 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:29:38 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:18 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:19 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:19 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 20:30:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:30:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:30:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:01 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:01 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 20:31:38 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-15 21:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 21:03:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 21:03:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 21:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-15 21:29:23 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 21:29:23 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-15 21:38:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 22:06:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-15 22:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 22:27:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-15 22:58:26 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 22:58:31 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-15 23:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 23:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-15 23:04:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-15 23:15:25 --> 404 Page Not Found: Robotstxt/index
