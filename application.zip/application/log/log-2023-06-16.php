<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-16 05:41:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-16 05:41:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-16 05:51:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-16 14:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-16 14:53:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-16 14:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-16 14:54:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-16 14:59:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-16 17:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-16 17:10:32 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-16 17:10:33 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-16 17:10:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-16 19:36:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
