<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-07 01:09:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 05:59:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 08:14:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 12:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-07 14:07:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 14:07:58 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-07 14:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-07 14:17:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 14:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-07 16:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-07 16:43:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 16:43:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 17:10:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 17:11:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-07 17:11:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-07 20:57:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 21:02:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-07 21:03:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-07 21:06:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 21:07:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-07 21:08:48 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-07-07 21:08:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 21:57:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-07 21:57:13 --> 404 Page Not Found: Assets/frontend
