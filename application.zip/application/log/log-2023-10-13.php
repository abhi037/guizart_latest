<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-13 01:45:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 01:45:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 01:45:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 01:45:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 01:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 01:49:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 01:56:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 01:56:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 01:58:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 01:58:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 02:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 02:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 02:16:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:18:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:19:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 02:24:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:34:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:35:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 02:35:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 02:49:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 02:55:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:55:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 02:57:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 02:57:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 03:14:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 03:19:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 03:19:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 03:34:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 03:34:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 04:04:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 04:07:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 04:29:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:33:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:36:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:36:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 04:36:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:37:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 04:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 04:40:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:54:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:54:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:54:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:55:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:55:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 04:55:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:05:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:06:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:06:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:06:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:06:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:06:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:07:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:07:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:08:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:32:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:32:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 05:40:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 05:40:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 05:49:15 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 06:18:05 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 06:18:05 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 06:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 06:30:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 06:30:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 06:35:43 --> 404 Page Not Found: Lcgreek84748/vdv1266048.htm
ERROR - 2023-10-13 06:38:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 06:38:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 07:28:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 07:29:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 07:35:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 07:35:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 07:36:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 07:36:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 08:05:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 08:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 08:34:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 08:34:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 08:37:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 08:37:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 08:37:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 09:20:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 09:20:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 10:12:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 10:29:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 10:31:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 11:10:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:10:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 11:17:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 11:17:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 11:23:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 11:23:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 11:25:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:25:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:25:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:26:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:38:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 11:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 11:38:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 12:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 12:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 13:06:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 13:06:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 13:13:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:14:08 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:14:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:32 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:33 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:36 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:15:37 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:16:56 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:16:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:04 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:18:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-13 13:19:28 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-13 13:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 14:05:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:06:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 14:11:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:11:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 14:13:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:13:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 14:19:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:20:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 14:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 14:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 14:39:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 14:39:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 14:52:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 14:52:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 15:29:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 15:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 16:17:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 16:17:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 16:24:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 16:24:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 16:24:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 16:24:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 16:24:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 16:24:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 16:43:28 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-10-13 16:45:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 16:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 16:59:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 17:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 17:50:55 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-13 17:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 17:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 17:58:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:13:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:43:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:43:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:43:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:43:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:43:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:45:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:46:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 18:47:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:32:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:33:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 19:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 19:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:37:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:37:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:39:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:39:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 19:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-13 19:47:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:47:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 19:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 19:49:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 20:31:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 20:31:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 20:39:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 20:39:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 21:10:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:11:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:12:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-13 21:12:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 21:12:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-13 21:13:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:14:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:37:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:37:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:37:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:38:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 21:38:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 22:04:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 22:05:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 22:14:22 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-13 22:14:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-13 22:24:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-13 22:33:53 --> 404 Page Not Found: Robotstxt/index
