<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-17 00:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 00:34:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 00:34:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 04:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-17 04:33:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 06:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-17 06:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-17 06:42:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-17 08:20:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 10:40:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 10:40:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 10:41:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 11:49:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 11:49:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 11:49:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 14:39:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 15:39:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 15:39:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-17 15:43:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 15:53:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-17 16:08:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-17 22:42:17 --> 404 Page Not Found: Git/config
ERROR - 2023-05-17 22:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-17 22:46:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-17 22:46:51 --> 404 Page Not Found: Faviconico/index
