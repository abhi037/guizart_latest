<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-13 04:19:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 05:41:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 06:42:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 07:08:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 12:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 21:51:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 21:51:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-13 21:51:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-13 21:51:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-13 21:51:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
