<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-30 00:00:34 --> 404 Page Not Found: Wp-plainphp/index
ERROR - 2023-07-30 00:00:34 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 00:00:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 00:00:35 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2023-07-30 00:19:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 00:20:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 00:48:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 01:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 01:39:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 01:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 02:04:34 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-30 02:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 05:55:53 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-07-30 06:06:55 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-07-30 07:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 07:12:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 08:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 08:03:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-30 08:17:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 08:17:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 08:17:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 09:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 09:07:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 09:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 09:39:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 11:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 11:33:58 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-30 11:56:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 12:17:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 12:35:14 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-30 12:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 12:35:16 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-30 12:35:17 --> 404 Page Not Found: Bc/index
ERROR - 2023-07-30 12:35:17 --> 404 Page Not Found: Bk/index
ERROR - 2023-07-30 12:35:20 --> 404 Page Not Found: New/index
ERROR - 2023-07-30 12:35:21 --> 404 Page Not Found: Main/index
ERROR - 2023-07-30 12:35:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 14:38:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 14:38:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 14:42:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 14:42:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 14:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 14:53:54 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-07-30 15:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 15:06:02 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-07-30 16:14:27 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-07-30 16:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 16:25:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 16:25:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 16:30:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 17:42:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 17:42:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 17:53:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 17:53:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 19:18:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 19:18:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 19:36:32 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-07-30 19:36:33 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-07-30 19:36:33 --> 404 Page Not Found: 1php/index
ERROR - 2023-07-30 19:36:34 --> 404 Page Not Found: 404php/index
ERROR - 2023-07-30 19:36:34 --> 404 Page Not Found: 403php/index
ERROR - 2023-07-30 19:36:34 --> 404 Page Not Found: Initphp/index
ERROR - 2023-07-30 19:36:35 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-07-30 19:36:35 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-07-30 19:36:36 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-07-30 19:36:36 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-07-30 19:36:36 --> 404 Page Not Found: Docphp/index
ERROR - 2023-07-30 19:36:37 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-07-30 19:36:37 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-07-30 19:36:37 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-07-30 19:36:38 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-07-30 19:36:38 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-07-30 19:36:39 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-07-30 19:36:39 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-07-30 19:36:39 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-07-30 19:36:40 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-07-30 19:36:40 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-07-30 19:36:41 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-07-30 19:36:41 --> 404 Page Not Found: Upphp/index
ERROR - 2023-07-30 19:36:41 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-07-30 19:36:42 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-07-30 19:36:42 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-07-30 19:36:43 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-07-30 19:36:43 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-07-30 19:36:43 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-07-30 19:36:44 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-07-30 19:36:44 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-07-30 19:36:44 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-07-30 19:36:45 --> 404 Page Not Found: Mphp/index
ERROR - 2023-07-30 19:36:45 --> 404 Page Not Found: 503php/index
ERROR - 2023-07-30 19:36:46 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-07-30 19:36:46 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-07-30 19:36:46 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-07-30 19:36:47 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-07-30 19:36:47 --> 404 Page Not Found: Massphp/index
ERROR - 2023-07-30 19:36:48 --> 404 Page Not Found: 1337php/index
ERROR - 2023-07-30 19:36:48 --> 404 Page Not Found: 1877php/index
ERROR - 2023-07-30 19:36:48 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-07-30 19:36:49 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-07-30 19:36:49 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-07-30 19:36:50 --> 404 Page Not Found: Index2php/index
ERROR - 2023-07-30 19:36:50 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-07-30 19:36:50 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-07-30 19:36:51 --> 404 Page Not Found: Marphp/index
ERROR - 2023-07-30 19:36:51 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-07-30 19:36:52 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-07-30 19:36:52 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-07-30 19:36:52 --> 404 Page Not Found: Shphp/index
ERROR - 2023-07-30 19:36:53 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-07-30 19:36:53 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-07-30 19:36:53 --> 404 Page Not Found: Symphp/index
ERROR - 2023-07-30 19:36:54 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-07-30 19:36:54 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-07-30 19:36:55 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-07-30 19:36:55 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-07-30 19:36:55 --> 404 Page Not Found: Anphp/index
ERROR - 2023-07-30 19:36:56 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-07-30 19:36:56 --> 404 Page Not Found: Xphp/index
ERROR - 2023-07-30 19:36:57 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-07-30 19:36:57 --> 404 Page Not Found: Byphp/index
ERROR - 2023-07-30 19:36:57 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-07-30 19:36:58 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-07-30 19:36:58 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-07-30 19:36:59 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-07-30 19:36:59 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-07-30 19:36:59 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-07-30 19:37:00 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-07-30 19:37:00 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-07-30 19:37:00 --> 404 Page Not Found: Userphp/index
ERROR - 2023-07-30 19:37:01 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-07-30 19:37:01 --> 404 Page Not Found: Zphp/index
ERROR - 2023-07-30 19:37:02 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-07-30 19:37:02 --> 404 Page Not Found: Chphp/index
ERROR - 2023-07-30 19:37:02 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-07-30 19:37:03 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-07-30 19:37:03 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-07-30 19:37:04 --> 404 Page Not Found: Madphp/index
ERROR - 2023-07-30 19:37:04 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-07-30 19:37:04 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-07-30 19:37:05 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-07-30 19:37:05 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-07-30 19:37:05 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-07-30 19:37:06 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-07-30 19:37:06 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-07-30 19:37:07 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-07-30 19:37:07 --> 404 Page Not Found: Endphp/index
ERROR - 2023-07-30 19:37:07 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-07-30 19:37:08 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-07-30 19:37:08 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-07-30 19:37:09 --> 404 Page Not Found: __1975php/index
ERROR - 2023-07-30 19:37:09 --> 404 Page Not Found: Killphp/index
ERROR - 2023-07-30 19:37:09 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-07-30 19:37:10 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-07-30 19:37:10 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-07-30 19:37:11 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-07-30 19:37:11 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-07-30 19:37:12 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-07-30 19:37:12 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-07-30 19:37:13 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-07-30 19:37:13 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-07-30 19:37:14 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-07-30 19:37:14 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-07-30 19:37:14 --> 404 Page Not Found: Logphp/index
ERROR - 2023-07-30 19:37:15 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-07-30 19:37:15 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-07-30 19:37:16 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-07-30 19:37:16 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-07-30 19:37:16 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-07-30 19:37:17 --> 404 Page Not Found: Demophp/index
ERROR - 2023-07-30 19:37:17 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-07-30 19:37:17 --> 404 Page Not Found: Motophp/index
ERROR - 2023-07-30 19:37:18 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-07-30 19:37:18 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:37:19 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-07-30 19:37:19 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-07-30 19:37:19 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-07-30 19:37:20 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-07-30 19:37:20 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-07-30 19:37:21 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-07-30 19:37:21 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-07-30 19:37:21 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-07-30 19:37:22 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-07-30 19:37:22 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-07-30 19:37:23 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-07-30 19:37:23 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-07-30 19:37:23 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-07-30 19:37:24 --> 404 Page Not Found: 1975php/index
ERROR - 2023-07-30 19:37:24 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-07-30 19:37:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:25 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-07-30 19:37:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:26 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-07-30 19:37:26 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-07-30 19:37:27 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:37:27 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-07-30 19:37:28 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-07-30 19:37:28 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-07-30 19:37:28 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-07-30 19:37:29 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-07-30 19:37:29 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-07-30 19:37:29 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-07-30 19:37:30 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-07-30 19:37:30 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-07-30 19:37:31 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-07-30 19:37:31 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-07-30 19:37:31 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-07-30 19:37:32 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-07-30 19:37:32 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-07-30 19:37:33 --> 404 Page Not Found: Mephp/index
ERROR - 2023-07-30 19:37:33 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-07-30 19:37:33 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-07-30 19:37:34 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-07-30 19:37:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:35 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-07-30 19:37:35 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-07-30 19:37:35 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-07-30 19:37:36 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-07-30 19:37:36 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-07-30 19:37:36 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-07-30 19:37:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:37 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:37:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:39 --> 404 Page Not Found: Sites/all
ERROR - 2023-07-30 19:37:40 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-07-30 19:37:40 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-07-30 19:37:40 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-07-30 19:37:41 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-07-30 19:37:41 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-07-30 19:37:41 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-07-30 19:37:42 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-07-30 19:37:42 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-07-30 19:37:43 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-07-30 19:37:43 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-07-30 19:37:43 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-07-30 19:37:44 --> 404 Page Not Found: Termphp/index
ERROR - 2023-07-30 19:37:44 --> 404 Page Not Found: Textphp/index
ERROR - 2023-07-30 19:37:45 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-07-30 19:37:45 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-07-30 19:37:45 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-07-30 19:37:46 --> 404 Page Not Found: Homephp/index
ERROR - 2023-07-30 19:37:46 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-07-30 19:37:47 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-07-30 19:37:47 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-07-30 19:37:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:48 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:37:48 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-30 19:37:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:49 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-07-30 19:37:49 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-07-30 19:37:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:50 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-07-30 19:37:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:52 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-07-30 19:37:53 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-07-30 19:37:53 --> 404 Page Not Found: 406php/index
ERROR - 2023-07-30 19:37:54 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-30 19:37:54 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-07-30 19:37:54 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-07-30 19:37:55 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-07-30 19:37:55 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:37:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:57 --> 404 Page Not Found: D7php/index
ERROR - 2023-07-30 19:37:58 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-07-30 19:37:58 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-07-30 19:37:59 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-07-30 19:37:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:37:59 --> 404 Page Not Found: Eephp/index
ERROR - 2023-07-30 19:38:00 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-07-30 19:38:00 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-07-30 19:38:01 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-30 19:38:01 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-07-30 19:38:01 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-07-30 19:38:02 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-07-30 19:38:02 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-07-30 19:38:02 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-07-30 19:38:03 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-07-30 19:38:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 19:38:04 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-07-30 19:38:04 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-07-30 19:38:04 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-30 19:38:05 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-07-30 19:38:05 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-07-30 19:38:06 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-07-30 19:38:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-30 20:07:19 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-30 20:33:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 20:36:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 20:41:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 20:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 21:17:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 21:18:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 21:18:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 21:18:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 21:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 21:22:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 21:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 21:22:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 21:22:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 21:39:21 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-07-30 21:59:50 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 22:10:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 22:10:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 22:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-30 22:11:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 22:11:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-30 22:12:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 22:13:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 22:13:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:32:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:33:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:34:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:34:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:35:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:36:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:38:05 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-07-30 22:54:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:54:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 22:59:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 22:59:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 22:59:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 23:03:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-30 23:03:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-30 23:03:15 --> 404 Page Not Found: Assets/frontend
