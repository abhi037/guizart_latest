<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-25 00:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 00:18:00 --> 404 Page Not Found: Wp-admin/index
ERROR - 2023-09-25 00:39:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 00:39:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 00:54:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 00:54:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-25 01:17:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 01:17:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 01:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 01:57:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 01:57:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 03:04:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 03:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 04:14:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 04:14:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 04:15:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 04:17:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 04:17:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 04:17:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 04:18:13 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-25 04:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 04:20:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-25 04:34:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 04:35:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 06:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 07:31:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 08:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-25 08:35:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 08:35:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 08:42:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 08:42:47 --> 404 Page Not Found: Collections/all.atom
ERROR - 2023-09-25 08:42:52 --> 404 Page Not Found: Feed/index
ERROR - 2023-09-25 08:54:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 08:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 09:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 09:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 09:55:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 10:44:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 10:45:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 10:45:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 10:45:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 10:45:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 10:45:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 10:47:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 10:47:28 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:03:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:03:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:05:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:05:32 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:06:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:06:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:07:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:07:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:10:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:10:45 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:12:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:12:22 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:13:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:13:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:13:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:13:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:13:25 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:14:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:14:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:19:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:19:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:23:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:23:33 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:24:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:24:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:24:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:25:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:25:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:26:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:26:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:26:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:26:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:26:30 --> 404 Page Not Found: Log/index
ERROR - 2023-09-25 11:26:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:26:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:26:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:26:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:27:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:30:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:32:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 11:32:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:33:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 11:33:43 --> 404 Page Not Found: Log/index
ERROR - 2023-09-25 11:33:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:33:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:33:51 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:33:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:33:54 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:33:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:33:56 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 11:36:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-25 11:36:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-25 12:55:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 13:20:45 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-25 13:20:49 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-25 13:20:56 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-25 13:21:14 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-09-25 13:21:23 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-25 13:21:38 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-25 13:21:53 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-09-25 13:21:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:22 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:22:44 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-09-25 13:22:58 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:23:06 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-25 13:23:23 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-25 13:23:31 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-09-25 13:23:47 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:23:51 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-25 13:23:59 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:24:04 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:24:21 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:24:40 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:24:46 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-09-25 13:24:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:25:00 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-09-25 13:25:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:25:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:25:50 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:25:55 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-25 13:49:55 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-25 13:50:16 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-25 13:50:21 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-25 13:50:26 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-09-25 13:50:31 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-25 13:50:34 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-25 13:50:37 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-09-25 13:50:40 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:50:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:50:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:51:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:51:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:51:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:51:48 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-09-25 13:52:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:52:16 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-25 13:52:21 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-25 13:52:43 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-09-25 13:52:47 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:52:51 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-25 13:52:55 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:53:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:53:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:53:27 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:53:34 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-09-25 13:53:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:53:41 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-09-25 13:53:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:53:58 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-25 13:54:01 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-25 13:54:07 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-25 14:15:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 14:15:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 14:15:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 14:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 15:02:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 15:02:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 15:09:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 15:09:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 15:10:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 15:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 16:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 16:07:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 16:07:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 16:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 17:03:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:04:55 --> 404 Page Not Found: Env/index
ERROR - 2023-09-25 17:04:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:27:41 --> 404 Page Not Found: Env/index
ERROR - 2023-09-25 17:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:41:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:42:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:43:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-25 17:57:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 17:57:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 18:11:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-25 19:42:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 19:42:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-25 20:31:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 21:00:05 --> 404 Page Not Found: Env/index
ERROR - 2023-09-25 21:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 21:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 21:13:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-25 21:13:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-25 21:27:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 21:27:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 21:27:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 21:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 21:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 22:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 23:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-25 23:05:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 23:05:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 23:06:01 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-25 23:06:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-25 23:06:48 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
