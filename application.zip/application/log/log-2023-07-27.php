<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-27 00:05:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 00:05:30 --> 404 Page Not Found: Blog-single-with-sidebarhtml/index
ERROR - 2023-07-27 00:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 00:29:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 00:32:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 01:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 02:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 03:33:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 04:16:02 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-07-27 06:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 06:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 06:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 06:15:58 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-27 06:15:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 06:15:59 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-27 06:15:59 --> 404 Page Not Found: Bc/index
ERROR - 2023-07-27 06:15:59 --> 404 Page Not Found: Bk/index
ERROR - 2023-07-27 06:16:01 --> 404 Page Not Found: New/index
ERROR - 2023-07-27 06:16:02 --> 404 Page Not Found: Main/index
ERROR - 2023-07-27 06:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 06:36:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 06:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 06:39:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 06:46:26 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-27 07:38:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 07:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-27 08:15:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 08:15:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 08:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 08:26:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 08:26:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 08:42:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 09:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 09:02:45 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-27 09:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 10:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 10:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 10:22:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 10:37:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 11:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 11:56:02 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-07-27 11:56:02 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-07-27 11:56:02 --> 404 Page Not Found: View-source:/index
ERROR - 2023-07-27 11:56:02 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2023-07-27 12:32:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 15:02:50 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-27 15:43:53 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-27 15:43:54 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-07-27 15:43:55 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-07-27 15:43:55 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-07-27 15:43:56 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-07-27 15:43:56 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-07-27 15:43:57 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-07-27 15:43:58 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-27 15:43:58 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-07-27 15:43:58 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-07-27 15:43:59 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-07-27 15:43:59 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-27 15:44:00 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-07-27 15:44:00 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-27 15:44:01 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-07-27 15:44:01 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-07-27 15:44:01 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-27 15:44:01 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-27 15:44:02 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-07-27 15:44:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-27 15:44:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-27 15:44:02 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-27 15:44:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-27 15:44:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-27 15:44:21 --> 404 Page Not Found: Revisionphp/index
ERROR - 2023-07-27 17:00:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 17:00:24 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-27 17:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 17:39:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 18:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 19:21:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 19:21:08 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-27 19:21:09 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-27 19:21:09 --> 404 Page Not Found: Blog/index
ERROR - 2023-07-27 19:21:10 --> 404 Page Not Found: New/index
ERROR - 2023-07-27 19:21:11 --> 404 Page Not Found: Test/index
ERROR - 2023-07-27 19:21:12 --> 404 Page Not Found: Main/index
ERROR - 2023-07-27 19:21:12 --> 404 Page Not Found: Testing/index
ERROR - 2023-07-27 19:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 20:07:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 20:07:12 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-07-27 20:07:12 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-07-27 20:07:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 20:07:13 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-07-27 20:07:13 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-07-27 20:07:13 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-07-27 20:07:13 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-07-27 20:07:13 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-07-27 20:07:14 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-07-27 20:07:15 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-07-27 20:07:15 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-07-27 20:07:15 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-07-27 20:07:15 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-07-27 20:07:15 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-07-27 21:00:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 21:00:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 21:00:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 21:00:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-27 21:00:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-27 21:00:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:00:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-27 21:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-27 21:55:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 23:52:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 23:52:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 23:53:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-27 23:53:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
