<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-26 02:14:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 02:14:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 02:25:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 02:25:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-26 02:28:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 04:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-26 04:17:35 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-05-26 04:17:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-05-26 04:17:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 05:38:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 05:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-26 05:55:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 06:01:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 06:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-26 06:06:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-26 06:14:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-26 06:48:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 06:48:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-26 12:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-26 12:26:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 15:24:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 18:21:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 18:21:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-26 18:21:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-26 18:23:07 --> 404 Page Not Found: Log/index
ERROR - 2023-05-26 18:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-26 18:52:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 21:33:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 21:41:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-26 23:55:11 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-05-26 23:55:14 --> 404 Page Not Found: Public/_ignition
