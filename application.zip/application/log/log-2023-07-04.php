<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-04 00:37:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 01:18:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 01:18:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 01:18:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 06:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 10:02:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 10:39:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 12:13:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 12:25:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 12:25:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 12:25:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 13:44:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 13:44:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 13:44:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-04 14:25:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 14:25:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-04 14:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 14:33:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-04 21:02:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 21:03:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 21:03:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-04 21:03:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-04 23:08:38 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-07-04 23:08:41 --> 404 Page Not Found: Public/_ignition
