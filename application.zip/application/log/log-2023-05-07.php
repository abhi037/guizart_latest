<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-07 00:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-07 01:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-07 01:35:45 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-05-07 01:35:46 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-05-07 01:35:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 02:37:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-05-07 02:37:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-05-07 02:53:38 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-05-07 02:53:38 --> 404 Page Not Found: Feed/index
ERROR - 2023-05-07 03:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-07 03:14:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 03:14:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 03:16:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 03:30:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-07 03:52:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 05:28:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 05:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-07 08:20:08 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-07 16:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-07 16:44:10 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-05-07 16:44:39 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-07 16:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-07 16:45:32 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-05-07 16:45:47 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-05-07 16:52:28 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-07 17:27:03 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-07 17:34:15 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-07 17:34:35 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-07 17:59:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 17:59:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 17:59:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 18:03:38 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-05-07 18:12:39 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-07 18:18:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-07 18:28:40 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-07 21:11:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 21:11:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 21:12:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-07 21:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-07 21:12:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 21:12:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 21:27:57 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-07 21:29:15 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-07 21:32:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 21:32:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 21:32:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 21:35:16 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-07 21:37:17 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-07 21:37:27 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-07 21:46:09 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-05-07 21:48:29 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-07 21:49:49 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-07 22:05:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 22:05:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 22:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 22:05:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 22:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 22:05:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-07 22:05:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 22:05:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 22:05:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-07 22:05:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 22:06:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-07 22:06:04 --> 404 Page Not Found: Assets/frontend
