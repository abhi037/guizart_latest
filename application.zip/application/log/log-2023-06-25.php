<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-25 07:30:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-25 08:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-25 10:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-25 10:52:56 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-25 10:52:57 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-25 10:52:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
