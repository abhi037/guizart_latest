<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-01 01:42:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 01:42:43 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-06-01 03:37:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 03:37:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 04:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-01 04:34:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 04:34:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 04:35:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 05:44:20 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-01 05:44:20 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-01 06:37:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 06:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 06:37:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 10:24:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:11:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:11:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:11:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:11:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 13:12:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:12:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:12:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:12:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:15:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:16:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:16:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:16:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:17:02 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-06-01 13:17:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:17:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:17:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:17:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:17:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:18:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:18:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:19:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:19:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:19:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:19:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:22:11 --> 404 Page Not Found: Log/index
ERROR - 2023-06-01 13:24:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:25:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-01 13:25:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:27:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:27:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:44:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:44:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:44:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:44:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:44:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:44:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:45:11 --> 404 Page Not Found: Log/index
ERROR - 2023-06-01 13:45:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:45:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:45:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:46:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:46:02 --> 404 Page Not Found: Log/index
ERROR - 2023-06-01 13:48:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:48:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:48:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:48:58 --> 404 Page Not Found: Log/index
ERROR - 2023-06-01 13:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:49:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:49:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:51:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:51:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:51:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:51:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:51:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:52:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:52:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:35 --> 404 Page Not Found: Log/index
ERROR - 2023-06-01 13:52:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 13:52:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 13:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 13:53:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 16:51:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 16:53:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 19:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-01 19:48:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 19:49:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 20:04:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 20:04:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 20:04:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-01 22:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 23:00:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 23:00:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 23:00:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-01 23:00:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-01 23:00:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
