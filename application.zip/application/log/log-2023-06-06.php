<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-06 03:19:33 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-06-06 04:25:51 --> 404 Page Not Found: Git/config
ERROR - 2023-06-06 05:30:09 --> 404 Page Not Found: Git/config
ERROR - 2023-06-06 07:59:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 16:45:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 17:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-06 20:06:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 21:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-06 21:47:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-06 22:03:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 22:03:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 22:03:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-06 22:03:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-06 22:04:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-06 22:04:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
