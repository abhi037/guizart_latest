<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-23 00:18:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 00:18:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 00:18:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 01:24:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 01:24:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 01:24:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-23 01:44:47 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 01:44:47 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 02:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 02:11:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 03:17:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 03:17:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 03:17:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 03:34:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 03:34:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 03:35:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 03:48:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 03:48:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 05:10:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 05:10:35 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-23 06:04:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 06:06:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 06:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 06:07:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-23 07:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 07:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 07:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 08:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 08:05:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 08:05:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 08:18:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 08:22:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 08:29:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 09:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 09:05:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 09:05:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 09:15:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 09:38:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 09:58:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 09:59:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-23 11:05:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 11:05:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-23 11:10:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 11:10:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 11:28:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 11:28:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 11:28:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 11:28:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 11:48:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 11:56:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 12:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 13:04:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 13:04:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 13:13:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 13:13:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 13:30:13 --> 404 Page Not Found: Env/index
ERROR - 2023-08-23 13:40:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 13:40:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 13:40:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 13:40:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-23 14:08:14 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 14:08:14 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 14:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 14:38:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 15:37:16 --> 404 Page Not Found: Env/index
ERROR - 2023-08-23 16:17:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 16:42:13 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-23 16:59:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-23 16:59:35 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-23 17:09:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 17:09:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 18:07:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 18:10:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 18:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 18:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 18:33:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 18:33:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 18:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 19:11:22 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1068
ERROR - 2023-08-23 19:11:22 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/successpage.php 1
ERROR - 2023-08-23 19:11:23 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1068
ERROR - 2023-08-23 19:11:23 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/successpage.php 1
ERROR - 2023-08-23 20:03:34 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-08-23 20:16:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 20:17:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 20:51:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 22:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 22:35:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-08-23 23:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-23 23:02:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 23:02:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-23 23:09:03 --> 404 Page Not Found: Env/index
ERROR - 2023-08-23 23:09:03 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-08-23 23:19:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 23:19:31 --> 404 Page Not Found: Wp/index
ERROR - 2023-08-23 23:19:32 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-08-23 23:19:33 --> 404 Page Not Found: Wordpress1/index
ERROR - 2023-08-23 23:19:34 --> 404 Page Not Found: Old1/index
ERROR - 2023-08-23 23:19:35 --> 404 Page Not Found: Old2/index
ERROR - 2023-08-23 23:19:36 --> 404 Page Not Found: OLDSITE/index
ERROR - 2023-08-23 23:19:37 --> 404 Page Not Found: Beta/index
ERROR - 2023-08-23 23:19:38 --> 404 Page Not Found: Staging/index
ERROR - 2023-08-23 23:19:39 --> 404 Page Not Found: BKP/index
ERROR - 2023-08-23 23:19:40 --> 404 Page Not Found: Old-site/index
ERROR - 2023-08-23 23:19:41 --> 404 Page Not Found: 123/index
ERROR - 2023-08-23 23:19:42 --> 404 Page Not Found: Oldwebsite/index
ERROR - 2023-08-23 23:19:43 --> 404 Page Not Found: Blog/index
ERROR - 2023-08-23 23:19:44 --> 404 Page Not Found: Dev/index
ERROR - 2023-08-23 23:19:45 --> 404 Page Not Found: Newsite/index
ERROR - 2023-08-23 23:19:46 --> 404 Page Not Found: Test/index
ERROR - 2023-08-23 23:19:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 23:19:48 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-08-23 23:19:49 --> 404 Page Not Found: Old_files/index
ERROR - 2023-08-23 23:19:50 --> 404 Page Not Found: Old/index
ERROR - 2023-08-23 23:19:51 --> 404 Page Not Found: Demo/index
ERROR - 2023-08-23 23:19:52 --> 404 Page Not Found: Site/index
ERROR - 2023-08-23 23:19:53 --> 404 Page Not Found: Wordpress-old/index
ERROR - 2023-08-23 23:19:56 --> 404 Page Not Found: New/index
ERROR - 2023-08-23 23:19:57 --> 404 Page Not Found: Oldsitehere/index
ERROR - 2023-08-23 23:19:58 --> 404 Page Not Found: BAK/index
ERROR - 2023-08-23 23:19:59 --> 404 Page Not Found: Oldsiteback/index
ERROR - 2023-08-23 23:20:00 --> 404 Page Not Found: Devnew/index
ERROR - 2023-08-23 23:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-23 23:24:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 23:24:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-23 23:38:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-23 23:38:49 --> 404 Page Not Found: Assets/frontend
