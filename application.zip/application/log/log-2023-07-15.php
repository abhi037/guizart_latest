<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-15 00:10:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 01:28:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 01:39:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 01:39:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 06:32:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 07:48:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-15 07:48:35 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-15 07:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 07:48:38 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-15 07:48:39 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-15 07:48:40 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-15 07:48:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 07:49:06 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-15 07:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 07:49:08 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-15 07:49:09 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-15 07:49:09 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-15 07:49:10 --> 404 Page Not Found: Pma/index.php
ERROR - 2023-07-15 07:49:11 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2023-07-15 07:49:11 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2023-07-15 07:49:12 --> 404 Page Not Found: Php/thinkphp
ERROR - 2023-07-15 07:49:13 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2023-07-15 08:08:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 08:08:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-15 08:08:39 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-15 08:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 08:08:43 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-15 08:08:45 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-15 08:08:45 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-15 08:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 08:09:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-15 08:09:29 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-15 08:09:30 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-15 08:09:31 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-15 08:09:32 --> 404 Page Not Found: Pma/index.php
ERROR - 2023-07-15 08:09:33 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2023-07-15 08:09:34 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2023-07-15 08:09:35 --> 404 Page Not Found: Php/thinkphp
ERROR - 2023-07-15 08:09:35 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2023-07-15 08:42:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 13:50:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 13:50:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:51:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 13:51:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:53:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:53:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:53:09 --> 404 Page Not Found: Log/index
ERROR - 2023-07-15 13:57:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 13:57:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:57:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:57:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 13:57:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 14:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 14:25:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 14:25:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:04:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 15:04:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:04:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:05:00 --> 404 Page Not Found: Log/index
ERROR - 2023-07-15 15:05:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-15 15:05:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 15:05:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:05:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:08:23 --> 404 Page Not Found: Log/index
ERROR - 2023-07-15 15:08:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 15:08:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 15:08:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-15 16:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-15 17:36:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 17:42:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 18:39:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-15 23:30:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
