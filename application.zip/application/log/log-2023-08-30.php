<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-30 01:10:43 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-30 01:40:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 01:56:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:11:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:11:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:12:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:13:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:14:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 02:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 03:07:25 --> 404 Page Not Found: Env/index
ERROR - 2023-08-30 03:13:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 03:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-30 03:59:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 03:59:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 04:18:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 04:21:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-30 04:21:53 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-30 04:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 04:38:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-30 04:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 04:55:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 04:57:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 05:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 05:02:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 05:56:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 06:00:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 06:01:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 06:02:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 07:43:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 07:43:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 07:44:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 07:44:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 07:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 07:45:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 07:45:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 07:49:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 07:49:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 08:36:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 08:44:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:45:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:47:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:47:09 --> 404 Page Not Found: Feed/index
ERROR - 2023-08-30 08:47:09 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-30 08:47:09 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-08-30 08:47:10 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-08-30 08:47:10 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-08-30 08:47:10 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-08-30 08:47:10 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-08-30 08:47:10 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-08-30 08:47:11 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-08-30 08:51:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:51:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 08:53:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:53:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:53:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:53:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 08:54:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-30 09:56:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 09:56:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 10:50:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-08-30 10:50:52 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-08-30 10:51:02 --> 404 Page Not Found: View-source:/index
ERROR - 2023-08-30 10:51:12 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2023-08-30 10:57:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 10:57:06 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-30 11:58:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 11:58:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 12:01:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 12:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 13:01:55 --> 404 Page Not Found: Env/index
ERROR - 2023-08-30 13:01:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 13:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 14:23:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 14:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 14:50:58 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-08-30 14:50:58 --> 404 Page Not Found: Feed/index
ERROR - 2023-08-30 14:50:58 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-30 14:50:59 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-08-30 14:50:59 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-08-30 14:50:59 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-08-30 14:50:59 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-08-30 14:50:59 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-08-30 14:51:00 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-08-30 14:51:00 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-08-30 14:51:00 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-08-30 14:51:00 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-08-30 14:51:00 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-08-30 14:51:01 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-08-30 14:51:01 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-08-30 14:51:22 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-30 15:27:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 15:27:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-30 15:33:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 15:33:22 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-08-30 15:35:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 15:35:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 15:39:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 15:40:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 15:49:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 15:50:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 15:50:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 17:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 17:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 17:11:48 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-08-30 17:12:07 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-08-30 17:12:27 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-08-30 17:12:45 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-08-30 17:13:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 17:13:23 --> 404 Page Not Found: Log In/index
ERROR - 2023-08-30 17:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 17:24:03 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-30 17:44:16 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-30 18:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 19:05:17 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-30 21:19:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-30 21:19:06 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-30 21:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 21:24:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 21:24:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 21:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-30 21:26:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 21:26:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 21:35:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 21:35:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 22:09:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 22:16:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 22:16:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 22:16:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 22:16:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 22:23:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 22:54:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-30 23:15:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 23:15:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 23:18:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 23:18:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-30 23:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-30 23:28:42 --> 404 Page Not Found: Assets/frontend
