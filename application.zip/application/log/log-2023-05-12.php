<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-12 00:20:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 05:25:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 05:25:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-12 05:48:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 07:34:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 08:46:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 08:46:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 09:15:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 09:15:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 09:15:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 09:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-12 10:30:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 10:30:14 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-05-12 14:09:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 14:23:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 14:25:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 14:25:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 14:25:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 14:26:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 14:26:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-12 14:51:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 14:51:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-12 18:59:13 --> 404 Page Not Found: Wp-json/wp
