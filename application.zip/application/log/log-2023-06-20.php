<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-20 00:39:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 06:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-20 06:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-20 06:43:47 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-06-20 09:53:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 15:37:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 15:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-20 20:12:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 20:16:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 20:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-20 20:18:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-20 20:18:58 --> 404 Page Not Found: Faviconico/index
