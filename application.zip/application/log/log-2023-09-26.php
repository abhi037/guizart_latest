<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-26 00:44:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 00:44:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 00:44:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 00:45:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 00:45:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 00:57:58 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-09-26 00:57:58 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-09-26 00:57:58 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-09-26 00:57:59 --> 404 Page Not Found: Congphp/index
ERROR - 2023-09-26 00:57:59 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-26 01:09:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:09:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:09:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:09:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:10:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:10:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:10:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:11:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:11:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:11:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:12:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:12:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:25:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 01:29:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:29:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 01:30:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 01:42:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 04:39:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 04:39:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 04:41:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 04:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 04:42:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 04:43:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 05:47:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 05:47:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 05:53:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 05:53:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 06:09:08 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-26 06:09:17 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-09-26 06:09:28 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-09-26 06:09:46 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-09-26 06:09:53 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-26 06:10:01 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-09-26 06:10:05 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-26 06:10:08 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-26 06:10:14 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-09-26 06:10:25 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-26 06:10:31 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-26 06:10:36 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-26 06:10:41 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-26 06:10:46 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-09-26 07:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 09:30:44 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-26 09:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 10:16:03 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-26 10:52:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 10:52:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 10:52:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 10:52:29 --> 404 Page Not Found: Log/index
ERROR - 2023-09-26 10:52:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:52:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:52:34 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 10:53:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 10:53:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 10:58:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:58:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:58:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:58:32 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:58:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:28 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:59:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:59:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 10:59:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 10:59:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:00:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:00:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:00:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:00:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:00:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:03:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:03:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:06:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:06:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:08:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:08:23 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:13:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:13:29 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:16:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:16:11 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:17:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:17:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:22:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:22:28 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:24:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:24:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:28:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:28:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:29:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:29:32 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 11:35:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 11:38:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:38:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:40:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:40:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:40:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:40:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:40:20 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:41:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:41:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:43:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:43:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:44:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:44:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:46:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:46:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:47:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:47:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:49:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:49:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:51:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:51:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:54:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:54:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:55:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:55:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:58:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:58:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 11:59:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 11:59:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 12:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 13:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 13:42:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 13:42:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 13:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 13:43:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 13:43:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 13:44:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 13:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 14:08:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 14:08:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 15:13:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 15:20:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 15:20:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 15:20:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 15:20:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 16:31:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 16:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 16:31:58 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-26 17:03:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 18:15:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:15:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:15:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:15:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:15:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:16:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:16:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:18:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:18:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:24:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:24:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:27:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:27:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:28:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:28:34 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:31:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:31:56 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:34:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:34:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:35:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:35:50 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:37:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:37:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:38:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:38:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:41:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:41:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:42:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 18:42:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 18:42:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:42:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:44:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 18:45:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:45:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:46:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:46:50 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:48:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:48:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:49:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:49:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:50:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 18:50:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 18:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 19:27:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:28:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:30:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:30:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:33:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:33:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:33:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:33:43 --> Query error: Commands out of sync; you can't run this command now - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1695737023
WHERE `id` = 'cf52cc9f8a2f40b359ef05cc30199e01217908cf'
ERROR - 2023-09-26 19:33:43 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('2335b289493450cf6070b8cb2b0dc242') AS ci_session_lock
ERROR - 2023-09-26 19:33:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:34:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:34:32 --> Query error: Commands out of sync; you can't run this command now - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1695737072, `data` = '__ci_last_regenerate|i:1695736987;user_id|s:1:\"1\";role_id|s:1:\"1\";role|s:5:\"Admin\";name|s:7:\"admin .\";admin_login|s:1:\"1\";last_page|s:8:\"chapters\";'
WHERE `id` = 'cf52cc9f8a2f40b359ef05cc30199e01217908cf'
ERROR - 2023-09-26 19:34:32 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('2335b289493450cf6070b8cb2b0dc242') AS ci_session_lock
ERROR - 2023-09-26 19:35:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:36:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:37:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:37:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:38:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:38:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:39:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:39:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:40:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:41:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:41:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:42:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:42:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:43:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:43:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:44:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:44:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:45:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:46:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:46:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:47:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:47:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:48:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:48:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:49:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:50:16 --> Query error: Commands out of sync; you can't run this command now - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1695738016
WHERE `id` = 'd34b869f449891ac8e1637358bd3dcbc37ecf0db'
ERROR - 2023-09-26 19:50:16 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('73de2dd4fe9aa10f2c2c7c50a9ee5b1b') AS ci_session_lock
ERROR - 2023-09-26 19:50:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:50:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:54:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:54:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:54:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 19:54:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:54:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 19:54:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:54:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 19:58:29 --> 404 Page Not Found: Nf_trackingphp/index
ERROR - 2023-09-26 19:58:29 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-09-26 19:58:29 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-09-26 19:58:29 --> 404 Page Not Found: Atomlibphp/index
ERROR - 2023-09-26 19:58:29 --> 404 Page Not Found: Ninjaphp/index
ERROR - 2023-09-26 19:59:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 19:59:19 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:02:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:02:32 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:03:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:03:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:08:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:08:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:09:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:09:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:11:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:11:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:12:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:12:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:13:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:13:54 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:15:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:15:21 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:18:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:18:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:19:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 20:19:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 20:19:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:19:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 20:21:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:21:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-26 20:21:44 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-26 21:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 21:13:15 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-26 21:13:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-26 21:14:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 21:14:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 21:14:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-26 21:38:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 21:38:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-26 21:38:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 21:57:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 22:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 22:04:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 22:57:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 23:02:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-26 23:03:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 23:03:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-26 23:03:10 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-26 23:31:54 --> 404 Page Not Found: Assets/frontend
