<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-11 01:51:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 01:51:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 01:51:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 01:51:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 02:44:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 05:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 07:49:01 --> 404 Page Not Found: Git/index
ERROR - 2023-07-11 08:07:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 09:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-11 09:07:30 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-07-11 14:43:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 20:12:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 20:50:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 20:50:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 20:50:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-11 20:50:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 20:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-11 20:51:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-11 21:05:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
