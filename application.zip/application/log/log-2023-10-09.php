<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-09 00:16:37 --> 404 Page Not Found: Env/index
ERROR - 2023-10-09 01:10:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:10:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 01:35:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:36:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:37:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:51:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:51:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 01:56:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:56:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 01:57:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 01:57:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 02:06:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 02:06:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 02:08:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 02:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 03:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 03:41:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 03:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 04:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 04:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 04:30:18 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-09 04:30:23 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-09 04:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 04:30:33 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-09 04:30:39 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-09 04:30:45 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-09 04:30:50 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-09 04:30:55 --> 404 Page Not Found: Home/Log In
ERROR - 2023-10-09 04:31:01 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-09 04:31:01 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-09 06:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 06:34:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 06:34:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 06:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 06:55:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 06:55:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 06:56:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 06:56:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 06:59:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 06:59:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 07:01:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 07:01:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 07:52:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 08:06:22 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-10-09 08:06:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 08:06:23 --> 404 Page Not Found: Wp/index
ERROR - 2023-10-09 08:06:24 --> 404 Page Not Found: Bc/index
ERROR - 2023-10-09 08:06:24 --> 404 Page Not Found: Bk/index
ERROR - 2023-10-09 08:06:26 --> 404 Page Not Found: New/index
ERROR - 2023-10-09 08:06:26 --> 404 Page Not Found: Main/index
ERROR - 2023-10-09 08:06:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 08:37:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 08:37:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 08:37:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 10:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 10:18:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 10:18:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 11:22:13 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-09 11:22:13 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-09 11:28:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 11:28:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 11:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 11:29:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 11:29:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 11:35:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 11:36:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 11:43:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 11:43:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 12:29:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 12:29:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 12:33:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 12:33:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 13:25:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 13:26:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:23:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:23:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:23:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:23:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:23:31 --> 404 Page Not Found: Log/index
ERROR - 2023-10-09 14:23:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:23:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:32:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:37:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:38:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:38:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:38:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:38:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:39:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:39:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-09 14:40:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-09 14:40:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-09 14:40:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:40:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:41:14 --> 404 Page Not Found: Log/index
ERROR - 2023-10-09 14:42:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:42:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:42:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 14:42:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 14:55:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 15:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 15:23:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 15:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 15:47:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 15:47:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 15:47:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 15:52:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 15:52:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 15:52:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 16:32:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 16:32:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 16:39:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 16:39:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 16:41:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 16:41:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 16:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 16:46:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 16:46:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 16:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 17:30:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:30:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:30:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:30:46 --> 404 Page Not Found: Log/index
ERROR - 2023-10-09 17:31:21 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-10-09 17:31:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:31:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:31:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:31:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:32:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:32:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:32:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:32:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:32:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:33:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:34:27 --> 404 Page Not Found: Log/index
ERROR - 2023-10-09 17:34:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 17:34:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:34:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 17:53:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 18:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 19:25:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 19:25:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 19:25:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 19:44:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-09 19:46:31 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-09 19:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 20:18:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 20:18:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 21:25:19 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-09 21:30:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 21:30:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-09 21:40:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-09 21:40:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-09 21:44:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 21:44:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 21:47:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 21:47:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 21:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 21:48:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 21:48:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:00:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:00:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:00:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:07:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:07:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:07:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:17:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 22:30:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:30:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-09 22:35:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:35:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:40:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:42:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:44:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:44:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:47:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 22:48:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-09 22:49:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 23:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 23:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-09 23:47:40 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-10-09 23:47:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-10-09 23:48:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
