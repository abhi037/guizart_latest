<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-17 08:08:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-17 10:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-17 19:40:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-17 19:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-17 19:41:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
