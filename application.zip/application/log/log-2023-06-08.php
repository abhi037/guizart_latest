<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-08 05:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-08 05:42:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 06:15:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 06:24:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 06:27:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 07:00:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 08:43:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 08:43:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 09:12:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 09:33:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 09:33:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 16:26:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 16:26:03 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-06-08 16:26:03 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-06-08 16:26:03 --> 404 Page Not Found: Readmehtml/index
ERROR - 2023-06-08 16:26:03 --> 404 Page Not Found: Licensetxt/index
ERROR - 2023-06-08 16:26:04 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-06-08 16:26:04 --> 404 Page Not Found: Wp/index
ERROR - 2023-06-08 16:26:04 --> 404 Page Not Found: Backup/index
ERROR - 2023-06-08 21:07:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 21:07:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-08 21:07:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 21:07:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 21:08:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-08 21:08:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 21:09:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 21:10:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-08 21:10:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 23:05:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 23:05:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 23:05:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 23:05:24 --> 404 Page Not Found: Log/index
ERROR - 2023-06-08 23:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-08 23:05:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 23:05:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 23:05:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-08 23:05:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 23:05:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-08 23:05:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 23:05:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-08 23:06:01 --> 404 Page Not Found: Assets/frontend
