<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-28 02:45:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 04:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 11:08:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 12:50:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 12:51:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 12:51:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-28 12:51:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-28 13:21:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 19:02:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 19:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-28 19:03:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 19:04:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 19:05:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 19:05:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-28 19:05:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-28 23:38:24 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-06-28 23:38:24 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-06-28 23:38:26 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-06-28 23:38:26 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-06-28 23:38:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-06-28 23:38:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-06-28 23:38:29 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-06-28 23:38:29 --> 404 Page Not Found: Wp-content/upgrade-functions.php
ERROR - 2023-06-28 23:38:31 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-06-28 23:38:31 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-06-28 23:38:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-06-28 23:38:33 --> 404 Page Not Found: Wp-content/plugins
