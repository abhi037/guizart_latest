<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-13 01:41:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 02:55:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 06:02:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 06:02:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 06:02:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 06:02:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 13:01:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 13:01:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 13:01:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 13:01:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 13:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-13 13:49:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 13:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 14:18:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:18:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:18:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:18:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 14:19:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:19:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:19:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:19:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:19:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:23:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:24:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:24:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:21 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 14:24:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:24:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:24:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:30:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:30:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:31:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:11 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 14:31:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:31:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:33:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:33:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:34:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:35:06 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 14:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:35:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:35:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:35:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:35:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:35:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:35:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:36:00 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 14:36:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 14:36:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:36:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:36:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:36:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:36:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:36:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:36:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:38:02 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-13 14:38:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:38:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:38:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:38:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:38:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:39:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:41:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:41:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:41:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:43:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:43:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:43:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:43:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:43:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:44:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:44:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:44:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:44:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:44:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:45:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:45:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:46:04 --> Severity: Notice --> Undefined index: cupon /home4/demouake/public_html/application/controllers/Checkout.php 238
ERROR - 2023-05-13 14:46:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 564
ERROR - 2023-05-13 14:52:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:52:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:52:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:52:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:53:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:53:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:53:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:53:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:55:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 14:55:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:55:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:55:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:55:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:56:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:56:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:56:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:10 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 14:57:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:57:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 14:57:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 14:57:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:02:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:02:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:02:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:02:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:02:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:03:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:03:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:03:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:03:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:03:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:03:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:03:57 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 15:04:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:04:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:04:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:04:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:04:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:04:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:04:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:04:35 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 15:04:46 --> Severity: Notice --> Undefined variable: obj /home4/demouake/public_html/application/models/Crud_model.php 1682
ERROR - 2023-05-13 15:04:46 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home4/demouake/public_html/application/models/Crud_model.php 1682
ERROR - 2023-05-13 15:04:46 --> Severity: Notice --> Undefined variable: data /home4/demouake/public_html/application/models/Crud_model.php 1686
ERROR - 2023-05-13 15:04:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-05-13 15:05:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:08:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:54:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:54:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:54:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:55:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-13 15:55:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:55:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:55:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:55:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:58:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 15:58:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:31 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 15:58:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 15:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-13 15:58:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:01:38 --> Severity: Notice --> Undefined index: cupon /home4/demouake/public_html/application/controllers/Checkout.php 238
ERROR - 2023-05-13 16:01:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 564
ERROR - 2023-05-13 16:11:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:12:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:12:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:12:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:12:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:12:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:12:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 16:12:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:13:06 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:13:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:13:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:13:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:14:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:14:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:14:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:14:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:14:11 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:14:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:16:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:16:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:43 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:16:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:16:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:16:53 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:17:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:19:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:19:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:19:29 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:19:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:21:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:23:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 16:23:48 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-13 16:23:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:23:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:23:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:23:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:08 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:24:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 16:24:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:24:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:24:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:24:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:25:26 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:25:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:27:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 16:27:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:27:36 --> 404 Page Not Found: Log/index
ERROR - 2023-05-13 16:27:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 16:29:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 19:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 21:28:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 21:28:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 21:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 21:28:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 21:29:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 22:56:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-13 23:06:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 23:06:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 23:06:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 23:39:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 23:43:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-13 23:43:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 23:43:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-13 23:51:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
