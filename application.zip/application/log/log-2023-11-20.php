<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-20 00:10:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 00:10:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 00:33:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 00:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 00:42:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 00:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 01:09:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 01:09:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 01:18:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 01:18:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 01:37:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 01:37:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 02:02:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 02:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 02:03:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 02:09:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 02:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 02:29:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 02:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 02:54:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 03:14:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 03:14:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 03:16:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 03:19:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 03:19:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 03:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 03:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 04:59:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-20 05:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 05:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 05:47:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 05:47:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 05:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 05:58:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 05:58:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 06:24:15 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-11-20 06:24:15 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-20 06:46:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 06:46:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 06:56:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 06:56:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 06:59:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 06:59:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 07:09:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 07:37:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-20 07:53:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 07:54:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 07:54:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 07:54:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 07:54:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 08:16:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 08:16:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 08:17:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 08:59:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 09:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 09:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 11:33:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 11:33:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 11:44:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 11:44:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 12:31:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 12:31:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 12:36:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 12:43:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 12:43:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 13:01:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:01:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 13:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:07:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:07:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 13:07:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:08:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:08:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 13:08:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 13:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:41:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 13:41:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 14:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 14:50:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-20 15:23:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 15:23:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 15:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 15:40:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 15:43:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 15:57:45 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-20 15:57:46 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-20 15:57:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-11-20 15:57:49 --> 404 Page Not Found: Plugins/jquery-file-upload
ERROR - 2023-11-20 15:57:50 --> 404 Page Not Found: Resources/plugins
ERROR - 2023-11-20 15:57:50 --> 404 Page Not Found: Style/assets
ERROR - 2023-11-20 15:57:51 --> 404 Page Not Found: Assets/front
ERROR - 2023-11-20 15:57:52 --> 404 Page Not Found: Assets/admin
ERROR - 2023-11-20 15:57:53 --> 404 Page Not Found: Theme/assets
ERROR - 2023-11-20 15:57:54 --> 404 Page Not Found: Admin-assets/plugins
ERROR - 2023-11-20 15:57:55 --> 404 Page Not Found: Admin_assets/assets
ERROR - 2023-11-20 15:57:56 --> 404 Page Not Found: Backend/assets
ERROR - 2023-11-20 15:57:57 --> 404 Page Not Found: Js/jquery-file-upload
ERROR - 2023-11-20 15:57:58 --> 404 Page Not Found: Public/plugins
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-20 16:41:02 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 16:41:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 16:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-20 17:03:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 17:03:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 17:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 17:50:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 17:50:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 17:55:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 17:55:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 18:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 18:21:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 18:21:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 18:22:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 18:22:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 18:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 18:48:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 18:49:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 18:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 18:56:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 18:56:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 20:21:26 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-11-20 21:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 21:12:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 21:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 21:31:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 21:42:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 21:42:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 21:42:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 22:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 22:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 22:46:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 22:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-20 23:12:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 23:38:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 23:38:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 23:39:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 23:39:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-20 23:40:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 23:40:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-20 23:47:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 23:56:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-20 23:56:20 --> 404 Page Not Found: Assets/frontend
