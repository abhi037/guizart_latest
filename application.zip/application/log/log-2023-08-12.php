<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-12 00:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 00:03:06 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-08-12 00:03:08 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-08-12 00:03:10 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-08-12 00:03:12 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-08-12 00:03:14 --> 404 Page Not Found: Wsphp7/index
ERROR - 2023-08-12 00:03:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 00:03:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 00:03:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 00:03:20 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-08-12 00:03:22 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-12 00:03:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 00:03:26 --> 404 Page Not Found: Logphp/index
ERROR - 2023-08-12 00:03:28 --> 404 Page Not Found: Wp-admin/about.php
ERROR - 2023-08-12 00:03:30 --> 404 Page Not Found: Cgi-bin/wp-sigunq.php
ERROR - 2023-08-12 00:03:32 --> 404 Page Not Found: Wp-content/about.php
ERROR - 2023-08-12 00:03:34 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-12 00:03:36 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-12 00:03:38 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-12 00:03:39 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-12 00:03:40 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-12 00:03:42 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-12 00:03:42 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-12 00:03:44 --> 404 Page Not Found: My1php/index
ERROR - 2023-08-12 00:03:45 --> 404 Page Not Found: Cgi-bin/my1.php
ERROR - 2023-08-12 00:03:48 --> 404 Page Not Found: Cjfunsphp/index
ERROR - 2023-08-12 00:03:50 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-12 00:03:51 --> 404 Page Not Found: Congphp/index
ERROR - 2023-08-12 00:03:52 --> 404 Page Not Found: Css/index.php
ERROR - 2023-08-12 00:03:53 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-08-12 00:03:55 --> 404 Page Not Found: Stphp/index
ERROR - 2023-08-12 00:24:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 00:24:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 00:31:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 01:00:09 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-08-12 01:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 01:05:25 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-12 01:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 01:25:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 01:25:36 --> 404 Page Not Found: Congphp/index
ERROR - 2023-08-12 01:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 02:02:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:02:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:03:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:03:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:04:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:04:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 02:39:21 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-12 02:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 02:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 03:28:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 03:28:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 05:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 05:49:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 05:49:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 05:51:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 06:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 06:37:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 07:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 07:02:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 07:02:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 07:43:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 08:05:02 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-12 08:14:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 08:14:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-12 08:14:08 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-12 08:14:10 --> 404 Page Not Found: Wp-includes/IXR
ERROR - 2023-08-12 08:14:12 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-08-12 08:14:13 --> 404 Page Not Found: Wp-consarphp/index
ERROR - 2023-08-12 08:14:15 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-08-12 08:14:17 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-12 08:14:19 --> 404 Page Not Found: Bitrix/admin
ERROR - 2023-08-12 08:14:21 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-08-12 08:14:23 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-12 08:14:25 --> 404 Page Not Found: Admin-headephp/index
ERROR - 2023-08-12 08:14:26 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2023-08-12 08:14:28 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-08-12 08:14:29 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-08-12 08:14:30 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-08-12 08:14:32 --> 404 Page Not Found: Adminfunsphp/index
ERROR - 2023-08-12 09:56:59 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-08-12 09:57:40 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-12 09:58:30 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-08-12 09:58:54 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-08-12 10:00:03 --> 404 Page Not Found: Env/index
ERROR - 2023-08-12 10:12:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 10:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 10:17:41 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-08-12 10:17:41 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-12 10:17:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 11:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 12:20:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 12:20:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 12:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 12:51:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 12:51:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 13:00:10 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-12 14:12:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 14:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 14:55:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 14:57:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 15:40:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 15:40:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 16:30:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 16:30:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 16:53:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 18:06:48 --> 404 Page Not Found: Wp-content/wp-1ogin_bak.php
ERROR - 2023-08-12 18:13:28 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-08-12 18:13:28 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 18:16:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 18:16:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 18:22:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 19:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 19:28:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 19:29:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 19:38:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 19:38:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 20:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-12 20:11:41 --> 404 Page Not Found: Home/about_us
ERROR - 2023-08-12 20:26:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 20:26:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 20:26:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 20:26:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-12 20:51:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 20:51:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-12 21:42:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 21:43:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 21:43:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 21:45:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 23:02:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 23:02:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 23:02:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-12 23:52:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-12 23:52:38 --> 404 Page Not Found: Assets/frontend
