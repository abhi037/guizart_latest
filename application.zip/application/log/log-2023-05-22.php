<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-22 07:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-22 07:12:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 07:13:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 07:13:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 07:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-22 10:24:46 --> 404 Page Not Found: Adminerphp/index
ERROR - 2023-05-22 17:25:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 17:25:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:25:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:28:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 17:28:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:28:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:57:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 17:57:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:57:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:58:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 17:58:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 17:58:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-22 20:03:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 20:03:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-22 20:03:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 20:03:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 20:04:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-22 22:55:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-22 22:55:55 --> 404 Page Not Found: Well-known/traffic-advice
