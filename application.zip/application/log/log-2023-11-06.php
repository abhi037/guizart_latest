<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 01:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 01:34:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 01:39:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 01:39:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 01:48:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 01:48:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 01:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 02:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 02:12:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 02:12:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 02:12:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 02:36:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 02:36:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 02:36:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 02:36:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 02:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 03:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 03:03:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 03:03:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 03:16:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 03:16:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 04:02:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 04:02:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 04:14:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 04:15:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 04:39:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 04:40:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 04:41:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 04:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 05:13:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 05:14:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 05:21:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 05:21:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 05:21:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 05:27:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 05:58:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 06:07:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 06:28:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:20 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:21 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 06:28:22 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:22 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 06:28:39 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:57 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:28:58 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:16 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:17 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 06:29:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 06:46:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 07:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 07:00:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 07:00:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 07:02:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 07:02:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 07:06:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 07:06:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 07:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 07:56:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 08:01:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-06 08:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 08:25:20 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-06 08:32:39 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-06 08:56:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 08:56:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 08:58:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 09:02:44 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-06 09:11:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 09:11:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 09:21:56 --> 404 Page Not Found: Env/index
ERROR - 2023-11-06 09:32:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 09:32:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 09:44:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 10:10:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 10:10:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 10:35:26 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-06 11:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 11:41:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 11:41:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 11:41:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 11:48:44 --> 404 Page Not Found: Env/index
ERROR - 2023-11-06 11:48:52 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2023-11-06 11:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 12:04:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 12:04:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 12:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 12:15:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 12:15:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 12:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 13:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 14:14:45 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-06 14:15:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 14:15:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 14:16:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 14:16:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 14:16:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 14:26:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 14:26:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 14:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 14:41:52 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-11-06 14:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 14:42:03 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-11-06 14:42:07 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-11-06 14:42:12 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-11-06 15:01:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 15:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 15:14:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 15:14:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 15:24:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 15:24:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 15:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 16:01:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:01:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:05:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:05:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:05:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:13:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:13:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 16:19:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 16:23:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 16:23:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 17:01:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:01:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:02:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:05:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 17:05:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 17:07:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 17:07:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 17:07:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 17:07:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 17:11:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 17:11:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 17:28:18 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 17:33:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 17:33:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 18:15:09 --> 404 Page Not Found: Env/index
ERROR - 2023-11-06 18:15:10 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-11-06 18:42:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 18:42:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 19:06:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 19:06:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 19:06:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 19:08:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 19:08:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 19:08:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 19:36:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 19:38:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 19:38:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 19:39:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 19:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 19:43:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 19:43:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 20:07:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:08:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 20:08:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 20:08:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 20:08:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:08:32 --> 404 Page Not Found: Log/index
ERROR - 2023-11-06 20:08:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:27:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:28:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:30:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:30:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 20:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 20:43:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 21:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:03:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:06:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:06:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:08:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 21:08:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 21:08:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 21:08:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:14:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:14:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:14:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:14:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 21:37:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:37:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:47:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 21:47:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 21:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-06 22:02:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 22:02:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 22:07:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 22:09:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 22:09:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 22:36:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 22:36:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 22:46:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 22:57:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 22:57:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-06 23:38:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 23:38:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-06 23:38:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:43:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:03 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 23:44:04 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:06 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:06 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:27 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:50 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:44:51 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:10 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:10 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:11 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:45:59 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:01 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-06 23:46:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 23:46:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:46:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:46:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 23:47:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-06 23:47:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-06 23:50:37 --> 404 Page Not Found: Robotstxt/index
