<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-22 00:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 00:11:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 00:11:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 00:19:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 00:19:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 00:49:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 00:49:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 00:49:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 01:09:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 01:09:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 01:17:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 01:17:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 02:19:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 02:19:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 02:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 02:31:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 02:31:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 02:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 02:52:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 02:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 03:01:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 03:02:43 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-11-22 03:02:43 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-22 03:07:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 03:09:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 03:25:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 03:25:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 04:02:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 04:02:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 04:03:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 04:03:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 04:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 04:59:23 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-22 05:36:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:13:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 06:30:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 06:47:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:47:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 06:53:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:53:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 06:54:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 06:59:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 06:59:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 07:09:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 07:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 07:12:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 07:14:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 07:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 07:47:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 07:52:23 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-22 07:59:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 07:59:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 08:11:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 08:11:29 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-11-22 08:11:30 --> 404 Page Not Found: Wp/index
ERROR - 2023-11-22 08:11:31 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-11-22 08:11:32 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-11-22 08:11:33 --> 404 Page Not Found: Blog/index
ERROR - 2023-11-22 08:11:34 --> 404 Page Not Found: New/index
ERROR - 2023-11-22 08:11:36 --> 404 Page Not Found: Newsite/index
ERROR - 2023-11-22 08:11:37 --> 404 Page Not Found: Test/index
ERROR - 2023-11-22 08:11:37 --> 404 Page Not Found: Core/index
ERROR - 2023-11-22 08:11:39 --> 404 Page Not Found: Testing/index
ERROR - 2023-11-22 08:11:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-22 08:41:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-22 08:41:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-22 08:53:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 08:53:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 08:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 09:28:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 09:28:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 09:28:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 10:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-22 11:58:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:32:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:32:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:32:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 12:32:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-22 12:32:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:33:00 --> 404 Page Not Found: Log/index
ERROR - 2023-11-22 12:33:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-11-22 12:33:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:33:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-22 12:33:23 --> 404 Page Not Found: Assets/frontend
