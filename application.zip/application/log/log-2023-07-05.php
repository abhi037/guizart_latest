<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-05 01:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-05 01:22:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-05 07:29:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-05 09:21:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-05 14:49:05 --> 404 Page Not Found: Well-known/traffic-advice
