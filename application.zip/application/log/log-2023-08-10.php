<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 00:16:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 00:16:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 00:36:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 00:36:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 00:40:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 00:40:15 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-10 00:40:16 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-08-10 00:40:16 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-08-10 00:40:16 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-08-10 00:40:16 --> 404 Page Not Found: Wp-loadphp/index
ERROR - 2023-08-10 00:40:17 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-10 00:40:17 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-10 00:40:17 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-08-10 00:40:18 --> 404 Page Not Found: Cache/indexx.php
ERROR - 2023-08-10 00:40:18 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-10 00:40:18 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-10 00:40:19 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-10 01:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 01:09:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 01:09:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 01:12:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 01:12:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 02:10:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 02:10:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 02:11:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 02:11:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 02:53:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 02:53:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 03:43:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 03:46:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 03:46:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 03:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 03:54:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 03:54:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 04:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 04:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 04:49:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 06:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 06:38:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 06:38:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 07:27:31 --> 404 Page Not Found: Env/index
ERROR - 2023-08-10 07:34:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-10 07:43:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 08:01:21 --> 404 Page Not Found: Env/index
ERROR - 2023-08-10 08:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 09:46:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:49:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:50:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:50:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:50:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:51:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 09:51:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 10:07:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 10:21:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 10:22:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 10:22:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 11:33:39 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-10 11:39:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 11:43:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 11:45:38 --> 404 Page Not Found: Congphp/index
ERROR - 2023-08-10 11:45:43 --> 404 Page Not Found: Stphp/index
ERROR - 2023-08-10 11:45:48 --> 404 Page Not Found: Css/index.php
ERROR - 2023-08-10 11:45:55 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-08-10 11:57:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 11:57:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 11:57:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 11:58:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 11:58:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 11:59:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 12:04:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 12:04:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 12:06:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 12:06:38 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-08-10 12:06:39 --> 404 Page Not Found: Wp/index
ERROR - 2023-08-10 12:06:40 --> 404 Page Not Found: Blog/index
ERROR - 2023-08-10 12:06:41 --> 404 Page Not Found: New/index
ERROR - 2023-08-10 12:06:42 --> 404 Page Not Found: Test/index
ERROR - 2023-08-10 12:06:43 --> 404 Page Not Found: Main/index
ERROR - 2023-08-10 12:06:44 --> 404 Page Not Found: Testing/index
ERROR - 2023-08-10 12:10:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 12:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 12:32:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 12:36:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 12:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 12:52:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 13:33:09 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-08-10 13:33:09 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-10 13:41:30 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-10 13:42:03 --> 404 Page Not Found: Sites/default
ERROR - 2023-08-10 13:42:09 --> 404 Page Not Found: Admin/controller
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 13:44:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 13:44:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 14:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 14:04:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 14:04:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 14:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 14:56:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 14:57:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 15:23:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 15:23:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 16:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 17:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 18:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 18:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 18:34:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 18:34:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 18:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 18:57:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 18:57:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-10 19:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 19:17:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-10 19:17:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-10 19:17:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 19:17:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-10 19:50:35 --> 404 Page Not Found: Env/index
ERROR - 2023-08-10 19:50:35 --> 404 Page Not Found: Conf/.env
ERROR - 2023-08-10 19:50:36 --> 404 Page Not Found: Wp-content/.env
ERROR - 2023-08-10 19:50:37 --> 404 Page Not Found: Wp-admin/.env
ERROR - 2023-08-10 19:50:38 --> 404 Page Not Found: Library/.env
ERROR - 2023-08-10 19:50:38 --> 404 Page Not Found: New/.env
ERROR - 2023-08-10 19:50:39 --> 404 Page Not Found: Vendor/.env
ERROR - 2023-08-10 19:50:41 --> 404 Page Not Found: Local/.env
ERROR - 2023-08-10 19:50:41 --> 404 Page Not Found: Api/.env
ERROR - 2023-08-10 19:50:42 --> 404 Page Not Found: Blog/.env
ERROR - 2023-08-10 19:50:42 --> 404 Page Not Found: Crm/.env
ERROR - 2023-08-10 19:50:43 --> 404 Page Not Found: Admin/.env
ERROR - 2023-08-10 19:50:43 --> 404 Page Not Found: Laravel/.env
ERROR - 2023-08-10 19:50:44 --> 404 Page Not Found: App/.env
ERROR - 2023-08-10 19:50:45 --> 404 Page Not Found: App/config
ERROR - 2023-08-10 19:50:45 --> 404 Page Not Found: Apps/.env
ERROR - 2023-08-10 19:50:46 --> 404 Page Not Found: Audio/.env
ERROR - 2023-08-10 19:50:46 --> 404 Page Not Found: Cgi-bin/.env
ERROR - 2023-08-10 19:50:47 --> 404 Page Not Found: Backend/.env
ERROR - 2023-08-10 19:50:47 --> 404 Page Not Found: Src/.env
ERROR - 2023-08-10 19:50:48 --> 404 Page Not Found: Base/.env
ERROR - 2023-08-10 19:50:49 --> 404 Page Not Found: Core/.env
ERROR - 2023-08-10 19:50:49 --> 404 Page Not Found: Vendor/laravel
ERROR - 2023-08-10 19:50:50 --> 404 Page Not Found: Storage/.env
ERROR - 2023-08-10 19:50:50 --> 404 Page Not Found: Protected/.env
ERROR - 2023-08-10 19:50:51 --> 404 Page Not Found: Newsite/.env
ERROR - 2023-08-10 19:50:51 --> 404 Page Not Found: Www/.env
ERROR - 2023-08-10 19:50:52 --> 404 Page Not Found: Sites/all
ERROR - 2023-08-10 19:50:52 --> 404 Page Not Found: Database/.env
ERROR - 2023-08-10 19:50:53 --> 404 Page Not Found: Public/.env
ERROR - 2023-08-10 20:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 21:14:55 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-10 21:14:57 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-10 21:14:59 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-10 21:15:01 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-10 22:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-10 22:28:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 22:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 22:48:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 22:48:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 22:48:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 22:48:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 23:17:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 23:17:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 23:18:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 23:19:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-10 23:45:38 --> 404 Page Not Found: Env/index
ERROR - 2023-08-10 23:45:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
