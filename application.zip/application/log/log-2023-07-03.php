<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-03 00:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-03 00:42:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 07:54:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 08:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-03 08:23:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 08:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-03 08:23:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-03 10:45:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 10:45:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-03 13:51:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-03 21:49:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 21:50:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-03 21:50:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 21:50:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 21:50:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 21:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-03 21:51:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-03 21:52:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-03 21:52:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
