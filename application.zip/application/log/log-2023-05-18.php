<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-18 00:51:30 --> 404 Page Not Found: Git/config
ERROR - 2023-05-18 04:31:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 04:32:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-18 04:32:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 05:43:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 05:43:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-18 07:16:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 12:56:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 20:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-18 20:02:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-18 20:14:17 --> 404 Page Not Found: Faviconico/index
