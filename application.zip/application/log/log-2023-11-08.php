<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-08 00:30:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-08 00:30:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-08 00:57:02 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-08 01:03:00 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-08 01:03:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 01:15:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 01:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 01:35:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 01:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 02:11:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:11:22 --> 404 Page Not Found: Cjfunsphp/index
ERROR - 2023-11-08 02:11:22 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-11-08 02:11:22 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-11-08 02:11:23 --> 404 Page Not Found: Stphp/index
ERROR - 2023-11-08 02:11:23 --> 404 Page Not Found: My1php/index
ERROR - 2023-11-08 02:36:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:41:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:45:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:47:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:47:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 02:58:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 02:58:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 02:59:28 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-11-08 03:03:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 03:03:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 03:24:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 03:24:16 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-11-08 03:24:17 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-11-08 03:24:18 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-11-08 03:24:18 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-11-08 03:24:18 --> 404 Page Not Found: Eephp/index
ERROR - 2023-11-08 03:24:18 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-11-08 03:24:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 03:24:19 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-11-08 03:24:19 --> 404 Page Not Found: Installphp/index
ERROR - 2023-11-08 03:24:19 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-11-08 03:24:19 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-11-08 03:24:19 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Css/install.php
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-11-08 03:24:20 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-11-08 03:24:21 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-11-08 03:24:21 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 03:24:21 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-11-08 03:30:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 03:45:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:01:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:01:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 04:10:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:10:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:11:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:11:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:11:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:11:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:11:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:15:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 04:20:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:20:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 04:21:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:25:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 04:25:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 05:35:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 05:35:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 05:42:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 05:46:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 05:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 05:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 06:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 06:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 06:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 07:35:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 07:39:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 08:06:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 08:06:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 08:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 08:25:34 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-08 08:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 08:27:59 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-08 08:28:55 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-11-08 08:29:33 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-11-08 08:30:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 08:31:01 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 08:34:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 09:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 09:29:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 09:29:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 09:37:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 09:37:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 10:06:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 10:06:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 10:27:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 10:27:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 10:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 10:34:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-08 10:34:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-08 10:34:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-08 10:37:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 10:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 12:35:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 12:35:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 12:35:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 12:57:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 13:29:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 14:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 14:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 14:33:28 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-11-08 14:40:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 14:51:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 14:52:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 15:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 15:21:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:21:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 15:25:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:33:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:35:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:38:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:38:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 15:39:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:39:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 15:46:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 15:46:34 --> 404 Page Not Found: Cjfunsphp/index
ERROR - 2023-11-08 15:46:34 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-11-08 15:46:34 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-11-08 15:46:35 --> 404 Page Not Found: Stphp/index
ERROR - 2023-11-08 15:46:35 --> 404 Page Not Found: My1php/index
ERROR - 2023-11-08 16:19:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:20:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:20:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 16:24:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:24:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 16:32:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:32:55 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-08 16:32:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 16:32:56 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-11-08 16:32:56 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-08 16:32:56 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-11-08 16:32:57 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-11-08 16:32:57 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-11-08 16:32:57 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-11-08 16:32:58 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-11-08 16:32:58 --> 404 Page Not Found: Eephp/index
ERROR - 2023-11-08 16:32:58 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-11-08 16:32:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 16:32:59 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-11-08 16:32:59 --> 404 Page Not Found: Installphp/index
ERROR - 2023-11-08 16:33:00 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-11-08 16:33:00 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-11-08 16:33:00 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-11-08 16:33:01 --> 404 Page Not Found: Css/install.php
ERROR - 2023-11-08 16:33:01 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-11-08 16:33:01 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-11-08 16:33:02 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-11-08 16:33:02 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-11-08 16:33:02 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-11-08 16:33:03 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-11-08 16:33:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-08 16:33:03 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-11-08 16:33:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:33:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 16:37:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:37:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 16:39:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 16:39:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 18:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 18:10:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 18:10:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 18:12:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 18:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:45 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:46 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:46 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:46 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:53:47 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:53:47 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:41 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:42 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:43 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 18:54:43 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-11-08 18:54:44 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-11-08 19:23:01 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-11-08 19:23:01 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-08 19:36:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 19:36:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 19:37:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 19:46:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 19:46:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 20:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 20:31:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 20:44:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 20:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 21:12:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 21:12:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 21:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 21:44:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 21:44:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 21:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 22:11:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:11:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 22:43:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:44:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:44:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:45:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:45:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:46:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:46:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:48:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:48:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:49:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-08 22:51:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 22:55:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-08 23:21:08 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-08 23:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-08 23:35:46 --> 404 Page Not Found: Robotstxt/index
