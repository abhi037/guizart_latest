<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-16 00:17:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:18:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 00:22:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:22:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 00:24:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:24:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 00:29:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:29:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 00:29:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:29:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 00:35:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:35:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 00:35:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 01:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 02:06:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 02:06:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 02:08:01 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-16 02:11:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 02:11:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 03:23:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 03:41:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 03:50:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-16 04:51:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 04:51:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 05:42:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 05:42:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 06:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 06:02:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 06:02:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 06:02:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 06:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 06:06:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 06:06:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 06:39:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 06:40:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 06:40:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 07:00:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:01:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:08:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:08:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:23:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:23:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 07:31:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-16 07:44:44 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 07:44:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 07:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 07:49:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:49:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:49:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 07:50:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:51:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 07:51:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 08:06:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 08:06:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 08:06:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 08:07:08 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2023-10-16 08:49:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 08:49:04 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2023-10-16 08:49:05 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2023-10-16 09:09:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 10:08:42 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-10-16 10:08:42 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-10-16 10:08:43 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-10-16 10:08:43 --> 404 Page Not Found: Congphp/index
ERROR - 2023-10-16 10:08:44 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-16 10:12:37 --> 404 Page Not Found: Uploads/frontend
ERROR - 2023-10-16 10:30:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-16 11:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 11:02:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 11:02:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-16 11:27:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 11:27:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-16 11:32:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 11:32:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 11:41:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 11:41:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 11:42:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 11:42:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 12:17:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 12:17:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 12:18:12 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-16 12:18:13 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-10-16 12:18:13 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-10-16 12:18:14 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-10-16 12:18:15 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-10-16 12:31:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 12:31:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 12:32:16 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 12:32:21 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 12:44:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 12:44:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 12:56:56 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 12:57:01 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 13:07:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 13:07:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 13:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 13:14:57 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 13:15:01 --> 404 Page Not Found: Quizartzip/index
ERROR - 2023-10-16 13:16:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 13:16:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 13:29:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 13:29:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 13:43:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 13:43:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 13:52:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 14:00:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 14:00:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 14:00:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 14:02:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 14:06:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 14:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 15:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 15:26:43 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-10-16 15:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:46:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:46:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:46:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:47:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:47:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:48:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 15:48:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 16:11:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 16:11:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 16:17:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 16:17:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 16:21:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-16 16:21:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-10-16 16:48:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 16:48:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 16:48:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 16:48:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 17:02:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 17:10:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 17:10:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 17:47:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 18:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 18:09:09 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-10-16 18:09:10 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-16 18:09:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 18:21:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 18:32:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 18:32:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 18:32:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 18:32:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 18:42:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 18:42:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 18:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 18:57:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 18:57:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 19:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 19:30:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 19:30:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 19:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 19:31:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 19:40:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 19:40:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 19:57:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 20:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 21:28:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 21:28:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:28:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:29:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 21:29:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 21:29:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:29:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:29:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 21:29:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:30:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:30:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 21:32:46 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-16 21:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 21:59:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 21:59:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 22:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 22:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 22:05:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 22:59:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-16 23:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 23:41:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 23:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 23:51:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 23:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-16 23:57:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-16 23:58:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
