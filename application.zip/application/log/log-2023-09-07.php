<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-07 00:07:01 --> 404 Page Not Found: Env/index
ERROR - 2023-09-07 00:07:02 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-07 00:09:58 --> 404 Page Not Found: Env/index
ERROR - 2023-09-07 00:29:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:29:18 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-07 00:29:19 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-07 00:29:21 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-09-07 00:29:22 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-09-07 00:29:23 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-07 00:29:25 --> 404 Page Not Found: New/index
ERROR - 2023-09-07 00:29:28 --> 404 Page Not Found: Newsite/index
ERROR - 2023-09-07 00:29:30 --> 404 Page Not Found: Test/index
ERROR - 2023-09-07 00:29:31 --> 404 Page Not Found: Core/index
ERROR - 2023-09-07 00:29:33 --> 404 Page Not Found: Testing/index
ERROR - 2023-09-07 00:29:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:38:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 00:38:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:38:23 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-09-07 00:38:24 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-07 00:38:34 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-07 00:38:36 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-07 00:38:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:38:39 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-09-07 00:38:41 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-07 00:38:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 00:39:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 00:39:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 00:51:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 01:12:59 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-09-07 01:13:13 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-09-07 02:10:02 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-07 02:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 04:53:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-07 04:54:10 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-07 05:38:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 05:38:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 05:39:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 06:59:37 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-09-07 06:59:37 --> 404 Page Not Found: Feed/index
ERROR - 2023-09-07 06:59:37 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-07 06:59:37 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-07 06:59:38 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-07 06:59:38 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-07 06:59:38 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-07 06:59:38 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-09-07 06:59:38 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-07 06:59:39 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-09-07 06:59:39 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-07 06:59:39 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-07 06:59:39 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-07 06:59:39 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-07 06:59:40 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-07 07:27:41 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-07 07:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 07:27:42 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-07 07:27:42 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-07 07:27:43 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-07 07:27:45 --> 404 Page Not Found: New/index
ERROR - 2023-09-07 07:27:45 --> 404 Page Not Found: Main/index
ERROR - 2023-09-07 07:27:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 08:16:20 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-09-07 08:16:26 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-09-07 08:21:41 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-09-07 08:27:19 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-09-07 08:27:28 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-09-07 09:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 09:19:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 09:19:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 10:01:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 10:01:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 10:01:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 10:01:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 10:01:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 10:02:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 11:00:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 11:09:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:05:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:05:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:06:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:07:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:08:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:40:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 12:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 12:40:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 13:51:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 13:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 14:01:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 14:12:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 14:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 14:16:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 14:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 14:41:51 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-07 14:45:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 15:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 15:35:38 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-07 15:54:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 16:46:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 16:58:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 19:25:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 19:37:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 19:37:18 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-09-07 19:37:18 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-07 19:37:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 19:37:20 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-09-07 19:37:20 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-09-07 19:37:20 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-09-07 19:37:21 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-09-07 19:37:21 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-09-07 19:37:21 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-09-07 19:37:22 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2023-09-07 19:37:22 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-09-07 19:37:22 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-09-07 19:37:22 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-09-07 19:37:23 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-09-07 19:37:23 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-09-07 19:37:23 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-09-07 19:37:23 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-09-07 19:37:24 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-09-07 19:37:25 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-09-07 20:00:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 20:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 20:12:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 20:14:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 20:14:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 20:27:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 20:27:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-07 20:49:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-07 21:03:03 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-07 21:03:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-07 21:11:28 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-07 21:13:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-07 21:13:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-07 22:16:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:17:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 22:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-07 22:42:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 23:01:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 23:01:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-07 23:03:22 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-07 23:30:06 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-07 23:54:00 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
