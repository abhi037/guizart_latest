<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-18 00:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 00:16:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 00:17:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 00:27:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 00:28:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 00:56:45 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-11-18 01:16:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 01:16:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:26:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 01:26:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:32:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 01:32:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:32:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:34:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:52:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 01:53:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:56:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 01:56:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 01:56:39 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-18 01:56:43 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-18 01:56:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-11-18 01:56:48 --> 404 Page Not Found: Plugins/jquery-file-upload
ERROR - 2023-11-18 01:56:51 --> 404 Page Not Found: Resources/plugins
ERROR - 2023-11-18 01:56:53 --> 404 Page Not Found: Style/assets
ERROR - 2023-11-18 01:56:56 --> 404 Page Not Found: Assets/front
ERROR - 2023-11-18 01:56:58 --> 404 Page Not Found: Assets/admin
ERROR - 2023-11-18 01:57:01 --> 404 Page Not Found: Theme/assets
ERROR - 2023-11-18 01:57:03 --> 404 Page Not Found: Admin-assets/plugins
ERROR - 2023-11-18 01:57:05 --> 404 Page Not Found: Admin_assets/assets
ERROR - 2023-11-18 01:57:07 --> 404 Page Not Found: Backend/assets
ERROR - 2023-11-18 01:57:10 --> 404 Page Not Found: Js/jquery-file-upload
ERROR - 2023-11-18 01:57:14 --> 404 Page Not Found: Public/plugins
ERROR - 2023-11-18 02:00:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 02:00:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 02:08:10 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-11-18 02:08:11 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-11-18 02:31:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 02:42:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 02:42:38 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 02:46:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 02:46:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 03:26:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 03:26:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 05:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 05:58:51 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-18 06:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 06:09:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 06:09:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 06:24:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 06:24:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 06:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 06:41:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 06:41:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 06:48:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 06:48:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 06:57:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 07:12:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 07:14:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 07:14:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 07:16:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 07:24:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 07:24:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 08:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 08:06:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 09:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 09:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 09:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 09:23:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 11:28:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 11:28:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 11:39:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 11:39:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 12:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 12:01:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:01:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 12:06:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:06:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 12:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 12:27:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:27:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 12:29:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 12:38:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 12:38:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 12:38:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:39:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 12:39:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 12:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 12:46:22 --> 404 Page Not Found: Cdn-cgi/l
ERROR - 2023-11-18 13:25:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 13:25:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 13:26:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 15:09:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 15:20:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 15:20:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 15:42:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 15:43:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 15:43:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 16:01:33 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-18 16:01:34 --> 404 Page Not Found: Assets/global
ERROR - 2023-11-18 16:01:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-11-18 16:01:36 --> 404 Page Not Found: Plugins/jquery-file-upload
ERROR - 2023-11-18 16:01:37 --> 404 Page Not Found: Resources/plugins
ERROR - 2023-11-18 16:01:38 --> 404 Page Not Found: Style/assets
ERROR - 2023-11-18 16:01:39 --> 404 Page Not Found: Assets/front
ERROR - 2023-11-18 16:01:40 --> 404 Page Not Found: Assets/admin
ERROR - 2023-11-18 16:01:42 --> 404 Page Not Found: Theme/assets
ERROR - 2023-11-18 16:01:42 --> 404 Page Not Found: Admin-assets/plugins
ERROR - 2023-11-18 16:01:43 --> 404 Page Not Found: Admin_assets/assets
ERROR - 2023-11-18 16:01:44 --> 404 Page Not Found: Backend/assets
ERROR - 2023-11-18 16:01:45 --> 404 Page Not Found: Js/jquery-file-upload
ERROR - 2023-11-18 16:01:46 --> 404 Page Not Found: Public/plugins
ERROR - 2023-11-18 16:41:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 16:45:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 16:45:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 16:54:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 16:54:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 17:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 17:22:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 17:52:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 17:53:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 17:54:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 18:23:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 18:23:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 18:23:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 19:22:44 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 19:22:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 19:26:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-18 19:45:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 19:45:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-18 19:53:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-18 20:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 20:30:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 20:30:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 20:43:10 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-11-18 21:13:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 21:13:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 21:19:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 21:19:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 21:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-18 21:45:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 21:45:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 21:56:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 21:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 22:05:35 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-18 22:11:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 22:17:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-18 22:18:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-18 23:28:27 --> 404 Page Not Found: Robotstxt/index
