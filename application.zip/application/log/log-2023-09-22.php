<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-22 00:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 00:48:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 01:04:03 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-22 01:04:07 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-22 01:04:14 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-22 01:04:17 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-22 01:04:21 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-22 01:10:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 01:42:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-22 01:56:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 01:56:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 02:31:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-22 03:07:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 03:07:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 03:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 03:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 03:21:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 05:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 06:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 06:23:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 06:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 07:01:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:01:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:01:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:02:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:10:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:10:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 07:14:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 07:14:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-22 07:17:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 07:17:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 09:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 09:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 09:04:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:04:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:06:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:06:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:56:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:56:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 09:57:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 09:57:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 09:59:53 --> 404 Page Not Found: Log/index
ERROR - 2023-09-22 09:59:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 10:00:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 10:00:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 10:03:48 --> 404 Page Not Found: Log/index
ERROR - 2023-09-22 10:03:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 10:04:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 10:04:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-22 10:21:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 10:21:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 11:42:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 11:42:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:42:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:42:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:57:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 11:57:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:57:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:57:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 11:57:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:57:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:58:20 --> 404 Page Not Found: Log/index
ERROR - 2023-09-22 11:58:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 11:58:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:58:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 11:59:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 11:59:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 12:00:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 12:00:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 12:00:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 12:00:21 --> 404 Page Not Found: Log/index
ERROR - 2023-09-22 12:00:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:01:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:03:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 12:03:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 12:04:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:04:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:05:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:07:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:07:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:12:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:13:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:15:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:15:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:18:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:19:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:19:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:22:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:24:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:24:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 12:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 12:26:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 12:26:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 12:26:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:27:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:29:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:37:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:47:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:55:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:55:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:57:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:57:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:59:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 12:59:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:00:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:00:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:02:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:02:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:04:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:04:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:05:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:05:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:07:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:07:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:08:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:09:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:10:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 13:10:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 13:12:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:12:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:13:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:13:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:15:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:16:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:18:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:22:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:23:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:24:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:25:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-22 13:30:48 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-22 13:30:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 13:30:50 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-22 13:30:51 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-22 13:30:51 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-22 13:30:54 --> 404 Page Not Found: New/index
ERROR - 2023-09-22 13:30:55 --> 404 Page Not Found: Main/index
ERROR - 2023-09-22 13:30:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 13:35:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 13:58:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 14:33:43 --> 404 Page Not Found: Wp-json/wp
ERROR - 2023-09-22 14:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 14:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-22 14:42:42 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 14:42:42 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-22 14:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 14:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 14:50:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 14:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 14:54:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 14:54:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 15:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 15:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 15:40:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 15:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 15:40:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 15:42:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 15:53:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 15:55:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 15:55:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:04:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:04:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:07:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:07:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 16:10:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:10:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 16:16:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 16:16:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:17:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:18:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:18:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:31:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:31:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 16:32:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 17:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 17:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 17:20:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:20:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:22:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 17:29:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:29:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:52:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:55:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 17:56:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 18:05:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 18:18:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 19:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 19:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 20:14:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 20:14:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 20:15:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 20:48:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 20:48:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 20:48:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-22 21:28:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:28:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:28:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:29:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:31:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:31:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:31:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:32:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-22 21:42:35 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-22 22:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 23:02:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
