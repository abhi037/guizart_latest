<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-13 00:00:00 --> 404 Page Not Found: Temp/index
ERROR - 2023-09-13 00:00:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 00:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 00:40:51 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-13 00:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-13 00:58:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 00:58:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 01:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:24:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:24:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:24:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:25:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:25:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 01:25:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 03:02:55 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-13 03:03:01 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-13 03:03:05 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-13 03:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 04:33:33 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-13 04:33:37 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-09-13 04:33:42 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-09-13 04:33:48 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-09-13 04:33:53 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-13 04:33:58 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-09-13 04:34:01 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-13 04:34:05 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-13 04:34:22 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-09-13 04:34:28 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-13 04:34:32 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-13 04:34:36 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-13 04:34:40 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-13 04:34:48 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-09-13 05:03:13 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-13 05:34:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-13 05:34:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 05:34:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 05:46:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-13 06:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 06:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:03:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 06:05:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:05:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 06:06:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:06:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 06:14:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:14:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 06:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 06:23:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:40:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:40:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 06:42:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 07:08:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 07:21:37 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-13 07:21:37 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-13 09:03:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 09:11:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 09:25:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 09:33:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 09:42:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 10:54:08 --> 404 Page Not Found: Env/index
ERROR - 2023-09-13 10:59:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 11:00:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 12:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 12:21:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 12:25:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 12:25:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 12:33:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 12:34:45 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-13 12:35:08 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-13 12:35:11 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-13 12:35:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 12:40:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 12:42:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 12:43:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 12:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 13:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 13:21:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 13:27:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 13:27:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 13:41:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 13:41:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 13:48:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 13:49:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 13:49:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 13:49:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 15:45:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 15:45:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 15:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 15:58:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 16:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 18:03:48 --> 404 Page Not Found: Wp-json/wp
ERROR - 2023-09-13 18:03:50 --> 404 Page Not Found: Author-sitemapxml/index
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-13 18:23:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 18:23:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-13 18:29:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 18:29:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-13 18:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 18:50:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 18:50:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 18:59:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 18:59:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 19:29:48 --> 404 Page Not Found: Uploads/slider
ERROR - 2023-09-13 19:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 19:50:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 19:50:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 19:51:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 19:51:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 20:02:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 20:02:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 20:08:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 20:08:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-13 21:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 21:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 21:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 21:36:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 21:36:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 21:37:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 23:15:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 23:15:24 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-13 23:15:25 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-13 23:15:25 --> 404 Page Not Found: Old1/index
ERROR - 2023-09-13 23:15:26 --> 404 Page Not Found: Old2/index
ERROR - 2023-09-13 23:15:26 --> 404 Page Not Found: OLDSITE/index
ERROR - 2023-09-13 23:15:27 --> 404 Page Not Found: Beta/index
ERROR - 2023-09-13 23:15:27 --> 404 Page Not Found: Staging/index
ERROR - 2023-09-13 23:15:29 --> 404 Page Not Found: BKP/index
ERROR - 2023-09-13 23:15:29 --> 404 Page Not Found: Old-site/index
ERROR - 2023-09-13 23:15:30 --> 404 Page Not Found: Oldwebsite/index
ERROR - 2023-09-13 23:15:30 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-13 23:15:31 --> 404 Page Not Found: Dev/index
ERROR - 2023-09-13 23:15:32 --> 404 Page Not Found: Test/index
ERROR - 2023-09-13 23:15:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-13 23:15:33 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-09-13 23:15:34 --> 404 Page Not Found: Old_files/index
ERROR - 2023-09-13 23:15:34 --> 404 Page Not Found: Old/index
ERROR - 2023-09-13 23:15:35 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-13 23:15:36 --> 404 Page Not Found: BAK/index
