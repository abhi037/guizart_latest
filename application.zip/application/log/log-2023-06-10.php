<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-10 03:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-10 05:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-10 05:07:49 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-10 05:07:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-10 05:07:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 06:05:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 07:55:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 10:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 12:33:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 17:15:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 18:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-10 18:44:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-10 22:19:51 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-10 22:19:51 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-10 22:59:07 --> 404 Page Not Found: Wp-json/wp
ERROR - 2023-06-10 22:59:09 --> 404 Page Not Found: Author-sitemapxml/index
