<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-30 00:49:58 --> 404 Page Not Found: Env/index
ERROR - 2023-10-30 00:51:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 00:52:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 00:52:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 00:53:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 00:53:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 00:58:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 00:58:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 00:58:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 00:58:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 01:14:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 01:14:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 01:25:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 01:25:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 01:26:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 01:26:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 02:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 02:05:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 02:05:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 02:09:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 02:09:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 02:09:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 02:13:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 02:13:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 02:23:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 02:23:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 02:31:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 02:31:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 02:31:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 03:11:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 03:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 03:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 03:21:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 03:33:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 03:33:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 03:44:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 03:44:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 03:44:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 04:52:11 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-10-30 04:52:14 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-10-30 04:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 05:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 05:40:22 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-30 05:40:27 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-30 05:40:35 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-30 05:40:39 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-30 05:40:45 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-30 05:49:00 --> 404 Page Not Found: Env/index
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 06:15:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 06:15:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 06:15:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 06:42:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 06:42:07 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-30 06:42:08 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2023-10-30 06:42:09 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2023-10-30 06:42:11 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 06:58:02 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 06:58:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 06:58:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 06:58:41 --> 404 Page Not Found: Mshellphp/index
ERROR - 2023-10-30 07:06:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 07:06:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 07:14:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 07:14:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 07:28:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 07:28:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 07:28:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 07:52:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 08:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 08:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 08:17:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 08:17:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 08:34:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 08:34:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 08:34:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 08:39:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 08:39:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 09:16:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 09:16:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 09:17:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 09:17:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 09:17:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 09:17:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 09:38:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 09:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 10:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 10:04:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 10:44:01 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 10:47:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 10:47:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 10:47:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 11:24:23 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-30 11:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 11:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 11:53:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 11:53:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 11:53:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 11:53:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 12:04:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 12:04:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 12:12:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 12:12:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 12:13:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-includes/theme-compat
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 12:16:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/gecko-new.php
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-admin/raizoworm.php
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Libraries/legacy
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Libraries/phpmailer
ERROR - 2023-10-30 12:16:45 --> 404 Page Not Found: Libraries/vendor
ERROR - 2023-10-30 13:17:24 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-10-30 13:17:31 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-10-30 13:17:40 --> 404 Page Not Found: Wp-admin/index
ERROR - 2023-10-30 13:17:43 --> 404 Page Not Found: Well-knownold/index
ERROR - 2023-10-30 13:17:48 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-30 13:17:53 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 13:48:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 13:48:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 13:48:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 14:13:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 14:13:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 14:23:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 14:23:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 14:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 14:34:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 14:34:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 14:34:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 15:12:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 15:12:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 15:21:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 15:22:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 15:56:34 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 15:56:34 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 15:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 16:35:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 16:59:43 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-30 16:59:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 17:05:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 17:05:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 17:20:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 17:25:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 17:27:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 17:27:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 18:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 18:20:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 18:26:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 18:45:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 18:45:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 18:45:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 19:01:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 19:06:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 19:07:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 19:16:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 19:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 19:45:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 19:55:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 20:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 20:30:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 20:35:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 20:57:00 --> 404 Page Not Found: Env/index
ERROR - 2023-10-30 21:26:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:26:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:27:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:28:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:28:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:28:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:29:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:29:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 21:30:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:36:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 21:36:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 21:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 21:56:44 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 21:56:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 21:56:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 22:24:25 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-10-30 22:24:40 --> 404 Page Not Found: 1php/index
ERROR - 2023-10-30 22:24:42 --> 404 Page Not Found: 403php/index
ERROR - 2023-10-30 22:24:57 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-10-30 22:25:18 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-10-30 22:25:55 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-10-30 22:25:56 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-10-30 22:26:00 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-10-30 22:26:02 --> 404 Page Not Found: Upphp/index
ERROR - 2023-10-30 22:26:03 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-10-30 22:26:05 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-10-30 22:26:06 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-10-30 22:26:08 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-10-30 22:26:09 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-10-30 22:26:11 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-10-30 22:26:13 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-10-30 22:26:14 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-10-30 22:26:15 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-10-30 22:26:16 --> 404 Page Not Found: Mphp/index
ERROR - 2023-10-30 22:26:18 --> 404 Page Not Found: 503php/index
ERROR - 2023-10-30 22:26:19 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-10-30 22:26:21 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-10-30 22:26:22 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-10-30 22:26:23 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-10-30 22:26:25 --> 404 Page Not Found: Massphp/index
ERROR - 2023-10-30 22:26:26 --> 404 Page Not Found: 1337php/index
ERROR - 2023-10-30 22:26:28 --> 404 Page Not Found: 1877php/index
ERROR - 2023-10-30 22:26:29 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-10-30 22:26:31 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-10-30 22:26:32 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-10-30 22:26:33 --> 404 Page Not Found: Index2php/index
ERROR - 2023-10-30 22:26:35 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-10-30 22:26:36 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-10-30 22:26:38 --> 404 Page Not Found: Marphp/index
ERROR - 2023-10-30 22:26:39 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-10-30 22:26:40 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-10-30 22:26:42 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-10-30 22:26:43 --> 404 Page Not Found: Shphp/index
ERROR - 2023-10-30 22:26:45 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-10-30 22:26:47 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-10-30 22:26:48 --> 404 Page Not Found: Symphp/index
ERROR - 2023-10-30 22:26:49 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-10-30 22:26:51 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-10-30 22:26:52 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-10-30 22:26:53 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-10-30 22:26:54 --> 404 Page Not Found: Anphp/index
ERROR - 2023-10-30 22:26:56 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-10-30 22:26:57 --> 404 Page Not Found: Xphp/index
ERROR - 2023-10-30 22:26:59 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-10-30 22:27:01 --> 404 Page Not Found: Byphp/index
ERROR - 2023-10-30 22:27:02 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-10-30 22:27:04 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-10-30 22:27:05 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-10-30 22:27:07 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-10-30 22:27:08 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-10-30 22:27:09 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-10-30 22:27:11 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-10-30 22:27:12 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-10-30 22:27:14 --> 404 Page Not Found: Userphp/index
ERROR - 2023-10-30 22:27:15 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-10-30 22:27:16 --> 404 Page Not Found: Zphp/index
ERROR - 2023-10-30 22:27:18 --> 404 Page Not Found: Chphp/index
ERROR - 2023-10-30 22:27:20 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-10-30 22:27:21 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-10-30 22:27:23 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-10-30 22:27:24 --> 404 Page Not Found: Madphp/index
ERROR - 2023-10-30 22:27:25 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-10-30 22:27:27 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-10-30 22:27:29 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-10-30 22:27:30 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-10-30 22:27:32 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-10-30 22:27:33 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-10-30 22:27:35 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-10-30 22:27:36 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-10-30 22:27:38 --> 404 Page Not Found: Endphp/index
ERROR - 2023-10-30 22:27:40 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-10-30 22:27:41 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-10-30 22:27:43 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-10-30 22:27:45 --> 404 Page Not Found: __1975php/index
ERROR - 2023-10-30 22:27:46 --> 404 Page Not Found: Killphp/index
ERROR - 2023-10-30 22:27:47 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-10-30 22:27:49 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-10-30 22:27:50 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-10-30 22:27:51 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-10-30 22:27:54 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-10-30 22:27:55 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-10-30 22:27:57 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-10-30 22:27:58 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-10-30 22:27:59 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-10-30 22:28:01 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-10-30 22:28:02 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-10-30 22:28:03 --> 404 Page Not Found: Logphp/index
ERROR - 2023-10-30 22:28:05 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-10-30 22:28:06 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-10-30 22:28:08 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-10-30 22:28:09 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-10-30 22:28:10 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-10-30 22:28:13 --> 404 Page Not Found: Demophp/index
ERROR - 2023-10-30 22:28:14 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-10-30 22:28:16 --> 404 Page Not Found: Motophp/index
ERROR - 2023-10-30 22:28:18 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-10-30 22:28:19 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:28:21 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-10-30 22:28:22 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-10-30 22:28:23 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-10-30 22:28:25 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-10-30 22:28:28 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-10-30 22:28:30 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-10-30 22:28:31 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-10-30 22:28:32 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-10-30 22:28:34 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-10-30 22:28:36 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-10-30 22:28:41 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-10-30 22:28:42 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-10-30 22:28:44 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-10-30 22:28:45 --> 404 Page Not Found: 1975php/index
ERROR - 2023-10-30 22:28:51 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-10-30 22:28:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:28:54 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-10-30 22:28:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:29:04 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-10-30 22:29:05 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-10-30 22:29:07 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:29:08 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-10-30 22:29:16 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-10-30 22:29:18 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-10-30 22:29:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 22:29:19 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-10-30 22:29:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 22:29:20 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-10-30 22:29:27 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-10-30 22:29:29 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-10-30 22:29:30 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-10-30 22:29:31 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-10-30 22:29:32 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-10-30 22:29:34 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-10-30 22:29:35 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-10-30 22:29:36 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-10-30 22:29:38 --> 404 Page Not Found: Mephp/index
ERROR - 2023-10-30 22:29:39 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-10-30 22:29:41 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-10-30 22:29:42 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-10-30 22:29:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:29:45 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-10-30 22:29:47 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-10-30 22:29:48 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-10-30 22:29:50 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-10-30 22:29:51 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-10-30 22:29:53 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-10-30 22:29:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:29:55 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:29:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:29:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:00 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:03 --> 404 Page Not Found: Sites/all
ERROR - 2023-10-30 22:30:05 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-10-30 22:30:06 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-10-30 22:30:07 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-10-30 22:30:10 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-10-30 22:30:11 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-10-30 22:30:13 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-10-30 22:30:14 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-10-30 22:30:16 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-10-30 22:30:17 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-10-30 22:30:19 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-10-30 22:30:20 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-10-30 22:30:21 --> 404 Page Not Found: Termphp/index
ERROR - 2023-10-30 22:30:23 --> 404 Page Not Found: Textphp/index
ERROR - 2023-10-30 22:30:24 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-10-30 22:30:25 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-10-30 22:30:27 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-10-30 22:30:28 --> 404 Page Not Found: Homephp/index
ERROR - 2023-10-30 22:30:30 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-10-30 22:30:31 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-10-30 22:30:33 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-10-30 22:30:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:36 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:30:38 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 22:30:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:41 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-10-30 22:30:42 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-10-30 22:30:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:45 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-10-30 22:30:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:30:53 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-10-30 22:30:54 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-10-30 22:30:56 --> 404 Page Not Found: 406php/index
ERROR - 2023-10-30 22:30:57 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 22:30:59 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-10-30 22:31:01 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-30 22:31:03 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-10-30 22:31:04 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:31:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:31:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:31:09 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:31:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:31:13 --> 404 Page Not Found: D7php/index
ERROR - 2023-10-30 22:31:15 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-10-30 22:31:16 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-30 22:31:17 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-10-30 22:31:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 22:31:20 --> 404 Page Not Found: Eephp/index
ERROR - 2023-10-30 22:31:21 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-10-30 22:31:24 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-30 22:31:26 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-10-30 22:31:27 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-10-30 22:31:29 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-10-30 22:31:30 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-10-30 22:31:32 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-10-30 22:31:35 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-30 22:31:37 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-10-30 22:31:38 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-30 22:31:39 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-30 22:31:40 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-10-30 22:31:42 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-30 22:31:43 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-10-30 22:31:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-30 23:05:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 23:05:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 23:20:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 23:21:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 23:24:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 23:27:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-30 23:27:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-30 23:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 23:33:02 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-30 23:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-30 23:33:13 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-10-30 23:33:19 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-30 23:33:25 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-30 23:33:31 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-30 23:33:37 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-30 23:33:44 --> 404 Page Not Found: Home/Log In
ERROR - 2023-10-30 23:33:50 --> 404 Page Not Found: Home/Log In
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:03 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:51 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:51 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:34:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:34:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:34 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:34 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:38 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:38 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:35:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:35:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:36:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:36:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:36:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:36:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-30 23:36:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-30 23:36:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
