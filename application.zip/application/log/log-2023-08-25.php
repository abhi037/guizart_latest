<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-25 00:44:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:44:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:45:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:45:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:45:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:47:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:47:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 00:53:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 00:53:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 01:31:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 01:34:22 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-08-25 01:34:22 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-25 02:18:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 02:18:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 02:18:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 02:18:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 02:18:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 02:18:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 02:35:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 02:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 02:42:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 03:58:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 03:58:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 05:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 05:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 05:27:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 05:38:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 05:38:33 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-08-25 06:07:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-25 06:28:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 06:28:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 06:41:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 06:41:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 06:45:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 06:45:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 06:49:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 06:49:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 07:48:32 --> 404 Page Not Found: Aws/credentials
ERROR - 2023-08-25 08:47:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 08:47:25 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-08-25 09:38:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 09:38:27 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('491ee14ae731f6042349cf3ccd18e2a5') AS ci_session_lock
ERROR - 2023-08-25 10:42:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 10:42:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 11:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 11:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 11:44:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 11:44:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 12:11:57 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-08-25 12:12:02 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-08-25 12:12:06 --> 404 Page Not Found: Xl2023xphp/index
ERROR - 2023-08-25 12:12:10 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-08-25 12:12:15 --> 404 Page Not Found: Xphp/index
ERROR - 2023-08-25 12:12:20 --> 404 Page Not Found: Xlphp/index
ERROR - 2023-08-25 12:12:25 --> 404 Page Not Found: Wp-admin/xl2023.php
ERROR - 2023-08-25 12:12:29 --> 404 Page Not Found: Wp-includes/xl2023.php
ERROR - 2023-08-25 12:12:38 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-08-25 12:12:44 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-25 12:12:49 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-08-25 12:12:54 --> 404 Page Not Found: Images/iR7SzrsOUEP.php
ERROR - 2023-08-25 12:12:58 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-25 12:13:04 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-25 12:13:09 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-25 12:13:14 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-25 12:13:22 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2023-08-25 12:13:26 --> 404 Page Not Found: Admin-headephp/index
ERROR - 2023-08-25 12:13:32 --> 404 Page Not Found: Cgi-bin/iR7SzrsOUEP.php
ERROR - 2023-08-25 12:13:37 --> 404 Page Not Found: Wp-content/xl2023.php
ERROR - 2023-08-25 12:13:43 --> 404 Page Not Found: Wp-content/xl2023.php
ERROR - 2023-08-25 12:13:49 --> 404 Page Not Found: IR7SzrsOUEPphp/index
ERROR - 2023-08-25 12:13:54 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-25 12:15:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 12:15:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 12:27:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 12:27:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 13:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 13:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 13:29:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-25 13:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 14:43:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-25 14:43:39 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-25 15:04:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:04:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:05:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:05:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:05:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:05:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:05:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:06:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:06:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:07:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:07:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:07:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:07:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:07:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:07:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:07:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:08:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:08:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:08:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:08:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:09:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:09:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:09:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:09:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:16:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:16:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:16:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:16:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:16:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:32:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:32:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:32:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:32:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:32:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:32:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:35:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:35:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:35:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:36:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:36:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:36:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:36:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:39:12 --> 404 Page Not Found: Log/index
ERROR - 2023-08-25 15:39:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 15:40:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 15:40:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:40:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:40:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:41:02 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-25 15:41:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:41:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:41:37 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 15:41:37 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 15:41:37 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 15:41:37 --> The path to the image is not correct.
ERROR - 2023-08-25 15:41:37 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 15:41:37 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692958297', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 15:41:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:41:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:43:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:43:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:43:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:45:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:45:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:46:14 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 15:46:14 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 15:46:14 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 15:46:14 --> The path to the image is not correct.
ERROR - 2023-08-25 15:46:14 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 15:46:14 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692958574', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 15:46:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 15:46:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:46:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:46:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:49:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:49:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:50:05 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 15:50:05 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 15:50:05 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 15:50:05 --> The path to the image is not correct.
ERROR - 2023-08-25 15:50:05 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 15:50:05 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692958805', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 15:50:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 15:50:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:50:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:50:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 15:57:01 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 15:57:01 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 15:57:01 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 15:57:01 --> The path to the image is not correct.
ERROR - 2023-08-25 15:57:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 15:57:01 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692959221', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 15:57:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 15:57:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 15:57:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:57:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:57:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 15:57:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:06:04 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 16:06:04 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 16:06:04 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 16:06:04 --> The path to the image is not correct.
ERROR - 2023-08-25 16:06:04 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 16:06:04 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692959764', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 16:06:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 16:06:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:06:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:06:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:06:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:08:18 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 16:08:18 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 16:08:18 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 16:08:18 --> The path to the image is not correct.
ERROR - 2023-08-25 16:08:18 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 16:08:18 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692959898', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 16:08:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:08:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:23:10 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 16:23:10 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 16:23:10 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 16:23:10 --> The path to the image is not correct.
ERROR - 2023-08-25 16:23:10 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 16:23:10 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692960790', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 16:23:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 16:23:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:23:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:23:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:23:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:26:22 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 16:26:22 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 16:26:22 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 16:26:22 --> The path to the image is not correct.
ERROR - 2023-08-25 16:26:22 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 16:26:22 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692960982', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 16:26:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 16:26:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:26:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:26:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:26:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:26:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:26:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:31:52 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-25 16:35:12 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1283
ERROR - 2023-08-25 16:35:12 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1284
ERROR - 2023-08-25 16:35:12 --> Severity: Notice --> Undefined index: gallery /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Admin.php 1286
ERROR - 2023-08-25 16:35:12 --> The path to the image is not correct.
ERROR - 2023-08-25 16:35:12 --> Your server does not support the GD function required to process this type of image.
ERROR - 2023-08-25 16:35:12 --> Query error: Column 'type' cannot be null - Invalid query: INSERT INTO `photos` (`image_name`, `type`, `position`, `ptext`, `htext`, `blink`, `status`) VALUES ('1692961512', NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2023-08-25 16:35:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-25 16:35:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:35:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:35:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:35:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:36:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:37:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:37:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:38:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:38:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:38:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:39:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:40:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:40:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:40:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:43:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 16:43:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 16:44:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 16:57:41 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-25 17:05:02 --> 404 Page Not Found: Env/index
ERROR - 2023-08-25 17:38:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 17:38:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 17:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 17:50:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 17:50:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 19:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 19:24:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 19:24:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 19:59:29 --> 404 Page Not Found: Env/index
ERROR - 2023-08-25 19:59:32 --> 404 Page Not Found: Env/index
ERROR - 2023-08-25 20:29:32 --> 404 Page Not Found: Env/index
ERROR - 2023-08-25 20:29:34 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-08-25 20:35:22 --> 404 Page Not Found: Https:/1.adorahuginn.gives
ERROR - 2023-08-25 22:05:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 22:14:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:14:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:21:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 22:21:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 22:25:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 22:25:28 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-08-25 22:25:29 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-25 22:25:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 22:25:32 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-08-25 22:25:32 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-08-25 22:25:33 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-08-25 22:25:34 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-08-25 22:25:34 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-08-25 22:25:35 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-08-25 22:25:36 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2023-08-25 22:25:37 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-08-25 22:25:37 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-08-25 22:25:38 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-08-25 22:25:39 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-08-25 22:25:39 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-08-25 22:25:40 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-08-25 22:25:41 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-08-25 22:25:41 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-08-25 22:25:42 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 22:44:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:44:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-25 22:50:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:50:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-25 22:59:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 22:59:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 23:05:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:05:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-25 23:10:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:18:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:18:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:18:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:21:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-25 23:55:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
