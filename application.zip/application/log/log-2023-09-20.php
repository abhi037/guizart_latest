<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-20 01:10:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:10:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 01:10:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 01:16:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:17:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:17:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:17:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:17:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 01:19:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:39:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:40:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:40:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:40:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:40:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:40:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 02:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 02:51:57 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-20 02:52:05 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-09-20 02:52:14 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-09-20 02:52:21 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-09-20 02:52:28 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-20 02:52:35 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-09-20 02:52:42 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-20 02:53:01 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-20 02:53:08 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-09-20 02:53:15 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-20 02:53:22 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-20 02:53:30 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-20 02:53:37 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-20 02:53:47 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-09-20 03:35:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 04:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 05:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 05:42:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 05:43:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 05:44:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 06:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 07:07:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 07:08:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 07:08:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 07:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 07:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 07:35:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 07:37:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 07:54:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:11:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:11:43 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-20 08:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 08:13:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:13:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:14:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 08:14:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 08:14:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:14:32 --> 404 Page Not Found: Log/index
ERROR - 2023-09-20 08:14:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:15:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 08:41:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:41:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 08:44:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:48:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:48:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 08:52:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 08:52:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 09:00:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 09:38:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 09:38:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 09:38:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 09:38:16 --> 404 Page Not Found: Log/index
ERROR - 2023-09-20 10:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 10:21:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 10:23:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 10:26:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 10:27:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 10:29:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 10:30:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 11:42:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 11:42:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 12:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 13:00:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 13:00:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 13:27:40 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-20 13:27:44 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-20 13:27:51 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-20 13:28:01 --> 404 Page Not Found: New/index
ERROR - 2023-09-20 13:28:04 --> 404 Page Not Found: Test/index
ERROR - 2023-09-20 13:28:20 --> 404 Page Not Found: Temp/index
ERROR - 2023-09-20 13:28:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 13:43:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 13:43:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 13:43:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 14:16:03 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-09-20 14:16:03 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-20 14:26:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 14:27:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 14:28:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 14:56:28 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-09-20 15:33:56 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-20 15:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 15:33:57 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-20 15:33:58 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-20 15:33:58 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-20 15:34:00 --> 404 Page Not Found: New/index
ERROR - 2023-09-20 15:34:01 --> 404 Page Not Found: Main/index
ERROR - 2023-09-20 15:34:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 15:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 16:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 16:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 16:01:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 16:11:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:11:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:13:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:13:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 16:50:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:50:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 16:51:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 16:51:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 16:51:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 16:51:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 17:33:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-20 17:53:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-20 17:53:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-20 18:27:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 18:27:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 18:55:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:02:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:09:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-20 19:09:54 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-09-20 19:09:55 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-09-20 19:14:11 --> 404 Page Not Found: Uploads/slider
ERROR - 2023-09-20 19:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 19:30:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:32:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 19:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 19:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:36:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 19:36:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 20:42:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 20:42:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 20:44:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 20:44:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 20:44:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 20:44:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 20:44:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 20:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 21:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 21:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 21:42:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:42:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:44:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:44:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:52:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 21:52:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 21:52:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 21:52:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 21:53:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 22:02:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 22:02:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 22:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 22:12:06 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-20 22:12:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-20 22:52:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 22:52:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 22:53:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-20 22:53:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 23:29:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-20 23:35:52 --> 404 Page Not Found: Env/index
ERROR - 2023-09-20 23:35:54 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-20 23:45:11 --> 404 Page Not Found: Env/index
ERROR - 2023-09-20 23:45:14 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-20 23:58:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
