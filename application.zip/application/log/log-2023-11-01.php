<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-01 00:01:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:01:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 00:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 00:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 00:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 00:55:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:55:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:55:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:55:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:55:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:56:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 00:56:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:45:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:45:27 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-11-01 01:50:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:50:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:50:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:50:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:51:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:51:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:52:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:52:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 01:52:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:16:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:16:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 02:24:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 02:30:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 02:32:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:32:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 02:39:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:39:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 02:45:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 02:45:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 02:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 02:49:05 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 02:49:05 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 02:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 03:24:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 03:24:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 03:39:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 03:39:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 03:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 04:15:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 04:15:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 04:15:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 04:16:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 04:30:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 04:33:40 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-01 04:34:12 --> 404 Page Not Found: Simplephp/index
ERROR - 2023-11-01 04:34:28 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-11-01 04:34:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 04:35:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 04:35:45 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-11-01 04:36:22 --> 404 Page Not Found: Fm1php/index
ERROR - 2023-11-01 04:36:38 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-01 04:36:55 --> 404 Page Not Found: M1php/index
ERROR - 2023-11-01 04:37:10 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-11-01 04:37:26 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-11-01 04:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 04:49:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 05:15:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 05:15:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 05:42:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 05:42:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 06:15:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 06:15:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 06:19:02 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 06:19:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 07:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 07:06:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 07:06:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 07:06:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 07:13:45 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-11-01 07:19:30 --> 404 Page Not Found: Env/index
ERROR - 2023-11-01 07:22:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 07:27:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:28:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:28:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:30:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:30:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:30:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:36:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:36:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:36:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:36:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:36:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:37:22 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 07:47:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 07:47:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 07:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 07:50:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:50:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:50:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:50:11 --> 404 Page Not Found: Log/index
ERROR - 2023-11-01 07:50:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:50:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:52:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:52:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:52:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:52:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:52:06 --> 404 Page Not Found: Log In/index
ERROR - 2023-11-01 07:52:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 07:52:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:52:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:52:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 07:52:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 08:03:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 08:03:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 08:12:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 08:12:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 08:13:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 08:13:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 08:23:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 08:23:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 08:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 09:13:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 09:13:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 09:23:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 09:23:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 10:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 10:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 10:17:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 10:17:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 10:17:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 10:40:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 10:40:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 10:40:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 10:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 10:54:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-01 12:27:33 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-11-01 12:27:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:27:34 --> 404 Page Not Found: Wp/index
ERROR - 2023-11-01 12:27:35 --> 404 Page Not Found: Bc/index
ERROR - 2023-11-01 12:27:35 --> 404 Page Not Found: Bk/index
ERROR - 2023-11-01 12:27:39 --> 404 Page Not Found: New/index
ERROR - 2023-11-01 12:27:39 --> 404 Page Not Found: Main/index
ERROR - 2023-11-01 12:27:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:47:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:47:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 12:54:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:54:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:54:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 12:54:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 12:54:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 12:54:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 13:40:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:40:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:40:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:40:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:40:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:41:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:41:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:41:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:43:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:43:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 13:48:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:48:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 13:58:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 13:59:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 14:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 14:09:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:09:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 14:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 14:30:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:30:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 14:35:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:36:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:36:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:36:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:37:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:37:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:47:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:47:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 14:57:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 14:57:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 15:00:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 15:00:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 15:00:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 15:00:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 15:00:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 15:15:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 15:15:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 15:24:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 15:24:43 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-11-01 15:24:53 --> 404 Page Not Found: 404php/index
ERROR - 2023-11-01 15:25:04 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-11-01 15:25:12 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-11-01 15:25:17 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-11-01 15:25:33 --> 404 Page Not Found: Xophp/index
ERROR - 2023-11-01 15:25:43 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-01 15:25:47 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-11-01 15:25:55 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-11-01 15:26:01 --> 404 Page Not Found: Congphp/index
ERROR - 2023-11-01 15:26:08 --> 404 Page Not Found: Wso-x569php/index
ERROR - 2023-11-01 15:26:21 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-11-01 15:26:32 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-01 15:26:41 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-11-01 15:26:51 --> 404 Page Not Found: Wp-content/style-css.php
ERROR - 2023-11-01 15:27:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 15:27:16 --> 404 Page Not Found: Wp-content/themes.php
ERROR - 2023-11-01 15:27:28 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-11-01 15:27:38 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-01 15:27:42 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 15:27:45 --> 404 Page Not Found: Fm1php/index
ERROR - 2023-11-01 15:27:53 --> 404 Page Not Found: Alfadheatphp/index
ERROR - 2023-11-01 15:28:03 --> 404 Page Not Found: M1php/index
ERROR - 2023-11-01 15:47:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 15:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 15:58:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 16:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 16:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 17:01:01 --> 404 Page Not Found: Chosenphp/index
ERROR - 2023-11-01 17:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 17:32:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 17:32:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 01php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 02php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 1php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 1337php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 1h6j5php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 1indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 1indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 2indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 2indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 3indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 3xphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 403php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 404php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: 4pricephp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Admin/controller
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Autoload_classmapphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Baindexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Cphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Cphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Cryptedphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Css/4O4.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Deadcode1975xxxxxxxxxxxxxxxxxxxxxxxxxxxxphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Docphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Goodphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Haxorphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Image/screenshot_1.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Images/wp-2019.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Madphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Massphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Mininewphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: New-indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Old-indexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Payoutphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Piphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Reminderphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Screenshot_1php/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Up-konphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Upphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Uploads/xleet.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wikindexphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/priv8.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/rss.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-admin/xleet.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/wp-activate.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-01 17:36:02 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/upload.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-easyphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-godphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/24.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/indeh.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/ms-pie.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/radio.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/theme-templates-private.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/uplaod.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/v22.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/wp-2019.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/wp-includes
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/wp-site.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/xmrlpc.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/xx.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/1index.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/admin-bar.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/assets
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/block-supports
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/customize
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/ms-files.php
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/pomo
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-includes/pomo
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-xphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp_logxphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wxophp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xlphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xltphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xmlrqcphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xwxxphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: XxXphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-2018php/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-2019php/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-2020php/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-2021php/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-2022php/index
ERROR - 2023-11-01 17:36:03 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-11-01 17:44:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 17:44:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 17:55:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 17:55:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 17:55:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 17:55:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 18:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 18:26:14 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 18:26:14 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 18:26:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 19:04:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 19:04:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 19:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 19:51:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 19:51:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 19:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 20:03:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 20:03:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 20:08:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 20:08:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 20:08:59 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 20:08:59 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 20:08:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 20:22:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 20:22:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 22:15:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 22:15:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 22:24:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 22:24:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 22:29:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 22:29:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 22:38:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-01 22:38:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-01 22:38:54 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 22:38:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-01 22:38:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-01 22:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-01 23:30:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 23:33:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 23:33:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-01 23:33:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
