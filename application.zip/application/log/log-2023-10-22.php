<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-22 00:11:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 00:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 00:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 00:27:14 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-22 00:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 00:35:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 00:37:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 00:46:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 00:46:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 00:46:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 00:51:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 01:28:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:15:40 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-22 02:22:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:22:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:22:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:24:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:38:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:38:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:40:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:40:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:52:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:52:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:53:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 02:53:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 02:58:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 02:58:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 02:58:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 03:16:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 03:29:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 03:42:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 03:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 04:09:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 04:09:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 04:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 04:18:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 04:24:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 04:24:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 04:24:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 04:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 04:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 04:35:08 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-10-22 04:35:08 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-10-22 04:35:09 --> 404 Page Not Found: Sftpjson/index
ERROR - 2023-10-22 04:37:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 04:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 04:37:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 04:37:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 04:39:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:01:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:02:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:05:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:17:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:17:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:23:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:25:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:40:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:40:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:40:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:40:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 05:48:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 05:48:22 --> 404 Page Not Found: Wp-json/tdw
ERROR - 2023-10-22 05:54:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 06:47:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 06:47:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 06:47:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 07:06:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 07:06:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 07:06:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 07:06:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 07:09:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 07:37:47 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-22 07:57:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 08:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 08:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 09:39:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 09:39:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 09:39:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 10:01:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 10:22:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 10:23:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 10:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 10:31:56 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-22 10:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 10:34:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 10:34:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 10:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 10:40:46 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-22 10:40:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 10:50:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 10:50:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 11:57:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 11:57:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 11:57:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 11:57:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 12:34:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 12:34:51 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 12:34:51 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 12:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 12:51:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:34 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:35 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:51:48 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:00 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:13 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:14 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdndatatablesnet/v
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Contentjwplatformcom/libraries
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Cdnjscloudflarecom/ajax
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Wwwgooglecom/recaptcha
ERROR - 2023-10-22 12:52:25 --> 404 Page Not Found: Quizartcoin/assets
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 13:02:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 13:02:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 13:02:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 13:02:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 13:06:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 13:06:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 13:06:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 13:36:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 13:36:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 13:36:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 13:36:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 13:37:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 13:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 13:52:51 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-22 14:02:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 14:02:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 14:03:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:06:39 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-22 14:06:39 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-22 14:06:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:07:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:10:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 14:10:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:42:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:51:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 14:51:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 14:56:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 14:56:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 15:12:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 15:46:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 15:46:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 15:46:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 16:06:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 16:43:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 16:58:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 16:58:37 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-10-22 17:24:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 17:34:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:34:37 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-22 17:34:40 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-10-22 17:34:46 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-10-22 17:34:46 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-10-22 17:34:50 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-22 17:34:52 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-10-22 17:34:55 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:34:57 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-22 17:34:57 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-10-22 17:34:59 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:35:01 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:35:02 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-22 17:35:04 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:35:06 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-10-22 17:35:09 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-10-22 17:35:13 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-22 17:35:14 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:36:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-10-22 17:36:03 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-10-22 17:36:04 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Wp-includes/theme-compat
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-10-22 17:36:05 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-22 17:36:06 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:07 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:08 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:09 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-22 17:36:10 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-22 17:36:10 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-10-22 17:36:10 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-10-22 17:36:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Wp-content/gecko-new.php
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Wp-admin/raizoworm.php
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Libraries/legacy
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Libraries/phpmailer
ERROR - 2023-10-22 17:36:11 --> 404 Page Not Found: Libraries/vendor
ERROR - 2023-10-22 17:38:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 17:40:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 17:40:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 17:47:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 17:49:29 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-22 17:49:29 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-22 17:49:30 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-22 17:49:30 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-22 18:05:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 18:05:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 18:39:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 18:39:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 18:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 18:52:54 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-10-22 19:40:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 19:40:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 19:41:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 19:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 19:58:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 19:58:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 19:58:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 19:58:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 19:58:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 20:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 20:28:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-22 20:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:45:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:47:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:48:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:48:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 20:57:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 20:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 20:59:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 20:59:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 21:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 21:04:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 21:04:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 21:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 21:14:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 21:41:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 21:41:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 21:50:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 22:03:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 22:13:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 22:14:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 22:39:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-22 22:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 22:53:51 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-10-22 22:53:52 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-22 22:53:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 22:56:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-22 22:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 23:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-22 23:57:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 23:57:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-22 23:58:32 --> 404 Page Not Found: Robotstxt/index
