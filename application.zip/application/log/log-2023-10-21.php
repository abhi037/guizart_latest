<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-21 00:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 00:45:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 00:48:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 01:08:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 01:08:47 --> 404 Page Not Found: Cjfunsphp/index
ERROR - 2023-10-21 01:08:48 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-10-21 01:08:48 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-10-21 01:08:48 --> 404 Page Not Found: Stphp/index
ERROR - 2023-10-21 01:08:49 --> 404 Page Not Found: My1php/index
ERROR - 2023-10-21 01:13:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 01:15:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 01:16:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 01:16:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 01:16:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 01:26:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 01:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 02:31:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:31:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:32:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:32:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:33:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:34:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:34:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:35:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:43:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:43:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 02:56:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:56:23 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-10-21 02:56:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-21 02:56:23 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-10-21 02:56:24 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-21 02:56:24 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-10-21 02:56:24 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-10-21 02:56:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 02:56:25 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-10-21 02:56:25 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-10-21 02:56:25 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-10-21 02:56:26 --> 404 Page Not Found: Eephp/index
ERROR - 2023-10-21 02:56:26 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-10-21 02:56:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-21 02:56:27 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-10-21 02:56:27 --> 404 Page Not Found: Installphp/index
ERROR - 2023-10-21 02:56:27 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-10-21 02:56:28 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-21 02:56:28 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-10-21 02:56:29 --> 404 Page Not Found: Css/install.php
ERROR - 2023-10-21 02:56:29 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-21 02:56:29 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-21 02:56:30 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-10-21 02:56:30 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-10-21 02:56:30 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-10-21 02:56:31 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-10-21 02:56:31 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-21 02:56:31 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-10-21 02:56:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 03:00:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:02:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:03:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 03:08:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:08:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 03:09:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:09:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 03:30:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:30:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 03:36:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 03:36:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 03:36:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 03:41:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 03:41:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 04:07:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 04:08:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 04:09:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 04:09:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 04:39:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 04:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 05:36:50 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-10-21 06:00:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 06:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 06:39:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 06:39:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 06:39:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 07:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 07:38:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 07:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 07:39:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 07:39:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 08:02:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 08:02:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 08:07:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 08:07:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 08:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 09:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 09:30:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 09:30:04 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-21 09:36:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 09:48:22 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-21 10:16:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 10:17:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 10:17:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 11:00:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 11:00:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 11:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 11:11:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 11:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 11:18:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 11:23:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 11:23:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 12:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 12:07:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 12:10:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 12:11:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 12:18:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 12:18:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 12:29:09 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-21 12:31:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 12:31:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 13:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 13:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 13:53:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:02:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:09:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:09:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 14:09:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 14:09:18 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-21 14:09:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:09:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:09:30 --> 404 Page Not Found: Log/index
ERROR - 2023-10-21 14:09:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:09:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:22:39 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-21 14:27:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 14:43:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 14:49:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 14:49:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 15:32:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 15:32:18 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-21 16:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 16:43:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 16:43:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 16:44:09 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-21 16:44:10 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-21 16:44:38 --> 404 Page Not Found: Home/contact.html
ERROR - 2023-10-21 16:44:41 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-21 16:44:41 --> 404 Page Not Found: Home/contact.html
ERROR - 2023-10-21 16:44:44 --> 404 Page Not Found: Advisor-singlehtml/index
ERROR - 2023-10-21 16:44:52 --> 404 Page Not Found: Advisors-2html/index
ERROR - 2023-10-21 16:44:52 --> 404 Page Not Found: Advisorshtml/index
ERROR - 2023-10-21 16:44:53 --> 404 Page Not Found: Blog-3-columhtml/index
ERROR - 2023-10-21 16:44:55 --> 404 Page Not Found: Blog-single-with-sidebarhtml/index
ERROR - 2023-10-21 16:44:57 --> 404 Page Not Found: Blog-singlehtml/index
ERROR - 2023-10-21 16:44:58 --> 404 Page Not Found: Blog-standardhtml/index
ERROR - 2023-10-21 16:44:59 --> 404 Page Not Found: Blog-with-sidebarhtml/index
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:02 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:03 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:14 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:14 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:17 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:17 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 16:45:39 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 16:45:40 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-21 16:45:41 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-21 16:45:41 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-21 16:45:45 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-21 16:45:45 --> 404 Page Not Found: Advisor-singlehtml/index
ERROR - 2023-10-21 16:45:45 --> 404 Page Not Found: Advisors-2html/index
ERROR - 2023-10-21 16:45:48 --> 404 Page Not Found: Advisorshtml/index
ERROR - 2023-10-21 16:45:48 --> 404 Page Not Found: Blog-2-columhtml/index
ERROR - 2023-10-21 16:45:48 --> 404 Page Not Found: Blog-3-columhtml/index
ERROR - 2023-10-21 16:45:51 --> 404 Page Not Found: Blog-singlehtml/index
ERROR - 2023-10-21 16:45:51 --> 404 Page Not Found: Blog-standardhtml/index
ERROR - 2023-10-21 16:45:51 --> 404 Page Not Found: Blog-single-with-sidebarhtml/index
ERROR - 2023-10-21 16:45:52 --> 404 Page Not Found: Blog-with-sidebarhtml/index
ERROR - 2023-10-21 16:45:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 16:45:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 16:46:07 --> 404 Page Not Found: Util/login.aspx
ERROR - 2023-10-21 16:46:07 --> 404 Page Not Found: Installphp/index
ERROR - 2023-10-21 16:46:07 --> 404 Page Not Found: Magento_version/index
ERROR - 2023-10-21 17:29:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 18:01:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 18:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 18:45:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 18:45:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 19:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 19:02:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 19:38:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 19:38:48 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-21 19:44:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 19:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 19:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 19:44:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 19:48:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 19:48:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 19:58:36 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-10-21 19:59:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 20:23:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 20:33:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 20:33:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 20:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 20:44:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 20:44:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 20:51:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 20:51:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 20:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 21:33:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 21:44:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 21:44:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 21:44:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 21:51:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-21 22:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-21 22:31:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 22:58:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 22:58:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 22:58:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 22:58:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 22:58:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 23:07:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-21 23:37:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 23:37:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-21 23:48:27 --> 404 Page Not Found: Assets/frontend
