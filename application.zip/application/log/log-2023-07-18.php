<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-18 05:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-18 05:19:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 05:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-18 05:23:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 06:29:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 06:30:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 06:30:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 07:01:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 07:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-18 07:01:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 07:01:20 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:34 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:34 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:35 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:36 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:37 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:38 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:39 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:40 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:41 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-18 07:01:42 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:42 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-18 07:01:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-07-18 07:02:35 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-07-18 07:02:35 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2023-07-18 07:02:36 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-07-18 07:02:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-18 07:02:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 07:02:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 07:02:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 07:02:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 13:16:51 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-07-18 13:46:36 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-07-18 13:46:39 --> 404 Page Not Found: Public/_ignition
ERROR - 2023-07-18 14:07:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 14:36:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 14:51:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 14:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-18 14:52:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-18 15:55:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 15:56:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 18:16:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 18:16:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 18:16:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-18 20:44:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 20:44:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 20:44:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-18 20:44:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-18 20:44:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-18 20:44:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
