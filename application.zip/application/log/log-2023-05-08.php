<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-08 00:19:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 00:19:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 00:19:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 00:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-08 00:57:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 00:57:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-08 01:22:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:22:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:22:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:22:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:22:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:22:55 --> 404 Page Not Found: Log/index
ERROR - 2023-05-08 01:23:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:23:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-08 01:23:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:24:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:24:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:25:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:12 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-08 01:27:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 01:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 01:27:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 05:24:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 05:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-08 07:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-08 07:07:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-08 07:07:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-08 14:07:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 16:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-08 16:50:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 16:51:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-08 21:10:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
