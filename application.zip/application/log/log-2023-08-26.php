<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-26 00:16:04 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-08-26 00:16:55 --> 404 Page Not Found: Alfanewphp/index
ERROR - 2023-08-26 00:17:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 00:18:37 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-26 00:19:29 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-26 00:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 00:20:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 00:20:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 00:20:20 --> 404 Page Not Found: Wp-admin/repeater.php
ERROR - 2023-08-26 00:21:11 --> 404 Page Not Found: Wp-includes/repeater.php
ERROR - 2023-08-26 00:22:02 --> 404 Page Not Found: Wp-content/repeater.php
ERROR - 2023-08-26 00:22:53 --> 404 Page Not Found: Wsoyanzphp/index
ERROR - 2023-08-26 00:23:44 --> 404 Page Not Found: Wp-includes/IXR
ERROR - 2023-08-26 00:24:36 --> 404 Page Not Found: Assets/images
ERROR - 2023-08-26 00:25:27 --> 404 Page Not Found: Wp-includes/block-supports
ERROR - 2023-08-26 00:26:18 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-26 00:27:09 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-08-26 00:28:00 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:28:51 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:29:42 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-08-26 00:30:33 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-08-26 00:31:25 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:32:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 00:32:16 --> 404 Page Not Found: Wp-content/correos
ERROR - 2023-08-26 00:33:07 --> 404 Page Not Found: Images/captcha
ERROR - 2023-08-26 00:33:59 --> 404 Page Not Found: Wp-includes/customize
ERROR - 2023-08-26 00:34:51 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-08-26 00:35:42 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-26 00:36:33 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:37:24 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-26 00:38:15 --> 404 Page Not Found: Wp-includes/SimplePie
ERROR - 2023-08-26 00:39:07 --> 404 Page Not Found: Wp-includes/SimplePie
ERROR - 2023-08-26 00:39:58 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-26 00:40:49 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-26 00:41:40 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-08-26 00:42:31 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-26 00:43:22 --> 404 Page Not Found: Wp-content/mu-plugins
ERROR - 2023-08-26 00:44:13 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:45:04 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:45:32 --> 404 Page Not Found: Wp-includes/pomo
ERROR - 2023-08-26 00:46:23 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 00:47:14 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-26 02:04:37 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-08-26 02:10:13 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-08-26 02:56:25 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-08-26 02:56:25 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-08-26 03:53:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 03:53:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 03:54:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 03:54:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 04:14:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 04:14:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 04:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 04:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 04:59:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 04:59:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 05:00:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 05:00:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 05:07:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 05:07:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 05:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 05:08:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 05:08:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 05:09:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 05:09:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 05:20:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 05:20:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 05:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 05:31:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 05:31:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 05:57:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 05:57:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 06:07:38 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-26 06:20:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 06:21:14 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-26 06:24:54 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-26 07:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 07:36:20 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 07:36:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 08:20:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 08:54:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 08:54:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 09:14:21 --> 404 Page Not Found: Cdn-cgi/l
ERROR - 2023-08-26 09:38:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 10:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 10:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 10:21:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 10:32:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 10:32:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 10:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 10:38:52 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-08-26 10:38:53 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-26 10:38:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 10:45:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 10:45:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 10:52:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 10:52:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 11:48:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 11:48:49 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-08-26 13:33:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 13:34:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 14:11:52 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-26 14:12:53 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-08-26 14:14:18 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-08-26 14:15:19 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-08-26 14:16:21 --> 404 Page Not Found: Wp-includes/IXR
ERROR - 2023-08-26 14:17:22 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-26 14:18:23 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-26 14:18:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 14:19:59 --> 404 Page Not Found: Wp-content/mu-plugins
ERROR - 2023-08-26 14:21:00 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-26 14:22:01 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-26 14:23:03 --> 404 Page Not Found: Wp-includes/certificates
ERROR - 2023-08-26 14:24:04 --> 404 Page Not Found: Wp-includes/customize
ERROR - 2023-08-26 14:25:05 --> 404 Page Not Found: Wp-includes/fonts
ERROR - 2023-08-26 14:26:06 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-08-26 14:27:38 --> 404 Page Not Found: Well-knownold/index
ERROR - 2023-08-26 14:30:11 --> 404 Page Not Found: Images/index
ERROR - 2023-08-26 14:32:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2023-08-26 14:33:14 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-26 14:34:16 --> 404 Page Not Found: Wp-includes/pomo
ERROR - 2023-08-26 14:35:17 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-26 14:36:18 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-08-26 14:37:19 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-26 14:38:21 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-26 14:39:22 --> 404 Page Not Found: Wp-admin/meta
ERROR - 2023-08-26 14:40:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 14:40:23 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-26 14:41:24 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-26 14:42:11 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-08-26 14:43:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 14:44:14 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-26 14:45:15 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-08-26 14:46:16 --> 404 Page Not Found: Wp-admin/index
ERROR - 2023-08-26 14:47:17 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-08-26 14:50:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 14:50:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 15:33:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 15:34:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 15:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 15:44:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 15:46:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 15:46:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 15:46:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 15:46:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 15:48:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 15:52:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 15:52:58 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-08-26 16:04:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 16:04:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 16:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 16:28:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 16:28:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 18:26:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 18:34:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 18:34:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 18:34:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 18:35:07 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-26 18:35:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 18:36:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 18:45:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-26 19:05:58 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 19:05:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-26 19:35:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 20:28:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:30:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:30:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:30:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:30:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 20:31:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:31:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 20:31:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 20:32:26 --> 404 Page Not Found: Log In/index
ERROR - 2023-08-26 20:34:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 20:35:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 20:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 21:06:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 21:06:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 21:06:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 21:25:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 21:25:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 21:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-26 21:39:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 21:39:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 21:46:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 21:46:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 22:02:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 22:02:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 22:03:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 22:08:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-26 22:17:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 22:38:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 22:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 22:56:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 22:56:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-26 23:04:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:04:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:04:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:06:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:06:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:07:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-26 23:47:39 --> 404 Page Not Found: Env/index
