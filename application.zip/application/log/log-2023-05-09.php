<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-09 00:28:00 --> 404 Page Not Found: Git/config
ERROR - 2023-05-09 01:14:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 03:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 03:05:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 05:29:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 05:29:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-09 06:23:59 --> 404 Page Not Found: Git/config
ERROR - 2023-05-09 06:35:41 --> 404 Page Not Found: Adminerphp/index
ERROR - 2023-05-09 09:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-09 18:14:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:04:16 --> 404 Page Not Found: Archivarixcmsphp/index
ERROR - 2023-05-09 21:16:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:16:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:16:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:16:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:16:51 --> 404 Page Not Found: Log/index
ERROR - 2023-05-09 21:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-09 21:17:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:21:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:21:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:21:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:22:32 --> 404 Page Not Found: Log/index
ERROR - 2023-05-09 21:22:49 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-09 21:22:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:22:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:22:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:22:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:22:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:23:07 --> 404 Page Not Found: Log/index
ERROR - 2023-05-09 21:23:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:23:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:08 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-09 21:24:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:24:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:24:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:24:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:25:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:25:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:26:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:26:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:26:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:26:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:26:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:27:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:27:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:27:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:28:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:28:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:28:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:28:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:29:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:29:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:29:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:29:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:29:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:29:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:30:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 21:30:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 21:36:46 --> 404 Page Not Found: Log/index
ERROR - 2023-05-09 22:11:37 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-09 22:11:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 22:11:40 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-09 22:11:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 22:11:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-09 22:26:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 22:27:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-09 22:27:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 22:27:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-09 22:28:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
