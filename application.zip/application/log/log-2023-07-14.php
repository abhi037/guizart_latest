<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-14 00:15:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 00:26:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 01:52:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 01:53:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 02:12:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 02:12:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 02:26:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-14 03:22:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 03:22:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-14 03:22:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-14 03:22:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-14 04:02:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 04:09:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-14 04:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 04:09:01 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-14 04:09:03 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-14 04:09:04 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-14 04:09:05 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-14 04:09:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 04:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 04:10:34 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-14 04:14:00 --> 404 Page Not Found: Axis2-admin/index
ERROR - 2023-07-14 04:14:01 --> 404 Page Not Found: Axis2/index
ERROR - 2023-07-14 04:14:03 --> 404 Page Not Found: Axis2/axis2-admin
ERROR - 2023-07-14 04:14:05 --> 404 Page Not Found: Pma/index.php
ERROR - 2023-07-14 04:14:06 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2023-07-14 04:14:07 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2023-07-14 04:14:09 --> 404 Page Not Found: Php/thinkphp
ERROR - 2023-07-14 04:14:09 --> 404 Page Not Found: Index_ssophp/index
ERROR - 2023-07-14 04:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 07:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 07:08:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 07:09:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 07:16:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 07:16:06 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-07-14 07:16:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 09:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 14:34:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 14:34:33 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-14 15:39:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 15:39:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 16:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 20:01:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 21:26:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 22:12:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 22:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 22:37:15 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-07-14 22:37:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-14 22:37:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 23:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-14 23:03:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 23:07:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-14 23:08:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-14 23:08:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-14 23:08:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-14 23:48:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
