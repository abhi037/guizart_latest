<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-22 01:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 01:49:34 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-06-22 01:49:34 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-06-22 01:49:34 --> 404 Page Not Found: WORDPRESS/index
ERROR - 2023-06-22 01:49:35 --> 404 Page Not Found: WordPress/index
ERROR - 2023-06-22 01:49:35 --> 404 Page Not Found: Wp/index
ERROR - 2023-06-22 01:49:35 --> 404 Page Not Found: Wp/index
ERROR - 2023-06-22 01:49:36 --> 404 Page Not Found: WP/index
ERROR - 2023-06-22 01:49:37 --> 404 Page Not Found: Old/index
ERROR - 2023-06-22 01:49:37 --> 404 Page Not Found: OLD/index
ERROR - 2023-06-22 01:49:37 --> 404 Page Not Found: Oldsite/index
ERROR - 2023-06-22 01:49:38 --> 404 Page Not Found: New/index
ERROR - 2023-06-22 01:49:38 --> 404 Page Not Found: New/index
ERROR - 2023-06-22 01:49:39 --> 404 Page Not Found: NEW/index
ERROR - 2023-06-22 01:49:39 --> 404 Page Not Found: Wp-old/index
ERROR - 2023-06-22 01:49:39 --> 404 Page Not Found: 2022/index
ERROR - 2023-06-22 01:49:40 --> 404 Page Not Found: 2020/index
ERROR - 2023-06-22 01:49:40 --> 404 Page Not Found: 2019/index
ERROR - 2023-06-22 01:49:40 --> 404 Page Not Found: 2018/index
ERROR - 2023-06-22 01:49:41 --> 404 Page Not Found: Backup/index
ERROR - 2023-06-22 01:49:41 --> 404 Page Not Found: Test/index
ERROR - 2023-06-22 01:49:41 --> 404 Page Not Found: Test/index
ERROR - 2023-06-22 01:49:42 --> 404 Page Not Found: TEST/index
ERROR - 2023-06-22 01:49:42 --> 404 Page Not Found: Demo/index
ERROR - 2023-06-22 01:49:43 --> 404 Page Not Found: Bc/index
ERROR - 2023-06-22 01:49:43 --> 404 Page Not Found: Www/index
ERROR - 2023-06-22 01:49:43 --> 404 Page Not Found: WWW/index
ERROR - 2023-06-22 01:49:44 --> 404 Page Not Found: Www/index
ERROR - 2023-06-22 01:49:44 --> 404 Page Not Found: 2021/index
ERROR - 2023-06-22 01:49:44 --> 404 Page Not Found: Main/index
ERROR - 2023-06-22 01:49:45 --> 404 Page Not Found: Old-site/index
ERROR - 2023-06-22 01:49:45 --> 404 Page Not Found: Bk/index
ERROR - 2023-06-22 01:49:45 --> 404 Page Not Found: Backup/index
ERROR - 2023-06-22 01:49:46 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-06-22 01:49:46 --> 404 Page Not Found: SHOP/index
ERROR - 2023-06-22 01:49:47 --> 404 Page Not Found: Shop/index
ERROR - 2023-06-22 01:49:47 --> 404 Page Not Found: Shop/index
ERROR - 2023-06-22 01:49:47 --> 404 Page Not Found: Bak/index
ERROR - 2023-06-22 01:49:48 --> 404 Page Not Found: Sitio/index
ERROR - 2023-06-22 01:49:48 --> 404 Page Not Found: Bac/index
ERROR - 2023-06-22 01:49:48 --> 404 Page Not Found: Sito/index
ERROR - 2023-06-22 01:49:49 --> 404 Page Not Found: Site/index
ERROR - 2023-06-22 01:49:49 --> 404 Page Not Found: Site/index
ERROR - 2023-06-22 01:49:50 --> 404 Page Not Found: SITE/index
ERROR - 2023-06-22 01:49:50 --> 404 Page Not Found: Blog/index
ERROR - 2023-06-22 01:49:50 --> 404 Page Not Found: BLOG/index
ERROR - 2023-06-22 01:49:51 --> 404 Page Not Found: Blog/index
ERROR - 2023-06-22 08:16:46 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-06-22 14:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-22 14:57:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 16:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-22 16:55:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 16:55:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-22 16:55:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-22 16:56:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-22 21:53:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 21:53:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 21:54:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-22 21:54:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-22 21:54:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
