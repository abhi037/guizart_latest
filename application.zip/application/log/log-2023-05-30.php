<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-30 03:54:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 06:38:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 14:22:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 18:26:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 18:26:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-30 18:26:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-30 19:20:13 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-05-30 19:20:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 20:32:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 20:32:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-30 20:33:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-30 20:33:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-30 22:18:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-30 22:18:36 --> 404 Page Not Found: Well-known/traffic-advice
