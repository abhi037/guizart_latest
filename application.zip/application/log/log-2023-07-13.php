<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-13 00:03:23 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-07-13 01:56:41 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-07-13 02:17:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 02:31:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 03:46:00 --> 404 Page Not Found: Wp-ccphp/index
ERROR - 2023-07-13 03:46:00 --> 404 Page Not Found: Wp-commentinphp/index
ERROR - 2023-07-13 04:27:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 04:53:14 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-07-13 07:54:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 08:08:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 09:38:58 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-07-13 09:39:01 --> 404 Page Not Found: Public/_ignition
ERROR - 2023-07-13 13:18:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 13:18:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 13:18:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-13 13:18:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 13:18:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 13:18:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-13 13:18:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-13 13:18:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 13:18:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-13 13:18:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-13 14:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-13 15:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-13 15:22:30 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-07-13 15:23:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 16:45:05 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-07-13 16:48:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 21:30:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 21:30:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 21:31:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-13 21:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-13 21:31:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 21:31:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 21:32:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-13 21:32:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 23:25:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-13 23:26:16 --> 404 Page Not Found: Robotstxt/index
