<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-29 06:38:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-29 11:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-29 14:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-29 14:31:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-29 15:40:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-29 15:40:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-29 15:40:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-29 17:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-29 19:55:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-29 19:55:39 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-06-29 22:01:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
