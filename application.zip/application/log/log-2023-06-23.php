<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-23 06:20:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 07:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-23 07:31:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 07:32:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-23 07:35:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 16:35:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 16:35:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-23 16:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-23 16:37:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 21:06:02 --> 404 Page Not Found: Git/config
ERROR - 2023-06-23 21:27:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-23 23:41:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
