<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-19 01:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 01:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:05:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 01:06:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:06:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:06:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 01:06:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 01:14:18 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 01:14:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 01:17:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:25:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:25:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 01:26:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 01:27:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:50:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 01:51:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 02:40:15 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 02:40:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 02:45:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 02:45:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 03:06:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 03:11:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 03:16:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 03:16:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 03:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 03:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 03:58:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 03:58:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 04:10:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 04:13:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 04:27:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 04:27:22 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-19 04:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 04:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 04:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 04:56:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 05:32:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 05:32:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 07:07:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:07:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 07:27:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 07:28:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 07:28:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 07:28:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 07:28:29 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 07:28:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:28:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:28:32 --> 404 Page Not Found: Home/LogIn
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 07:28:36 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:28:36 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 07:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 07:29:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 08:08:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 08:08:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:08:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:08:40 --> 404 Page Not Found: Log/index
ERROR - 2023-09-19 08:09:11 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-19 08:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 08:25:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 08:25:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:25:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:54:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 08:54:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:54:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:54:48 --> 404 Page Not Found: Log/index
ERROR - 2023-09-19 08:54:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 08:55:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:55:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 08:55:41 --> Severity: Notice --> Undefined variable: instructor_list /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-09-19 08:55:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-09-19 09:03:40 --> 404 Page Not Found: Wp-loadphp/index
ERROR - 2023-09-19 09:03:43 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-19 09:03:44 --> 404 Page Not Found: Wp-admin/style.php
ERROR - 2023-09-19 09:03:47 --> 404 Page Not Found: S_ephp/index
ERROR - 2023-09-19 09:03:51 --> 404 Page Not Found: S_nephp/index
ERROR - 2023-09-19 09:03:56 --> 404 Page Not Found: 1indexphp/index
ERROR - 2023-09-19 09:03:57 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-09-19 09:03:59 --> 404 Page Not Found: Docphp/index
ERROR - 2023-09-19 09:04:01 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-09-19 09:04:02 --> 404 Page Not Found: Beencephp/index
ERROR - 2023-09-19 09:04:06 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-09-19 09:04:07 --> 404 Page Not Found: Wp-signinphp/index
ERROR - 2023-09-19 09:04:09 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-09-19 09:04:13 --> 404 Page Not Found: Exportphp/index
ERROR - 2023-09-19 09:04:14 --> 404 Page Not Found: Wp-content/export.php
ERROR - 2023-09-19 09:04:15 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-19 09:04:17 --> 404 Page Not Found: Wp-includes/wp-atom.php
ERROR - 2023-09-19 09:04:21 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-09-19 09:04:21 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-09-19 09:04:23 --> 404 Page Not Found: Defau1tphp/index
ERROR - 2023-09-19 09:04:24 --> 404 Page Not Found: Modulessphp/index
ERROR - 2023-09-19 09:04:26 --> 404 Page Not Found: Wp-bookingphp/index
ERROR - 2023-09-19 09:04:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-19 09:04:29 --> 404 Page Not Found: Wp-content/mu-plugins
ERROR - 2023-09-19 09:04:32 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-09-19 09:04:33 --> 404 Page Not Found: Configbakphp/index
ERROR - 2023-09-19 09:04:33 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-19 09:04:35 --> 404 Page Not Found: Legionphp/index
ERROR - 2023-09-19 09:04:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-19 09:04:38 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-09-19 09:04:41 --> 404 Page Not Found: GankphpPhP/index
ERROR - 2023-09-19 09:04:43 --> 404 Page Not Found: Wp-content/db-cache.php
ERROR - 2023-09-19 09:04:45 --> 404 Page Not Found: Archivesphp/index
ERROR - 2023-09-19 09:04:46 --> 404 Page Not Found: Defau11php/index
ERROR - 2023-09-19 09:04:48 --> 404 Page Not Found: Wp-content/outcms.php
ERROR - 2023-09-19 09:04:49 --> 404 Page Not Found: System_logphp/index
ERROR - 2023-09-19 09:04:50 --> 404 Page Not Found: Wp-backup-sql-302php/index
ERROR - 2023-09-19 09:04:54 --> 404 Page Not Found: Errorphp/index
ERROR - 2023-09-19 09:04:57 --> 404 Page Not Found: ALFA_DATA/index
ERROR - 2023-09-19 09:04:58 --> 404 Page Not Found: Alfacgiapi/index
ERROR - 2023-09-19 09:04:59 --> 404 Page Not Found: Cgialfa/index
ERROR - 2023-09-19 09:05:03 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-19 09:05:04 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-19 09:05:09 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-19 09:05:13 --> 404 Page Not Found: Wp-includes/ALFA_DATA
ERROR - 2023-09-19 09:05:14 --> 404 Page Not Found: Wp-includes/alfacgiapi
ERROR - 2023-09-19 09:05:16 --> 404 Page Not Found: Wp-includes/cgialfa
ERROR - 2023-09-19 09:05:23 --> 404 Page Not Found: Wp-admin/ALFA_DATA
ERROR - 2023-09-19 09:05:25 --> 404 Page Not Found: Wp-admin/alfacgiapi
ERROR - 2023-09-19 09:05:27 --> 404 Page Not Found: Wp-admin/cgialfa
ERROR - 2023-09-19 09:05:29 --> 404 Page Not Found: Wp-content/ALFA_DATA
ERROR - 2023-09-19 09:05:34 --> 404 Page Not Found: Wp-content/alfacgiapi
ERROR - 2023-09-19 09:05:37 --> 404 Page Not Found: Wp-content/cgialfa
ERROR - 2023-09-19 09:05:38 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-19 09:05:40 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-19 09:05:46 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-19 09:05:49 --> 404 Page Not Found: Sites/default
ERROR - 2023-09-19 09:05:50 --> 404 Page Not Found: Sites/default
ERROR - 2023-09-19 09:05:54 --> 404 Page Not Found: Sites/default
ERROR - 2023-09-19 09:05:56 --> 404 Page Not Found: Admin/controller
ERROR - 2023-09-19 09:05:58 --> 404 Page Not Found: Admin/controller
ERROR - 2023-09-19 09:06:00 --> 404 Page Not Found: Admin/controller
ERROR - 2023-09-19 09:06:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-19 09:06:03 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-09-19 09:06:03 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-09-19 09:06:04 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-09-19 09:06:04 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-09-19 09:06:04 --> 404 Page Not Found: Upphp/index
ERROR - 2023-09-19 09:06:05 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-09-19 09:06:05 --> 404 Page Not Found: 1php/index
ERROR - 2023-09-19 09:06:06 --> 404 Page Not Found: Xphp/index
ERROR - 2023-09-19 09:06:06 --> 404 Page Not Found: Zphp/index
ERROR - 2023-09-19 09:06:07 --> 404 Page Not Found: Aphp/index
ERROR - 2023-09-19 09:06:07 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-19 09:06:08 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-09-19 09:06:08 --> 404 Page Not Found: Configphp/index
ERROR - 2023-09-19 09:06:09 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-19 09:06:09 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-09-19 09:06:10 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-09-19 09:25:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 09:53:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 09:53:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 10:05:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 10:05:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 11:15:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 11:28:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 11:28:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 11:34:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 11:34:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 11:51:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 12:24:28 --> 404 Page Not Found: Env/index
ERROR - 2023-09-19 12:46:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 12:51:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 14:10:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 14:10:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 14:10:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 14:10:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 14:16:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 14:16:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 14:54:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 14:54:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 14:54:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 14:55:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:25:11 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-19 15:25:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:25:12 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-19 15:25:12 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-19 15:25:13 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-19 15:25:14 --> 404 Page Not Found: New/index
ERROR - 2023-09-19 15:25:15 --> 404 Page Not Found: Main/index
ERROR - 2023-09-19 15:25:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:25:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:26:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:26:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:26:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:27:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 15:29:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:29:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 15:30:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:32:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:32:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 15:34:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 15:34:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 15:43:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:43:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 15:45:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:47:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:47:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 15:49:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:49:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 15:51:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 15:51:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 16:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 16:45:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 16:45:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 16:52:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:10:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:10:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 17:42:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:42:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 17:48:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:48:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 17:48:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 17:49:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 17:49:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:56:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:59:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:59:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 17:59:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-19 18:25:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 18:26:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 18:26:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 19:11:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 19:11:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 19:18:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 19:18:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 19:40:40 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-19 19:40:42 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-19 19:40:44 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-19 19:40:44 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-19 21:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 21:26:09 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-19 21:26:09 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-19 21:26:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 21:26:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-19 22:12:02 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-19 22:12:03 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-19 22:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 22:15:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 22:15:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 22:15:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 22:31:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 22:31:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 22:31:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:08:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:08:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:08:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:08:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:08:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:08:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:08:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:10:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:10:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:10:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:15:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:15:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:33:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:33:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:45:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:45:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:45:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:45:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:46:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:46:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-19 23:46:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:47:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-19 23:47:45 --> 404 Page Not Found: Assets/frontend
