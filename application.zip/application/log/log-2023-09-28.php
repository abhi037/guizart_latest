<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-28 00:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 00:40:17 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-28 00:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 00:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 01:01:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:01:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:01:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:29:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:30:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:30:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:30:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:39:47 --> 404 Page Not Found: Env/index
ERROR - 2023-09-28 01:48:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 01:51:02 --> 404 Page Not Found: Env/index
ERROR - 2023-09-28 01:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 01:59:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 02:12:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 02:40:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 02:40:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 02:40:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 03:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 03:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 03:01:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 03:58:46 --> 404 Page Not Found: Uploads/slider
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 04:23:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 04:23:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 04:23:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 04:31:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:53:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:54:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:54:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:54:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:54:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:55:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:55:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:56:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:56:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 04:57:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 06:14:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 06:14:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 06:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 06:16:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 06:16:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 06:16:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 06:17:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 06:17:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 07:10:38 --> 404 Page Not Found: Env/index
ERROR - 2023-09-28 07:12:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 07:12:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 07:31:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 07:34:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 07:37:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 07:37:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 07:37:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 08:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 08:46:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 08:46:40 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-28 09:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 09:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 09:52:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 09:53:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 09:53:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 09:54:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 09:54:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 10:00:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:00:50 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:02:19 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-28 10:04:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-28 10:05:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:05:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:07:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:07:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:08:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:08:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:10:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:10:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 10:11:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 10:11:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 10:17:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:17:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:18:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:19:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:19:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:20:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:21:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:21:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:21:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:21:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:21:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:21:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:21:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:22:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:22:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:26:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:26:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:27:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:27:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:33:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 10:35:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:35:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:40:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:40:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:40:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:40:25 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:40:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:42:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:42:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:49:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:49:51 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:53:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:53:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 10:59:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 10:59:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 11:02:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 11:02:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 11:03:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 11:03:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 11:04:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 11:04:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 11:09:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 11:09:23 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 11:25:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 11:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 11:28:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 11:28:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 11:29:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 11:29:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 11:29:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 11:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 11:33:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 11:33:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 11:55:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 11:55:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 12:00:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 12:00:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 12:20:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:20:20 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:20:39 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-09-28 12:23:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:23:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:23:33 --> 404 Page Not Found: Env/index
ERROR - 2023-09-28 12:26:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:26:46 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:29:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:29:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:30:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:30:56 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:32:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:32:28 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 12:33:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 12:33:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 13:03:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 13:10:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 13:10:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 13:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 13:11:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 13:13:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 13:13:59 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 13:18:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 13:20:36 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-28 13:24:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 13:24:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 13:26:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 13:26:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 13:30:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 13:30:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 14:03:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:04:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:05:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:06:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:07:46 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 14:08:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:08:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 14:08:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:08:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 14:10:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 14:10:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 15:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 15:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 15:26:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 15:33:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 15:33:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 16:42:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 16:42:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 16:42:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 16:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 16:46:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 16:53:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 16:53:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 16:57:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 16:57:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 17:03:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 17:06:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 17:06:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 17:11:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 17:11:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 17:16:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 17:16:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 17:52:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 17:53:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 17:56:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 17:56:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 18:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 18:11:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 18:11:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 18:14:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 18:14:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 18:14:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 18:15:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 18:15:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 18:16:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 18:21:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 18:49:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 19:40:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 19:40:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 19:56:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 20:14:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 20:14:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 20:14:50 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 20:14:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 20:14:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 20:19:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:19:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:19:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:19:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:19:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:23:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:23:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:24:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:24:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:25:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:25:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:26:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-28 20:26:44 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-28 20:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 21:13:27 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-28 21:13:28 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-28 21:15:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 21:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 21:23:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 21:23:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 21:24:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 21:25:39 --> 404 Page Not Found: Log/index
ERROR - 2023-09-28 21:25:50 --> 404 Page Not Found: Uploads/pages
ERROR - 2023-09-28 21:30:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 21:39:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 21:39:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 21:39:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:00:36 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-09-28 22:00:39 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-09-28 22:00:44 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-28 22:00:49 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-09-28 22:00:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:00:58 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-28 22:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:03:03 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-28 22:04:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:04:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:04:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:04:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:07:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:07:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:07:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 22:21:45 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 22:21:45 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 22:21:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:49:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:49:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 22:50:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:50:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 22:56:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 22:56:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 23:02:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 23:02:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 23:51:02 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 23:51:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 23:51:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-28 23:51:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 23:51:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-28 23:51:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-28 23:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 23:53:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-28 23:53:45 --> 404 Page Not Found: Assets/frontend
