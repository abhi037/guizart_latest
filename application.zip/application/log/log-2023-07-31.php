<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-31 00:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-31 00:17:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 00:17:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 01:10:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 01:10:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 02:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 02:56:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-31 03:52:38 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 03:52:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-31 04:05:23 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 04:05:23 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 05:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 05:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 06:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 07:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 08:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 08:03:26 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-31 09:04:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-31 09:08:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 09:08:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 09:32:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 09:32:25 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-07-31 09:32:25 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-loadphp/index
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Cache/indexx.php
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-07-31 09:32:26 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-07-31 09:39:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 10:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 11:58:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 12:43:40 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-07-31 13:50:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:50:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:50:51 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-31 13:50:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1226): User 'u208937329_quizartuser' has exceeded the 'max_user_connections' resource (current value: 25) /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-31 13:50:52 --> Unable to connect to the database
ERROR - 2023-07-31 13:50:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1226): User 'u208937329_quizartuser' has exceeded the 'max_user_connections' resource (current value: 25) /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-31 13:50:52 --> Unable to connect to the database
ERROR - 2023-07-31 13:50:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1226): User 'u208937329_quizartuser' has exceeded the 'max_user_connections' resource (current value: 25) /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-31 13:50:53 --> Unable to connect to the database
ERROR - 2023-07-31 13:50:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:51:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:52:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:52:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:52:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:52:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 13:58:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 14:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 14:03:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 14:03:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 14:18:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 14:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 14:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 14:50:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 17:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 17:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 18:49:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:49:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:49:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:49:22 --> 404 Page Not Found: Log/index
ERROR - 2023-07-31 18:49:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:49:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:49:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:50:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:50:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:50:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:53:05 --> 404 Page Not Found: Log/index
ERROR - 2023-07-31 18:53:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:53:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:53:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:53:45 --> 404 Page Not Found: Log/index
ERROR - 2023-07-31 18:53:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:53:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:53:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:54:03 --> 404 Page Not Found: Log/index
ERROR - 2023-07-31 18:54:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:54:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:54:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:54:20 --> 404 Page Not Found: Log/index
ERROR - 2023-07-31 18:54:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:54:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:54:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:55:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 18:55:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 18:55:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 19:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 19:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 19:29:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 19:29:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 19:29:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 19:29:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 20:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 20:00:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 20:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 20:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 20:23:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 20:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 20:23:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 20:23:08 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-07-31 20:23:09 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-31 20:23:16 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-31 20:23:19 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-07-31 20:23:21 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-07-31 20:23:22 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-31 20:23:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 20:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 20:23:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 20:23:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 21:01:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 21:01:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 21:01:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 21:01:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 21:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 21:04:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 21:04:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 21:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 21:34:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-31 22:08:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 22:08:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-31 22:51:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-31 23:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 23:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-31 23:19:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 23:19:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-31 23:59:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
