<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-25 01:29:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 01:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-25 01:29:48 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-25 01:29:58 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-05-25 01:29:59 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-05-25 01:29:59 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-05-25 01:29:59 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2023-05-25 01:30:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 01:30:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 01:30:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-25 01:30:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-25 01:42:10 --> 404 Page Not Found: Merchant/z
ERROR - 2023-05-25 01:42:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 01:42:12 --> 404 Page Not Found: Merchant/z
ERROR - 2023-05-25 01:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 01:42:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 01:42:14 --> 404 Page Not Found: Merchant/code
ERROR - 2023-05-25 01:42:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 01:42:15 --> 404 Page Not Found: Merchant/code
ERROR - 2023-05-25 01:42:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 01:42:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 02:28:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 02:28:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-25 05:55:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 07:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-25 07:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-25 07:38:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 07:38:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-25 07:41:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 07:41:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 07:44:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 07:49:47 --> 404 Page Not Found: Test_404_page/index
ERROR - 2023-05-25 08:03:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 08:03:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-25 12:05:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 12:05:36 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-05-25 16:03:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 16:03:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-05-25 19:46:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 22:03:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-25 22:03:47 --> 404 Page Not Found: Faviconico/index
