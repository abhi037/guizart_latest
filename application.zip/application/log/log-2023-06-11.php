<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-11 02:06:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 02:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-11 02:06:42 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:06:56 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:06:57 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:06:58 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:58 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:06:59 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:59 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:06:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:07:00 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:07:01 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:07:02 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:02 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:07:03 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-11 02:07:04 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-11 02:07:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-11 02:07:57 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-11 02:07:57 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-11 02:07:58 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-06-11 02:07:58 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2023-06-11 02:07:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 02:08:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 02:08:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-11 02:08:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-11 06:13:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 07:33:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 07:57:49 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-06-11 07:57:52 --> 404 Page Not Found: Public/_ignition
ERROR - 2023-06-11 10:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 13:21:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 15:09:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 17:59:08 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-06-11 17:59:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 17:59:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-11 21:29:01 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-06-11 21:29:07 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-06-11 21:29:21 --> 404 Page Not Found: Rindexphp/index
ERROR - 2023-06-11 21:29:23 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-06-11 21:29:29 --> 404 Page Not Found: Wp-admin/xl2023.php
ERROR - 2023-06-11 21:29:35 --> 404 Page Not Found: Seophp/index
ERROR - 2023-06-11 21:29:37 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-06-11 21:29:40 --> 404 Page Not Found: Xl2023xphp/index
ERROR - 2023-06-11 22:06:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
