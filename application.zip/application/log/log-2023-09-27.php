<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-27 00:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 00:01:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:02:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:02:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 00:08:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:37:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:38:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:38:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:38:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:38:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:39:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:40:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:57:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 00:57:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:57:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 00:59:05 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-27 01:12:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 01:12:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 01:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 01:53:46 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-09-27 01:53:46 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-27 01:58:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 02:09:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 02:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 02:09:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 02:09:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 02:09:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:16:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 02:16:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:16:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:16:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 02:16:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:36:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 02:36:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 03:16:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 03:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 03:37:29 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1068
ERROR - 2023-09-27 03:37:29 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/successpage.php 1
ERROR - 2023-09-27 03:37:30 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1068
ERROR - 2023-09-27 03:37:30 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/successpage.php 1
ERROR - 2023-09-27 04:13:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 04:14:02 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-27 04:14:06 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-27 04:14:13 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-27 04:14:17 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-27 04:14:21 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-27 04:17:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 04:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 05:12:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 06:46:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 06:56:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 06:56:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 06:57:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 07:10:23 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-27 07:10:24 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-09-27 07:11:01 --> 404 Page Not Found: Env/index
ERROR - 2023-09-27 07:11:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 07:27:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 07:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 07:40:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 07:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 08:02:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:02:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:02:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:03:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:03:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:04:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:04:45 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:09:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:09:29 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:13:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:13:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:14:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:14:05 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:15:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:15:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:16:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:16:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:18:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:18:11 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:19:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:19:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:37:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:37:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:38:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:38:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:41:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:41:38 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 08:43:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:43:11 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:47:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:47:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:48:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:48:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:51:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:51:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:52:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:52:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:54:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:54:21 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 08:55:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 08:55:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:01:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:01:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:02:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:02:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:03:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:03:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:04:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:04:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:07:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:07:23 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:09:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:09:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:11:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:11:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:12:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:12:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:19:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:19:33 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:21:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:21:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:21:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:21:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 09:28:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 09:28:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 09:30:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:30:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:31:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:32:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:32:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:32:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:32:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:33:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:33:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:33:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:33:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:34:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:34:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:39:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:39:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:45:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:45:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:45:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:46:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:46:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:47:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:47:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:47:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:49:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:49:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:49:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:49:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:50:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 09:50:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 09:55:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 10:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 10:07:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 10:11:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 10:27:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 10:27:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 10:32:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 10:32:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 10:53:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 10:57:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 10:57:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 10:57:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 11:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 11:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 11:07:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 11:11:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 11:18:25 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-27 11:18:31 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-09-27 11:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 11:20:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 11:20:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 11:22:46 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 11:22:46 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 11:26:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:26:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:29:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:29:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:38:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:38:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:38:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:38:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:40:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:40:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:42:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:42:50 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:44:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:44:29 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:45:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:45:50 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:47:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:47:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:47:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:47:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:48:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:48:40 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:50:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 11:50:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 11:57:56 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 12:01:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 12:01:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 12:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 12:20:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:20:54 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:24:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:24:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:27:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:27:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:28:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:28:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 12:29:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 12:31:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:31:22 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:32:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:32:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:37:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:37:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:37:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:37:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:41:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:41:31 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:43:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:43:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:53:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:53:54 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:54:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:54:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:56:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:56:06 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:56:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 12:58:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 12:58:26 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 13:01:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-27 13:04:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 13:10:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:10:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:13:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 13:13:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:13:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:14:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:14:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:27:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:27:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:29:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:29:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:40:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:40:20 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:44:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:44:19 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:51:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:51:26 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:52:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:52:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 13:56:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 13:57:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 13:57:46 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:00:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:00:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:05:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:05:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:06:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:06:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:10:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:10:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:12:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:12:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:31:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:31:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:33:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:33:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:35:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:35:33 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:38:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:38:18 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:40:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:40:25 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:42:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:42:01 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:43:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 14:45:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:45:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:46:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 14:46:29 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 14:52:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 14:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 14:55:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 14:55:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 15:04:55 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 15:04:55 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 15:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 15:09:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 15:09:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 15:09:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 15:09:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 15:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 15:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 15:15:36 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-27 15:15:37 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-27 15:15:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 15:33:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 15:42:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 15:42:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 15:44:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 15:44:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 15:47:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 15:47:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 15:48:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 15:48:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:04:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:04:44 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:09:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:09:02 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:12:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:12:46 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:19:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:19:56 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:20:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:21:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:22:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:22:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:22:21 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:22:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:22:26 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:22:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:22:31 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 16:24:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 16:24:05 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 17:00:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 17:00:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 17:03:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 17:17:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 17:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 17:20:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 17:20:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 17:21:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 17:40:02 --> 404 Page Not Found: Home/assets
ERROR - 2023-09-27 18:12:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 18:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 18:32:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 18:32:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 18:43:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 18:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 19:15:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 19:15:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 19:15:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 19:16:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 19:16:11 --> 404 Page Not Found: Log/index
ERROR - 2023-09-27 19:16:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:16:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:16:16 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:16:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:16:30 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:16:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:16:34 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:21:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:21:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:21:51 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:23:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:23:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:23:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:23:20 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 19:26:38 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 19:26:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 19:26:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:26:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:28:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:30:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:30:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 19:31:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 19:31:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 19:32:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:32:15 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 19:38:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 19:46:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:46:48 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:48:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:48:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:53:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:53:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:55:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:55:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 19:56:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-27 19:56:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-27 20:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 20:36:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 20:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 20:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 20:58:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 20:58:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 20:58:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-27 21:07:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 21:09:02 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-27 21:13:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-27 21:51:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 21:51:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 21:51:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 21:51:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 21:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 22:12:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 22:12:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 22:45:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 22:45:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 22:45:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 22:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-27 22:51:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 22:51:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-27 22:51:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:04:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 23:04:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:04:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:12:54 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-27 23:19:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-27 23:19:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:19:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:19:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-27 23:20:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
