<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-25 01:52:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 01:52:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:52:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:53:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:53:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:53:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:53:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 01:54:00 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('7565f5e7944cef1aa28cd97eeee7de2d') AS ci_session_lock
ERROR - 2023-07-25 01:54:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 02:00:50 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-07-25 02:03:44 --> 404 Page Not Found: Wp-includes/customize
ERROR - 2023-07-25 02:04:03 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-07-25 02:34:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 02:34:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 02:34:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 02:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 02:56:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 03:05:33 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-07-25 03:05:34 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-07-25 03:05:35 --> 404 Page Not Found: 1php/index
ERROR - 2023-07-25 03:05:35 --> 404 Page Not Found: 404php/index
ERROR - 2023-07-25 03:05:37 --> 404 Page Not Found: 403php/index
ERROR - 2023-07-25 03:05:37 --> 404 Page Not Found: Initphp/index
ERROR - 2023-07-25 03:05:38 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-07-25 03:05:38 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-07-25 03:05:39 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-07-25 03:05:39 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-07-25 03:05:40 --> 404 Page Not Found: Docphp/index
ERROR - 2023-07-25 03:05:40 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-07-25 03:05:41 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-07-25 03:05:41 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-07-25 03:05:42 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-07-25 03:05:43 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-07-25 03:05:43 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-07-25 03:05:44 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-07-25 03:05:44 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-07-25 03:05:45 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-07-25 03:05:45 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-07-25 03:05:46 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-07-25 03:05:46 --> 404 Page Not Found: Upphp/index
ERROR - 2023-07-25 03:05:47 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-07-25 03:05:47 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-07-25 03:05:48 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-07-25 03:05:49 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-07-25 03:05:49 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-07-25 03:05:50 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-07-25 03:05:50 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-07-25 03:05:51 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-07-25 03:05:51 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-07-25 03:05:52 --> 404 Page Not Found: Mphp/index
ERROR - 2023-07-25 03:05:52 --> 404 Page Not Found: 503php/index
ERROR - 2023-07-25 03:05:53 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-07-25 03:05:53 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-07-25 03:05:54 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-07-25 03:05:54 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-07-25 03:05:54 --> 404 Page Not Found: Massphp/index
ERROR - 2023-07-25 03:05:55 --> 404 Page Not Found: 1337php/index
ERROR - 2023-07-25 03:05:55 --> 404 Page Not Found: 1877php/index
ERROR - 2023-07-25 03:05:56 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-07-25 03:05:56 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-07-25 03:05:57 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-07-25 03:05:57 --> 404 Page Not Found: Index2php/index
ERROR - 2023-07-25 03:05:57 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-07-25 03:05:58 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-07-25 03:05:58 --> 404 Page Not Found: Marphp/index
ERROR - 2023-07-25 03:05:59 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-07-25 03:05:59 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-07-25 03:06:00 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-07-25 03:06:00 --> 404 Page Not Found: Shphp/index
ERROR - 2023-07-25 03:06:00 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-07-25 03:06:01 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-07-25 03:06:01 --> 404 Page Not Found: Symphp/index
ERROR - 2023-07-25 03:06:02 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-07-25 03:06:02 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-07-25 03:06:03 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-07-25 03:06:03 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-07-25 03:06:04 --> 404 Page Not Found: Anphp/index
ERROR - 2023-07-25 03:06:04 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-07-25 03:06:04 --> 404 Page Not Found: Xphp/index
ERROR - 2023-07-25 03:06:05 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-07-25 03:06:05 --> 404 Page Not Found: Byphp/index
ERROR - 2023-07-25 03:06:06 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-07-25 03:06:06 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-07-25 03:06:07 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-07-25 03:06:07 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-07-25 03:06:07 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-07-25 03:06:08 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-07-25 03:06:08 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-07-25 03:06:09 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-07-25 03:06:09 --> 404 Page Not Found: Userphp/index
ERROR - 2023-07-25 03:06:10 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-07-25 03:06:10 --> 404 Page Not Found: Zphp/index
ERROR - 2023-07-25 03:06:11 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-07-25 03:06:11 --> 404 Page Not Found: Chphp/index
ERROR - 2023-07-25 03:06:12 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-07-25 03:06:12 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-07-25 03:06:12 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-07-25 03:06:13 --> 404 Page Not Found: Madphp/index
ERROR - 2023-07-25 03:06:13 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-07-25 03:06:14 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-07-25 03:06:14 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-07-25 03:06:15 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-07-25 03:06:15 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-07-25 03:06:15 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-07-25 03:06:16 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-07-25 03:06:16 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-07-25 03:06:17 --> 404 Page Not Found: Endphp/index
ERROR - 2023-07-25 03:06:17 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-07-25 03:06:18 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-07-25 03:06:18 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-07-25 03:06:19 --> 404 Page Not Found: __1975php/index
ERROR - 2023-07-25 03:06:19 --> 404 Page Not Found: Killphp/index
ERROR - 2023-07-25 03:06:20 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-07-25 03:06:20 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-07-25 03:06:21 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-07-25 03:06:22 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-07-25 03:06:22 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-07-25 03:06:23 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-07-25 03:06:23 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-07-25 03:06:24 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-07-25 03:06:24 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-07-25 03:06:25 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-07-25 03:06:25 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-07-25 03:06:26 --> 404 Page Not Found: Logphp/index
ERROR - 2023-07-25 03:06:26 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-07-25 03:06:26 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-07-25 03:06:27 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-07-25 03:06:27 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-07-25 03:06:28 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-07-25 03:06:28 --> 404 Page Not Found: Demophp/index
ERROR - 2023-07-25 03:06:29 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-07-25 03:06:29 --> 404 Page Not Found: Motophp/index
ERROR - 2023-07-25 03:06:30 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-07-25 03:06:30 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:06:31 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-07-25 03:06:31 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-07-25 03:06:32 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-07-25 03:06:32 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-07-25 03:06:33 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-07-25 03:06:33 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-07-25 03:06:34 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-07-25 03:06:34 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-07-25 03:06:35 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-07-25 03:06:35 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-07-25 03:06:36 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-07-25 03:06:36 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-07-25 03:06:36 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-07-25 03:06:37 --> 404 Page Not Found: 1975php/index
ERROR - 2023-07-25 03:06:37 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-07-25 03:06:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:38 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-07-25 03:06:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:40 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-07-25 03:06:40 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-07-25 03:06:41 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:06:41 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-07-25 03:06:42 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-07-25 03:06:42 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-07-25 03:06:43 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-07-25 03:06:43 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-07-25 03:06:43 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-07-25 03:06:44 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-07-25 03:06:44 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-07-25 03:06:45 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-07-25 03:06:45 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-07-25 03:06:46 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-07-25 03:06:46 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-07-25 03:06:47 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-07-25 03:06:47 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-07-25 03:06:48 --> 404 Page Not Found: Mephp/index
ERROR - 2023-07-25 03:06:48 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-07-25 03:06:49 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-07-25 03:06:49 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-07-25 03:06:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:51 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-07-25 03:06:52 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-07-25 03:06:52 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-07-25 03:06:53 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-07-25 03:06:53 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-07-25 03:06:54 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-07-25 03:06:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:55 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:06:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:06:57 --> 404 Page Not Found: Sites/all
ERROR - 2023-07-25 03:06:58 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-07-25 03:06:58 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-07-25 03:06:58 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-07-25 03:06:59 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-07-25 03:06:59 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-07-25 03:07:00 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-07-25 03:07:00 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-07-25 03:07:01 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-07-25 03:07:01 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-07-25 03:07:02 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-07-25 03:07:02 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-07-25 03:07:03 --> 404 Page Not Found: Termphp/index
ERROR - 2023-07-25 03:07:03 --> 404 Page Not Found: Textphp/index
ERROR - 2023-07-25 03:07:04 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-07-25 03:07:04 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-07-25 03:07:05 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-07-25 03:07:05 --> 404 Page Not Found: Homephp/index
ERROR - 2023-07-25 03:07:05 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-07-25 03:07:06 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-07-25 03:07:06 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-07-25 03:07:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:07 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:07:08 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-25 03:07:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:09 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-07-25 03:07:09 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-07-25 03:07:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:10 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-07-25 03:07:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:13 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-07-25 03:07:14 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-07-25 03:07:14 --> 404 Page Not Found: 406php/index
ERROR - 2023-07-25 03:07:15 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-25 03:07:15 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-07-25 03:07:16 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-07-25 03:07:16 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-07-25 03:07:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:07:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:20 --> 404 Page Not Found: D7php/index
ERROR - 2023-07-25 03:07:20 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-07-25 03:07:21 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-07-25 03:07:21 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-07-25 03:07:22 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:22 --> 404 Page Not Found: Eephp/index
ERROR - 2023-07-25 03:07:22 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-07-25 03:07:23 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-07-25 03:07:23 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-25 03:07:24 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-07-25 03:07:24 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-07-25 03:07:25 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-07-25 03:07:25 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-07-25 03:07:26 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-07-25 03:07:26 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-07-25 03:07:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 03:07:27 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-07-25 03:07:28 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-07-25 03:07:28 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-25 03:07:29 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-07-25 03:07:29 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-07-25 03:07:29 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-07-25 03:07:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-25 04:11:42 --> 404 Page Not Found: Wp-includes/IXR
ERROR - 2023-07-25 05:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 05:01:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 05:02:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 05:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 06:15:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 07:00:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 07:00:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 07:38:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 07:54:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 07:55:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 08:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 08:53:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 08:53:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 08:55:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 09:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 11:06:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 11:11:37 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-25 13:02:41 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-25 13:29:56 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-07-25 13:52:25 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-07-25 16:32:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:51:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:56:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:56:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:56:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:56:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:56:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:56:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:56:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:56:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:56:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:57:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:57:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:57:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:58:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:58:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 16:58:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 16:58:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 18:01:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 18:01:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 18:01:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 18:31:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 18:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 18:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 19:28:21 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-07-25 19:28:29 --> 404 Page Not Found: Sites/default
ERROR - 2023-07-25 19:28:47 --> 404 Page Not Found: Admin/controller
ERROR - 2023-07-25 19:35:07 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-07-25 19:48:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 20:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 20:13:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-25 22:12:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 22:12:19 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-25 23:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-25 23:48:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 23:56:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 23:56:40 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-25 23:56:41 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-07-25 23:56:42 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-07-25 23:56:43 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-25 23:56:45 --> 404 Page Not Found: Blog/index
ERROR - 2023-07-25 23:56:46 --> 404 Page Not Found: New/index
ERROR - 2023-07-25 23:56:49 --> 404 Page Not Found: Newsite/index
ERROR - 2023-07-25 23:56:50 --> 404 Page Not Found: Test/index
ERROR - 2023-07-25 23:56:50 --> 404 Page Not Found: Main/index
ERROR - 2023-07-25 23:56:52 --> 404 Page Not Found: Testing/index
ERROR - 2023-07-25 23:56:53 --> 404 Page Not Found: Site/index
ERROR - 2023-07-25 23:56:58 --> 404 Page Not Found: Demo/index
ERROR - 2023-07-25 23:57:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 23:57:04 --> 404 Page Not Found: Tmp/index
ERROR - 2023-07-25 23:57:05 --> 404 Page Not Found: Dev/index
ERROR - 2023-07-25 23:57:07 --> 404 Page Not Found: Cms/index
ERROR - 2023-07-25 23:57:08 --> 404 Page Not Found: Portal/index
ERROR - 2023-07-25 23:57:09 --> 404 Page Not Found: Web/index
ERROR - 2023-07-25 23:59:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-25 23:59:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
