<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-27 00:16:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 01:47:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 01:47:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 01:48:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-27 01:48:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 01:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-27 01:48:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 01:50:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 03:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-27 03:23:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 04:33:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 10:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-27 12:02:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:24:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:24:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:24:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:25:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:25:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:25:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:25:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:25:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:27:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:27:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:27:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-27 12:28:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:28:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 12:28:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:28:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 12:31:09 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-27 14:44:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 14:45:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 14:45:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 14:50:13 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-27 14:50:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 14:50:36 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-27 14:50:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 14:50:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 14:50:56 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-27 14:50:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 14:56:10 --> Severity: Notice --> Undefined offset: 0 /home4/demouake/public_html/application/controllers/Home.php 1094
ERROR - 2023-05-27 14:56:10 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-27 14:56:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 15:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-27 18:02:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 18:02:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 18:02:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 18:02:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-27 18:02:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-27 18:02:12 --> 404 Page Not Found: Assets/frontend
