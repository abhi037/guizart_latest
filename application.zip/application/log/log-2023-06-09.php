<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-09 05:32:54 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-09 05:32:54 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-09 12:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-09 12:08:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 12:08:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-09 12:08:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-09 12:09:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-09 12:11:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 12:11:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-09 12:11:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-09 13:28:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 16:19:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 21:51:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 21:52:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-09 21:52:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
