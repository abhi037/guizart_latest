<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-18 01:12:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 01:12:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 01:12:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 01:12:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 02:01:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:01:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 02:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 02:24:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:24:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:25:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:25:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:25:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:25:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 02:34:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:34:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 02:41:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:41:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 02:53:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:53:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 02:59:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 02:59:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 03:24:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 03:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 03:33:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 03:33:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 03:48:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 03:48:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 05:06:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 05:06:59 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-18 05:07:00 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-18 05:07:01 --> 404 Page Not Found: Old1/index
ERROR - 2023-09-18 05:07:02 --> 404 Page Not Found: Old2/index
ERROR - 2023-09-18 05:07:02 --> 404 Page Not Found: OLDSITE/index
ERROR - 2023-09-18 05:07:03 --> 404 Page Not Found: Beta/index
ERROR - 2023-09-18 05:07:04 --> 404 Page Not Found: Staging/index
ERROR - 2023-09-18 05:07:05 --> 404 Page Not Found: BKP/index
ERROR - 2023-09-18 05:07:05 --> 404 Page Not Found: Old-site/index
ERROR - 2023-09-18 05:07:06 --> 404 Page Not Found: Oldwebsite/index
ERROR - 2023-09-18 05:07:07 --> 404 Page Not Found: Blog/index
ERROR - 2023-09-18 05:07:07 --> 404 Page Not Found: Dev/index
ERROR - 2023-09-18 05:07:08 --> 404 Page Not Found: Test/index
ERROR - 2023-09-18 05:07:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 05:07:10 --> 404 Page Not Found: BACKUP/index
ERROR - 2023-09-18 05:07:11 --> 404 Page Not Found: Old_files/index
ERROR - 2023-09-18 05:07:11 --> 404 Page Not Found: Old/index
ERROR - 2023-09-18 05:07:12 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-18 05:07:15 --> 404 Page Not Found: BAK/index
ERROR - 2023-09-18 05:26:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 06:05:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 06:05:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 06:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 06:53:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 06:53:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 07:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 07:54:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 07:56:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 08:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 08:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 09:46:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 09:47:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 09:50:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 09:50:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 09:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 09:51:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 09:52:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 09:57:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 10:44:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 10:44:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 11:08:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 11:08:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 11:10:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 11:10:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 11:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 12:06:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 12:06:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 12:06:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 12:06:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 12:06:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 14:58:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 14:58:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 14:58:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 14:58:55 --> 404 Page Not Found: Log/index
ERROR - 2023-09-18 14:58:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 14:59:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 14:59:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 14:59:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 16:33:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:23:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:23:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:23:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:24:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:32:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:32:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 17:40:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:41:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:42:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:42:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:43:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:44:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 17:45:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 17:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 17:55:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:29:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:30:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:31:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:31:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:31:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:38:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 18:38:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 18:39:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 18:39:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 19:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 19:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-18 19:59:52 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-18 19:59:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-18 20:16:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-18 20:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 20:52:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 20:52:59 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-18 21:36:56 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-18 21:36:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 21:36:57 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-18 21:36:58 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-18 21:36:59 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-18 21:37:01 --> 404 Page Not Found: New/index
ERROR - 2023-09-18 21:37:02 --> 404 Page Not Found: Main/index
ERROR - 2023-09-18 21:37:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 21:51:25 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-18 21:51:34 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-09-18 21:51:48 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-09-18 21:51:56 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-09-18 21:52:08 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-09-18 21:52:16 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-09-18 21:52:27 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-18 21:52:34 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-09-18 21:52:44 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-09-18 21:52:51 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-18 21:52:58 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-18 21:53:07 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-18 21:53:17 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-18 21:53:26 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-09-18 21:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 22:41:45 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-18 22:46:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:47:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:48:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:48:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:49:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 22:49:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:02:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:02:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:02:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 23:41:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 23:50:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-18 23:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 23:54:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
