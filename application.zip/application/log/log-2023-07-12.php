<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-12 04:31:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 05:39:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 08:48:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 08:48:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 14:15:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 14:15:46 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-07-12 14:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-12 14:47:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 17:48:52 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-12 17:49:04 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-07-12 17:49:40 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-07-12 17:49:52 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-07-12 19:30:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-12 19:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-12 19:50:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
