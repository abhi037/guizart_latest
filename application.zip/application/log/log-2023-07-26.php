<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-26 01:00:39 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-26 01:05:42 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-07-26 01:17:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 04:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-26 06:16:09 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 06:16:09 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 07:38:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 08:35:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 08:38:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 08:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 09:02:39 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-26 11:16:32 --> 404 Page Not Found: Home/Log In
ERROR - 2023-07-26 12:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 12:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 12:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 12:55:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 14:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 14:36:32 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-26 14:45:55 --> 404 Page Not Found: Home/Log In
ERROR - 2023-07-26 15:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 15:17:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 15:22:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 15:22:33 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-07-26 15:22:33 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-07-26 15:22:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 15:22:34 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-07-26 15:22:34 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-07-26 15:22:34 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-07-26 15:22:34 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-07-26 15:22:34 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-07-26 15:22:35 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-07-26 15:22:35 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2023-07-26 15:22:35 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-07-26 15:22:35 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-07-26 15:22:36 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-07-26 15:22:36 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-07-26 15:22:36 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-07-26 15:22:36 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-07-26 15:22:36 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-07-26 15:22:37 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-07-26 15:22:37 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-07-26 16:24:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 16:24:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 16:26:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 16:26:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 16:28:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 17:17:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 17:17:31 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-26 17:17:32 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-26 17:17:32 --> 404 Page Not Found: Blog/index
ERROR - 2023-07-26 17:17:33 --> 404 Page Not Found: New/index
ERROR - 2023-07-26 17:17:34 --> 404 Page Not Found: Test/index
ERROR - 2023-07-26 17:17:35 --> 404 Page Not Found: Main/index
ERROR - 2023-07-26 17:17:35 --> 404 Page Not Found: Testing/index
ERROR - 2023-07-26 17:21:33 --> 404 Page Not Found: Home/Log In
ERROR - 2023-07-26 18:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 20:04:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 20:25:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 20:32:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 20:32:15 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-26 21:41:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 21:41:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-26 21:59:32 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 21:59:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-26 22:21:12 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-07-26 22:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 22:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 22:40:46 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-07-26 22:40:53 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-07-26 22:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-26 22:41:02 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-07-26 22:41:10 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-07-26 22:41:17 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-07-26 22:41:22 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-07-26 22:43:44 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-26 22:55:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 22:55:06 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d40c1948ca1519c2a6b3f9a3f99c831823bfe63', '85.110.123.149', 1690392306, '__ci_last_regenerate|i:1690392306;cart_items|a:0:{}last_page|s:1:\"/\";')
ERROR - 2023-07-26 22:55:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 22:55:06 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('555b78b09f2a7a8237a817fc48c52b45') AS ci_session_lock
ERROR - 2023-07-26 22:55:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-26 22:55:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-26 23:43:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 23:43:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 23:43:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-26 23:44:40 --> 404 Page Not Found: Uploads/lesson_files
