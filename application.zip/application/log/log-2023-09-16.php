<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-16 00:35:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:35:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:36:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 00:37:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:21:24 --> 404 Page Not Found: Makhdamxphp/index
ERROR - 2023-09-16 03:21:25 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-09-16 03:21:25 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-16 03:21:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-16 03:21:26 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-16 03:21:26 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-16 03:21:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-16 03:21:27 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-16 03:21:28 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-16 03:21:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-16 03:21:29 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-16 03:21:29 --> 404 Page Not Found: Beencephp/index
ERROR - 2023-09-16 03:21:30 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-09-16 03:21:30 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-09-16 03:21:31 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-16 03:21:31 --> 404 Page Not Found: Modulessphp/index
ERROR - 2023-09-16 03:21:32 --> 404 Page Not Found: Wp-commentinphp/index
ERROR - 2023-09-16 03:21:32 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-09-16 03:21:33 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-16 03:21:33 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-16 03:21:34 --> 404 Page Not Found: Wordpress-seo/vendor
ERROR - 2023-09-16 03:21:34 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-16 03:21:35 --> 404 Page Not Found: Databasephp/index
ERROR - 2023-09-16 03:21:36 --> 404 Page Not Found: Wp-ccphp/index
ERROR - 2023-09-16 03:21:36 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-16 03:21:37 --> 404 Page Not Found: Xltavratphp/index
ERROR - 2023-09-16 03:21:37 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-16 03:21:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-16 03:21:38 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-09-16 03:21:38 --> 404 Page Not Found: Xleet-shellphp/index
ERROR - 2023-09-16 03:21:39 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-09-16 03:21:39 --> 404 Page Not Found: Ccx/index.php
ERROR - 2023-09-16 03:21:40 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-16 03:21:40 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-09-16 03:21:41 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-09-16 03:21:41 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-09-16 03:21:42 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-09-16 03:21:42 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-16 03:21:43 --> 404 Page Not Found: Radiophp/index
ERROR - 2023-09-16 03:21:43 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-09-16 03:21:44 --> 404 Page Not Found: 123php/index
ERROR - 2023-09-16 03:21:44 --> 404 Page Not Found: Sphp/index
ERROR - 2023-09-16 03:21:45 --> 404 Page Not Found: Iphp/index
ERROR - 2023-09-16 03:21:45 --> 404 Page Not Found: Ophp/index
ERROR - 2023-09-16 03:21:46 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-09-16 03:21:46 --> 404 Page Not Found: Alwsophp/index
ERROR - 2023-09-16 03:21:47 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-09-16 03:21:47 --> 404 Page Not Found: Uphp/index
ERROR - 2023-09-16 03:21:47 --> 404 Page Not Found: Templates/beez5
ERROR - 2023-09-16 03:21:48 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-16 03:21:48 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-09-16 03:21:49 --> 404 Page Not Found: Xphp/index
ERROR - 2023-09-16 03:21:49 --> 404 Page Not Found: 404php/index
ERROR - 2023-09-16 03:21:50 --> 404 Page Not Found: 13php/index
ERROR - 2023-09-16 03:21:50 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-09-16 03:21:51 --> 404 Page Not Found: 11indexphp/index
ERROR - 2023-09-16 03:21:51 --> 404 Page Not Found: Wp-uploadsphp/index
ERROR - 2023-09-16 03:21:52 --> 404 Page Not Found: Shphp/index
ERROR - 2023-09-16 03:21:52 --> 404 Page Not Found: Kphp/index
ERROR - 2023-09-16 03:21:53 --> 404 Page Not Found: Wikindexphp/index
ERROR - 2023-09-16 03:21:53 --> 404 Page Not Found: Yphp/index
ERROR - 2023-09-16 03:21:54 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-09-16 03:21:54 --> 404 Page Not Found: WSOphp/index
ERROR - 2023-09-16 03:21:55 --> 404 Page Not Found: 10php/index
ERROR - 2023-09-16 03:21:55 --> 404 Page Not Found: 2indexphp/index
ERROR - 2023-09-16 03:21:56 --> 404 Page Not Found: Mariphp/index
ERROR - 2023-09-16 03:21:56 --> 404 Page Not Found: 1php/index
ERROR - 2023-09-16 03:21:57 --> 404 Page Not Found: 100php/index
ERROR - 2023-09-16 03:21:57 --> 404 Page Not Found: Wp-adminphp/index
ERROR - 2023-09-16 03:21:57 --> 404 Page Not Found: Shxphp/index
ERROR - 2023-09-16 03:21:58 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-09-16 03:21:58 --> 404 Page Not Found: Wso1php/index
ERROR - 2023-09-16 03:21:59 --> 404 Page Not Found: Docphp/index
ERROR - 2023-09-16 03:21:59 --> 404 Page Not Found: Wso2php/index
ERROR - 2023-09-16 03:22:00 --> 404 Page Not Found: Wp-content/wp.php
ERROR - 2023-09-16 03:22:00 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-09-16 03:22:01 --> 404 Page Not Found: Old-indexphp/index
ERROR - 2023-09-16 03:22:01 --> 404 Page Not Found: 9php/index
ERROR - 2023-09-16 03:22:02 --> 404 Page Not Found: Datephp/index
ERROR - 2023-09-16 03:22:02 --> 404 Page Not Found: Nphp/index
ERROR - 2023-09-16 03:22:03 --> 404 Page Not Found: Pphp/index
ERROR - 2023-09-16 03:22:03 --> 404 Page Not Found: Marphp/index
ERROR - 2023-09-16 03:22:04 --> 404 Page Not Found: 01php/index
ERROR - 2023-09-16 03:22:04 --> 404 Page Not Found: 0php/index
ERROR - 2023-09-16 03:22:04 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-09-16 03:22:05 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-09-16 03:22:05 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-16 03:22:06 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-09-16 03:22:06 --> 404 Page Not Found: Wp-content/x.php
ERROR - 2023-09-16 03:22:07 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-09-16 03:22:07 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-09-16 03:22:08 --> 404 Page Not Found: Wp-includes/about.php
ERROR - 2023-09-16 03:22:08 --> 404 Page Not Found: Qphp/index
ERROR - 2023-09-16 03:22:09 --> 404 Page Not Found: Xxxphp/index
ERROR - 2023-09-16 03:22:09 --> 404 Page Not Found: Hphp/index
ERROR - 2023-09-16 03:22:10 --> 404 Page Not Found: Aphp/index
ERROR - 2023-09-16 03:22:10 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-09-16 03:22:11 --> 404 Page Not Found: Wp-includes/991176.php
ERROR - 2023-09-16 03:22:11 --> 404 Page Not Found: Wp-admin/radio.php
ERROR - 2023-09-16 03:22:12 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-16 03:22:13 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-09-16 03:22:13 --> 404 Page Not Found: Jindexphp/index
ERROR - 2023-09-16 03:22:14 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-09-16 03:22:14 --> 404 Page Not Found: 403php/index
ERROR - 2023-09-16 03:22:15 --> 404 Page Not Found: 0bytephp/index
ERROR - 2023-09-16 03:22:15 --> 404 Page Not Found: Haxorphp/index
ERROR - 2023-09-16 03:22:16 --> 404 Page Not Found: Xlphp/index
ERROR - 2023-09-16 03:22:16 --> 404 Page Not Found: Rphp/index
ERROR - 2023-09-16 03:22:17 --> 404 Page Not Found: Hellophp/index
ERROR - 2023-09-16 03:22:17 --> 404 Page Not Found: 4php/index
ERROR - 2023-09-16 03:22:18 --> 404 Page Not Found: Gphp/index
ERROR - 2023-09-16 03:22:18 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-09-16 03:22:19 --> 404 Page Not Found: Wp-classphp/index
ERROR - 2023-09-16 03:22:19 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-16 03:22:20 --> 404 Page Not Found: Uploaderphp/index
ERROR - 2023-09-16 03:22:20 --> 404 Page Not Found: Ephp/index
ERROR - 2023-09-16 03:22:21 --> 404 Page Not Found: 2php/index
ERROR - 2023-09-16 03:22:21 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-09-16 03:22:22 --> 404 Page Not Found: Fphp/index
ERROR - 2023-09-16 03:22:22 --> 404 Page Not Found: 5php/index
ERROR - 2023-09-16 03:22:23 --> 404 Page Not Found: Vphp/index
ERROR - 2023-09-16 03:22:23 --> 404 Page Not Found: W3llstorephp/index
ERROR - 2023-09-16 03:22:24 --> 404 Page Not Found: Images/about.php
ERROR - 2023-09-16 03:22:24 --> 404 Page Not Found: Rssphp/index
ERROR - 2023-09-16 03:22:25 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-09-16 03:22:25 --> 404 Page Not Found: Mphp/index
ERROR - 2023-09-16 03:22:26 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-09-16 03:22:26 --> 404 Page Not Found: 1indexphp/index
ERROR - 2023-09-16 03:22:27 --> 404 Page Not Found: Public/403.php
ERROR - 2023-09-16 03:22:27 --> 404 Page Not Found: Blogphp/index
ERROR - 2023-09-16 03:22:28 --> 404 Page Not Found: C99php/index
ERROR - 2023-09-16 03:22:28 --> 404 Page Not Found: Autoload_classmapphp/index
ERROR - 2023-09-16 03:22:29 --> 404 Page Not Found: Bphp/index
ERROR - 2023-09-16 03:22:29 --> 404 Page Not Found: Alfashellphp/index
ERROR - 2023-09-16 03:22:30 --> 404 Page Not Found: Bypassphp/index
ERROR - 2023-09-16 03:22:30 --> 404 Page Not Found: Contentphp/index
ERROR - 2023-09-16 03:22:31 --> 404 Page Not Found: Wp-content/about.php
ERROR - 2023-09-16 03:22:31 --> 404 Page Not Found: 1337php/index
ERROR - 2023-09-16 03:22:32 --> 404 Page Not Found: 3php/index
ERROR - 2023-09-16 03:22:32 --> 404 Page Not Found: Upphp/index
ERROR - 2023-09-16 03:22:33 --> 404 Page Not Found: FoxWSOphp/index
ERROR - 2023-09-16 03:22:34 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-09-16 03:22:34 --> 404 Page Not Found: Goodsphp/index
ERROR - 2023-09-16 03:22:35 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-09-16 03:22:35 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-09-16 03:22:36 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-09-16 03:22:36 --> 404 Page Not Found: Lphp/index
ERROR - 2023-09-16 03:22:37 --> 404 Page Not Found: Wphp/index
ERROR - 2023-09-16 03:22:37 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-09-16 03:22:38 --> 404 Page Not Found: Vulnphp/index
ERROR - 2023-09-16 03:22:39 --> 404 Page Not Found: Wp2php/index
ERROR - 2023-09-16 03:22:39 --> 404 Page Not Found: Edit-formphp/index
ERROR - 2023-09-16 03:22:40 --> 404 Page Not Found: Zphp/index
ERROR - 2023-09-16 03:22:40 --> 404 Page Not Found: Cphp/index
ERROR - 2023-09-16 03:22:41 --> 404 Page Not Found: Newphp/index
ERROR - 2023-09-16 03:22:41 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-09-16 03:22:42 --> 404 Page Not Found: Okphp/index
ERROR - 2023-09-16 03:34:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:35:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:35:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:36:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:36:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 03:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 04:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:18:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 04:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 04:23:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:23:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 04:28:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:28:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 04:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 04:44:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:44:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 04:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 04:47:57 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-16 04:54:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:54:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 04:55:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 04:55:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 05:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 05:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 05:27:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 05:27:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 06:17:43 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-16 06:17:46 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-16 06:17:53 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-16 06:17:56 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-16 06:18:00 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-09-16 07:25:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 07:25:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 09:42:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 11:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 11:41:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 11:53:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 11:56:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 11:56:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 12:00:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 12:00:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 12:12:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 12:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 12:55:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 12:55:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 12:56:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 14:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 15:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 16:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 16:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 17:39:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 17:39:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 17:40:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 17:43:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 17:43:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 17:51:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 17:51:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 18:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 18:03:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 18:05:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 18:06:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 18:06:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 18:16:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 18:16:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 18:50:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 18:50:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 18:56:34 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-16 18:56:45 --> 404 Page Not Found: Inputsphp/index
ERROR - 2023-09-16 19:03:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 19:03:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 19:05:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 19:06:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 19:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 19:52:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 19:56:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 19:57:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 19:57:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 20:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-16 20:33:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 20:33:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 20:43:03 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-09-16 20:43:04 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-16 21:10:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 21:10:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 21:10:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 21:10:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-16 21:11:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 21:12:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 21:46:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 21:57:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-16 23:11:34 --> 404 Page Not Found: Adstxt/index
