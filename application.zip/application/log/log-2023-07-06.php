<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-06 00:55:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 01:36:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 09:06:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:13:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:18:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:18:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:18:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 15:18:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 15:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:18:52 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-06 15:18:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 15:18:55 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-06 15:18:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 15:19:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:04:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:04:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:20:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:20:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:20:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:20:38 --> 404 Page Not Found: Log/index
ERROR - 2023-07-06 16:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:20:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-06 16:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:22:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:22:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:22:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:22:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:22:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:22:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:22:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:27:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:27:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:27:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:27:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:27:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:27:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 16:27:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 16:27:40 --> 404 Page Not Found: Log/index
ERROR - 2023-07-06 17:01:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 17:01:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:01:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:01:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 17:01:48 --> 404 Page Not Found: Log/index
ERROR - 2023-07-06 17:01:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:01:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:02:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-07-06 17:02:32 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-06 17:02:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 17:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 17:02:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 18:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-06 18:37:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 18:37:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 18:37:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 18:37:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-06 18:37:52 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-07-06 18:38:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-06 18:38:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 18:38:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 18:38:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 18:38:25 --> 404 Page Not Found: Log/index
ERROR - 2023-07-06 18:39:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-06 18:39:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 18:39:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-06 19:02:43 --> 404 Page Not Found: Log/index
ERROR - 2023-07-06 19:18:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
