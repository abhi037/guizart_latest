<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-01 00:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-01 00:37:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-01 08:28:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 08:43:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 10:15:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 11:42:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 14:52:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 16:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-01 16:47:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 16:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-01 16:47:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 20:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-01 20:26:35 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-07-01 20:26:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-01 20:26:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-01 21:38:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
