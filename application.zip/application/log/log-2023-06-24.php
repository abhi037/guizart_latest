<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-24 00:17:19 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-24 00:17:19 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-24 03:56:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 03:57:01 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-06-24 13:53:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 13:54:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 13:54:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 13:54:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 14:05:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 14:05:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-24 14:05:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-24 14:05:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 14:05:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-24 16:14:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 16:40:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 16:40:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-24 16:40:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-24 16:40:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-24 16:40:38 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-24 16:40:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-24 16:40:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: sub_category_details /home4/demouake/public_html/application/controllers/Home.php 230
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_details /home4/demouake/public_html/application/controllers/Home.php 231
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: sub_category_name /home4/demouake/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-06-24 16:40:39 --> Severity: Notice --> Undefined variable: courses /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-24 16:40:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/demouake/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-06-24 16:40:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
