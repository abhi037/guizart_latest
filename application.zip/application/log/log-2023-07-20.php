<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-20 02:04:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 02:04:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-20 02:27:34 --> 404 Page Not Found: Merchant/z
ERROR - 2023-07-20 02:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 02:27:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 02:27:37 --> 404 Page Not Found: Merchant/z
ERROR - 2023-07-20 02:27:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 02:27:38 --> 404 Page Not Found: Merchant/code
ERROR - 2023-07-20 02:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 02:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 02:27:39 --> 404 Page Not Found: Merchant/code
ERROR - 2023-07-20 02:27:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 05:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 05:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-20 05:27:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 10:21:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 13:20:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 13:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 13:20:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 13:39:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 13:39:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-20 13:39:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-20 13:39:56 --> 404 Page Not Found: Log/index
ERROR - 2023-07-20 13:40:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-20 13:40:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-20 13:40:32 --> Severity: Notice --> Undefined variable: row /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-20 13:40:32 --> Severity: Notice --> Trying to get property 'id' of non-object /home4/demouake/public_html/application/controllers/Login.php 142
ERROR - 2023-07-20 13:40:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Input.php 430
ERROR - 2023-07-20 13:40:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/application/controllers/Login.php 149
ERROR - 2023-07-20 13:40:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/helpers/url_helper.php 561
ERROR - 2023-07-20 13:40:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 20:11:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 20:11:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 21:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 21:34:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-07-20 21:34:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 21:45:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 21:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-20 21:52:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 22:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-20 22:44:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 23:04:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-20 23:29:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
