<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-02 05:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-02 08:07:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 09:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-02 09:10:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 09:10:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-02 09:11:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-02 09:13:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 09:13:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 09:13:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 11:42:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 11:42:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 11:42:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 11:42:36 --> 404 Page Not Found: Log/index
ERROR - 2023-06-02 11:42:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-02 11:42:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 11:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-02 11:46:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 11:46:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-02 12:38:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 15:17:19 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-06-02 15:17:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 20:09:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 20:15:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 20:58:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-02 20:58:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-02 20:58:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
