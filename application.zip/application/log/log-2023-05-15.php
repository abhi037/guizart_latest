<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-15 05:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-15 06:07:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 08:53:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 08:53:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 08:53:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 08:53:56 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 08:54:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 08:54:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:02:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 09:02:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:02:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:02:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:02:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:04:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 09:04:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:04:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:04:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:04:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:06:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 09:06:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:06:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:07:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 09:07:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:07:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 09:07:16 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 12:59:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 12:59:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 13:05:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 16:22:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 16:22:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:22:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:22:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 16:22:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:22:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:22:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:22:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 16:58:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 17:20:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:22:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:22:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:25:17 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 18:25:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 18:25:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:25:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:26:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:07 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-15 18:27:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:27:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:15 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 18:27:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:27:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:27 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 18:27:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:27:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:27:37 --> 404 Page Not Found: Log/index
ERROR - 2023-05-15 18:28:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 18:28:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 18:28:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-15 20:37:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 20:37:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 20:37:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 20:37:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-15 20:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-15 20:38:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
