<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-12 02:07:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 06:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-12 07:51:10 --> 404 Page Not Found: Git/config
ERROR - 2023-06-12 08:42:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:08:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:08:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:08:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-12 15:13:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:14:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-12 15:14:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-12 15:57:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 15:57:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-12 15:57:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-12 16:39:27 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-06-12 16:39:28 --> 404 Page Not Found: Feed/index
ERROR - 2023-06-12 17:13:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-12 20:43:44 --> 404 Page Not Found: Robotstxt/index
