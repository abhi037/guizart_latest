<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-24 01:21:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 01:39:10 --> 404 Page Not Found: Merchant/z
ERROR - 2023-05-24 01:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 01:39:13 --> 404 Page Not Found: Merchant/z
ERROR - 2023-05-24 01:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 01:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 01:39:14 --> 404 Page Not Found: Merchant/code
ERROR - 2023-05-24 01:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 01:39:16 --> 404 Page Not Found: Merchant/code
ERROR - 2023-05-24 01:39:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 01:39:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 04:12:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 04:12:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-24 07:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-24 07:24:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 07:24:03 --> 404 Page Not Found: Test_404_page/index
ERROR - 2023-05-24 08:44:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 13:03:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 18:01:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-24 18:01:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
