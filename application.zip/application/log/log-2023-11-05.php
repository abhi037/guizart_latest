<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-05 00:42:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 00:42:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 00:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 00:52:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 00:52:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 01:04:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:04:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:07:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 01:11:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:11:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:11:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 01:15:48 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:15:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 01:21:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:21:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 01:26:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 01:40:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 01:40:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 01:50:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 01:50:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 02:37:57 --> 404 Page Not Found: Filemanager/dialog.php
ERROR - 2023-11-05 02:37:57 --> 404 Page Not Found: Assets/filemanager
ERROR - 2023-11-05 03:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 03:21:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 03:22:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 03:22:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 03:24:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 03:24:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 03:26:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 03:26:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 03:38:26 --> 404 Page Not Found: Env/index
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 03:48:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 03:48:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 03:48:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 04:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 04:17:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 04:46:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 05:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 06:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 07:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 07:00:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 07:00:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 07:11:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 07:11:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 07:59:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 07:59:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:08:03 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 08:08:03 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 08:08:04 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 08:08:04 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 08:08:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:09:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:09:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 08:18:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:18:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:19:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:45:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:45:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 08:47:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:47:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:49:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 08:53:33 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 08:53:33 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 08:53:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 08:55:13 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-05 08:55:13 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-11-05 09:22:27 --> 404 Page Not Found: Env/index
ERROR - 2023-11-05 09:45:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 09:45:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 09:58:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 09:58:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 11:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 11:28:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 11:56:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 12:01:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 12:01:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 12:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 12:37:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 12:37:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 12:37:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 12:57:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 12:57:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 13:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 13:08:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 13:08:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 13:55:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 13:55:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:01:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 14:04:23 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:04:23 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:04:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:08:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 14:08:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 14:19:34 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:19:34 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 14:21:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:23:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 14:23:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 14:31:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:31:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 14:31:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 14:54:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 15:06:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 15:06:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 15:39:30 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 15:39:30 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 15:39:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 15:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 16:19:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 16:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 16:21:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 17:39:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 17:39:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 17:39:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 17:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 18:32:28 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 18:51:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 18:51:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 18:52:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 18:52:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 18:52:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 18:59:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 18:59:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 19:36:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 19:36:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 19:36:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 19:49:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 19:49:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 19:54:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 19:55:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 19:56:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 20:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 20:00:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 20:00:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 20:11:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 20:11:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 20:48:59 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-11-05 20:50:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 20:50:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 20:52:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 20:52:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 20:52:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 20:59:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 20:59:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 21:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 21:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 21:08:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 21:08:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 21:09:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 21:09:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 21:22:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 21:23:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 21:58:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 21:58:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 22:08:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 22:08:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-11-05 22:44:42 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-11-05 22:44:43 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-11-05 22:44:44 --> 404 Page Not Found: 1php/index
ERROR - 2023-11-05 22:44:45 --> 404 Page Not Found: 404php/index
ERROR - 2023-11-05 22:44:46 --> 404 Page Not Found: 403php/index
ERROR - 2023-11-05 22:44:47 --> 404 Page Not Found: Initphp/index
ERROR - 2023-11-05 22:44:47 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-11-05 22:44:48 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-11-05 22:44:49 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-11-05 22:44:50 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-11-05 22:44:51 --> 404 Page Not Found: Docphp/index
ERROR - 2023-11-05 22:44:52 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-11-05 22:44:52 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-11-05 22:44:53 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-11-05 22:44:54 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-11-05 22:44:55 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-11-05 22:44:56 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-11-05 22:44:57 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-11-05 22:44:58 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-11-05 22:44:58 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-11-05 22:44:59 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-11-05 22:45:00 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-11-05 22:45:01 --> 404 Page Not Found: Upphp/index
ERROR - 2023-11-05 22:45:02 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-11-05 22:45:03 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-11-05 22:45:04 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-11-05 22:45:04 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-11-05 22:45:05 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-11-05 22:45:06 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-11-05 22:45:07 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-11-05 22:45:08 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-11-05 22:45:09 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-11-05 22:45:09 --> 404 Page Not Found: Mphp/index
ERROR - 2023-11-05 22:45:10 --> 404 Page Not Found: 503php/index
ERROR - 2023-11-05 22:45:11 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-11-05 22:45:12 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-11-05 22:45:13 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-11-05 22:45:14 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-11-05 22:45:15 --> 404 Page Not Found: Massphp/index
ERROR - 2023-11-05 22:45:15 --> 404 Page Not Found: 1337php/index
ERROR - 2023-11-05 22:45:16 --> 404 Page Not Found: 1877php/index
ERROR - 2023-11-05 22:45:17 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-11-05 22:45:18 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-11-05 22:45:19 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-11-05 22:45:20 --> 404 Page Not Found: Index2php/index
ERROR - 2023-11-05 22:45:21 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-11-05 22:45:21 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-11-05 22:45:22 --> 404 Page Not Found: Marphp/index
ERROR - 2023-11-05 22:45:23 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-11-05 22:45:24 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-11-05 22:45:25 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-11-05 22:45:26 --> 404 Page Not Found: Shphp/index
ERROR - 2023-11-05 22:45:26 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-11-05 22:45:27 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-11-05 22:45:28 --> 404 Page Not Found: Symphp/index
ERROR - 2023-11-05 22:45:29 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-11-05 22:45:30 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-11-05 22:45:31 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-11-05 22:45:31 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-11-05 22:45:32 --> 404 Page Not Found: Anphp/index
ERROR - 2023-11-05 22:45:33 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-11-05 22:45:34 --> 404 Page Not Found: Xphp/index
ERROR - 2023-11-05 22:45:35 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-11-05 22:45:36 --> 404 Page Not Found: Byphp/index
ERROR - 2023-11-05 22:45:37 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-11-05 22:45:37 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-11-05 22:45:38 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-11-05 22:45:39 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-11-05 22:45:40 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-11-05 22:45:41 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-11-05 22:45:42 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-11-05 22:45:42 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-11-05 22:45:43 --> 404 Page Not Found: Userphp/index
ERROR - 2023-11-05 22:45:44 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-11-05 22:45:45 --> 404 Page Not Found: Zphp/index
ERROR - 2023-11-05 22:45:46 --> 404 Page Not Found: Chphp/index
ERROR - 2023-11-05 22:45:47 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-11-05 22:45:48 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-11-05 22:45:48 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-11-05 22:45:49 --> 404 Page Not Found: Madphp/index
ERROR - 2023-11-05 22:45:50 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-11-05 22:45:51 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-11-05 22:45:52 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-11-05 22:45:53 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-11-05 22:45:54 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-11-05 22:45:54 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-11-05 22:45:55 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-11-05 22:45:56 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-11-05 22:45:57 --> 404 Page Not Found: Endphp/index
ERROR - 2023-11-05 22:45:58 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-11-05 22:45:59 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-11-05 22:45:59 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-11-05 22:46:00 --> 404 Page Not Found: __1975php/index
ERROR - 2023-11-05 22:46:01 --> 404 Page Not Found: Killphp/index
ERROR - 2023-11-05 22:46:02 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-11-05 22:46:03 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-11-05 22:46:04 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-11-05 22:46:05 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-11-05 22:46:05 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-11-05 22:46:07 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-11-05 22:46:08 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-11-05 22:46:09 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-11-05 22:46:09 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-11-05 22:46:10 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-11-05 22:46:11 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-11-05 22:46:12 --> 404 Page Not Found: Logphp/index
ERROR - 2023-11-05 22:46:13 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-11-05 22:46:14 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-11-05 22:46:15 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-11-05 22:46:15 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-11-05 22:46:16 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-11-05 22:46:17 --> 404 Page Not Found: Demophp/index
ERROR - 2023-11-05 22:46:18 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-11-05 22:46:19 --> 404 Page Not Found: Motophp/index
ERROR - 2023-11-05 22:46:20 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-11-05 22:46:20 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:46:21 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-11-05 22:46:22 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-11-05 22:46:23 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-11-05 22:46:24 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-11-05 22:46:25 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-11-05 22:46:26 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-11-05 22:46:27 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-11-05 22:46:27 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-11-05 22:46:28 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-11-05 22:46:29 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-11-05 22:46:30 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-11-05 22:46:31 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-11-05 22:46:32 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-11-05 22:46:32 --> 404 Page Not Found: 1975php/index
ERROR - 2023-11-05 22:46:33 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-11-05 22:46:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:46:35 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-11-05 22:46:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:46:38 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-11-05 22:46:38 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-11-05 22:46:39 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:46:40 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-11-05 22:46:41 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-11-05 22:46:42 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-11-05 22:46:43 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-11-05 22:46:43 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-11-05 22:46:44 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-11-05 22:46:45 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-11-05 22:46:46 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-11-05 22:46:47 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-11-05 22:46:48 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-11-05 22:46:48 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-11-05 22:46:49 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-11-05 22:46:50 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-11-05 22:46:51 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-11-05 22:46:52 --> 404 Page Not Found: Mephp/index
ERROR - 2023-11-05 22:46:53 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-11-05 22:46:54 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-11-05 22:46:54 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-11-05 22:46:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:46:56 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-11-05 22:46:57 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-11-05 22:46:58 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-11-05 22:46:59 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-11-05 22:46:59 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-11-05 22:47:00 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-11-05 22:47:01 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:02 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:47:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:04 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:06 --> 404 Page Not Found: Sites/all
ERROR - 2023-11-05 22:47:07 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-11-05 22:47:08 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-11-05 22:47:09 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-11-05 22:47:10 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-11-05 22:47:11 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-11-05 22:47:12 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-11-05 22:47:13 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-11-05 22:47:13 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-11-05 22:47:14 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-11-05 22:47:15 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-11-05 22:47:16 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-11-05 22:47:17 --> 404 Page Not Found: Termphp/index
ERROR - 2023-11-05 22:47:18 --> 404 Page Not Found: Textphp/index
ERROR - 2023-11-05 22:47:18 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-11-05 22:47:19 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-11-05 22:47:20 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-11-05 22:47:21 --> 404 Page Not Found: Homephp/index
ERROR - 2023-11-05 22:47:22 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-11-05 22:47:23 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-11-05 22:47:24 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-11-05 22:47:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:26 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:47:27 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-05 22:47:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:28 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-11-05 22:47:29 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-11-05 22:47:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:31 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-11-05 22:47:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:35 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-11-05 22:47:36 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-11-05 22:47:37 --> 404 Page Not Found: 406php/index
ERROR - 2023-11-05 22:47:38 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-05 22:47:39 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-11-05 22:47:39 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-11-05 22:47:40 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-11-05 22:47:41 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:47:42 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:43 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:45 --> 404 Page Not Found: D7php/index
ERROR - 2023-11-05 22:47:46 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-11-05 22:47:47 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-11-05 22:47:48 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-11-05 22:47:49 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:47:49 --> 404 Page Not Found: Eephp/index
ERROR - 2023-11-05 22:47:50 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-11-05 22:47:51 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:47:52 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-11-05 22:47:53 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-11-05 22:47:54 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-11-05 22:47:55 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-11-05 22:47:55 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-11-05 22:47:56 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-11-05 22:47:57 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-11-05 22:47:58 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-11-05 22:47:59 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-11-05 22:48:00 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-11-05 22:48:00 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-11-05 22:48:01 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-11-05 22:48:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:48:03 --> 404 Page Not Found: Wp-config-samplephp/index
ERROR - 2023-11-05 22:48:04 --> 404 Page Not Found: Cms/RxR.php
ERROR - 2023-11-05 22:48:05 --> 404 Page Not Found: Mt/RxR.php
ERROR - 2023-11-05 22:48:06 --> 404 Page Not Found: Cgi-bin/mt
ERROR - 2023-11-05 22:48:06 --> 404 Page Not Found: Vhphp/index
ERROR - 2023-11-05 22:48:07 --> 404 Page Not Found: Wwdvphp/index
ERROR - 2023-11-05 22:48:08 --> 404 Page Not Found: Wp-godzphp/index
ERROR - 2023-11-05 22:48:09 --> 404 Page Not Found: Wp-content/options-writing.php
ERROR - 2023-11-05 22:48:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:48:11 --> 404 Page Not Found: Wp-content/upgrade-functions.php
ERROR - 2023-11-05 22:48:11 --> 404 Page Not Found: Wp-content/shiromoriaty.php
ERROR - 2023-11-05 22:48:12 --> 404 Page Not Found: Clenphp/index
ERROR - 2023-11-05 22:48:13 --> 404 Page Not Found: Icwfphp/index
ERROR - 2023-11-05 22:48:14 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-11-05 22:48:15 --> 404 Page Not Found: Smmphp/index
ERROR - 2023-11-05 22:48:16 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-11-05 22:48:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:48:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-11-05 22:48:18 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-11-05 22:48:19 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-11-05 22:48:20 --> 404 Page Not Found: Alfateslaphp/index
ERROR - 2023-11-05 22:48:21 --> 404 Page Not Found: Ioxi-rexphp/index
ERROR - 2023-11-05 22:48:22 --> 404 Page Not Found: Ioxiphp/index
ERROR - 2023-11-05 22:48:22 --> 404 Page Not Found: Alfanewphp/index
ERROR - 2023-11-05 22:48:23 --> 404 Page Not Found: Alfanew2php/index
ERROR - 2023-11-05 22:48:24 --> 404 Page Not Found: Ioxi-anehphp/index
ERROR - 2023-11-05 22:48:25 --> 404 Page Not Found: Pingphp/index
ERROR - 2023-11-05 22:48:26 --> 404 Page Not Found: Alfabypassphp/index
ERROR - 2023-11-05 22:48:27 --> 404 Page Not Found: Ioxianeh3php7/index
ERROR - 2023-11-05 22:48:28 --> 404 Page Not Found: Ioxi2php/index
ERROR - 2023-11-05 23:23:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 23:23:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-11-05 23:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-11-05 23:40:28 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 23:40:28 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-11-05 23:40:29 --> 404 Page Not Found: Assets/frontend
