<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-26 03:25:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 03:38:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 04:52:30 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2023-06-26 04:52:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 11:05:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 11:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-26 11:05:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 11:05:06 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-06-26 11:05:16 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-26 11:05:16 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-06-26 11:05:17 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2023-06-26 11:05:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 11:05:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-26 11:05:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 11:05:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 11:05:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 14:16:20 --> 404 Page Not Found: _ignition/health-check
ERROR - 2023-06-26 14:16:23 --> 404 Page Not Found: Public/_ignition
ERROR - 2023-06-26 19:14:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 19:14:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:14:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:15:22 --> 404 Page Not Found: Log/index
ERROR - 2023-06-26 19:15:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-26 19:15:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:44 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-06-26 19:15:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:16:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:16:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 19:17:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-26 23:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-26 23:05:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-26 23:06:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
