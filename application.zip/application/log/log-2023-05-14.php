<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-14 00:56:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 00:58:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 00:59:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-14 00:59:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-14 01:00:39 --> 404 Page Not Found: Home/add
ERROR - 2023-05-14 01:01:54 --> 404 Page Not Found: Home/all
ERROR - 2023-05-14 03:51:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 07:43:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 11:39:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 12:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-14 12:04:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-14 12:04:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-14 12:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-14 12:05:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-14 17:54:34 --> 404 Page Not Found: Blog/wp-json
ERROR - 2023-05-14 19:41:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-14 19:41:27 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-05-14 19:41:30 --> 404 Page Not Found: Wp/index
ERROR - 2023-05-14 19:41:34 --> 404 Page Not Found: New/index
ERROR - 2023-05-14 21:33:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-14 21:33:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-14 21:33:52 --> 404 Page Not Found: Faviconico/index
