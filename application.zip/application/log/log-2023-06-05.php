<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-05 00:59:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 06:37:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:04:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:25:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:25:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:25:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:25:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:26:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:26:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:26:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:27:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:27:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-05 07:47:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 07:47:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:48:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-05 07:48:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-05 07:48:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-05 08:01:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 13:32:10 --> 404 Page Not Found: Adminerphp/index
ERROR - 2023-06-05 14:59:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 20:08:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-05 23:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-05 23:27:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
