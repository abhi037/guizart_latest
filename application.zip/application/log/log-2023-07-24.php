<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 03:12:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 03:12:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 04:01:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:45:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:45:06 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-07-24 05:45:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:45:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:45:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:45:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:03 --> 404 Page Not Found: Git/config
ERROR - 2023-07-24 05:46:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:11 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-07-24 05:46:11 --> 404 Page Not Found: About/index
ERROR - 2023-07-24 05:46:12 --> 404 Page Not Found: Debug/default
ERROR - 2023-07-24 05:46:12 --> 404 Page Not Found: V2/_catalog
ERROR - 2023-07-24 05:46:13 --> 404 Page Not Found: Ecp/Current
ERROR - 2023-07-24 05:46:14 --> 404 Page Not Found: Loginaction/index
ERROR - 2023-07-24 05:46:14 --> 404 Page Not Found: _all_dbs/index
ERROR - 2023-07-24 05:46:15 --> 404 Page Not Found: DS_Store/index
ERROR - 2023-07-24 05:46:16 --> 404 Page Not Found: Git/config
ERROR - 2023-07-24 05:46:17 --> 404 Page Not Found: Configjson/index
ERROR - 2023-07-24 05:46:17 --> 404 Page Not Found: Telescope/requests
ERROR - 2023-07-24 05:46:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:46:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 05:59:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 06:13:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 06:27:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 06:28:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 06:28:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 06:28:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 06:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-24 06:45:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 07:27:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 07:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 10:13:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 10:36:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 11:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-24 11:49:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 12:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 12:35:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 12:35:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 13:48:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 13:50:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 13:50:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 13:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 13:50:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 13:50:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 13:50:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 13:50:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:44:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'demouake_u208937329_quizart'@'localhost' (using password: YES) /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-24 15:44:28 --> Unable to connect to the database
ERROR - 2023-07-24 15:44:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'demouake_u208937329_quizart'@'localhost' (using password: YES) /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-24 15:44:37 --> Unable to connect to the database
ERROR - 2023-07-24 15:46:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'u208937329_quizartuser'@'localhost' to database 'demouake_u208937329_quizart_lis' /home/u208937329/domains/quizart.co.in/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-07-24 15:46:14 --> Unable to connect to the database
ERROR - 2023-07-24 15:46:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:46:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:46:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:57:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:57:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:57:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:57:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:57:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:57:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:57:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:57:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:57:37 --> 404 Page Not Found: Log/index
ERROR - 2023-07-24 15:57:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:58:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:58:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:58:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 15:58:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 15:58:32 --> 404 Page Not Found: Log/index
ERROR - 2023-07-24 16:15:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:15:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:15:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:15:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:15:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:15:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:15:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:15:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:15:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:15:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:17:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:17:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-24 16:18:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-24 16:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 16:51:29 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-24 19:33:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-07-24 21:30:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:31:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:31:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:31:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:31:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:32:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 21:33:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-24 23:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-24 23:32:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
