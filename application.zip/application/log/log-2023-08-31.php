<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-31 00:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 00:56:35 --> 404 Page Not Found: 404/index
ERROR - 2023-08-31 01:05:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 01:05:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 01:05:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 01:05:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 01:05:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 01:07:44 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 01:07:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 01:13:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 01:13:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 02:47:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 02:47:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 02:53:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 03:02:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 04:08:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 04:08:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 04:11:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 04:11:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 04:38:30 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-31 04:38:31 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-31 04:50:46 --> 404 Page Not Found: Env/index
ERROR - 2023-08-31 05:02:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:02:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:02:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:02:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:03:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:03:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:09:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:09:46 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-08-31 05:20:38 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-31 05:27:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:27:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:27:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 05:32:31 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 05:32:31 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 05:53:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:53:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:53:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:54:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 05:54:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:54:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 05:56:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 06:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 06:17:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 06:32:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 06:32:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 06:39:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 06:39:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 06:54:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 06:57:42 --> 404 Page Not Found: Env/index
ERROR - 2023-08-31 08:07:08 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-08-31 08:07:09 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-31 08:45:54 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-08-31 08:45:58 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 08:50:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 08:50:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 09:21:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 10:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 10:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 10:58:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 10:58:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 11:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 11:05:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 11:05:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 11:44:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 12:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 12:19:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 12:19:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 12:54:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 12:55:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 12:58:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 13:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 14:31:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 14:31:33 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-08-31 14:31:35 --> 404 Page Not Found: Wp/index
ERROR - 2023-08-31 14:31:38 --> 404 Page Not Found: Blog/index
ERROR - 2023-08-31 14:31:40 --> 404 Page Not Found: New/index
ERROR - 2023-08-31 14:47:05 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-08-31 15:01:16 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 15:28:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 15:28:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 15:35:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 15:37:34 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-08-31 16:06:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:06:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:06:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:06:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:29:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 16:31:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:31:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:33:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:41:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:41:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:51:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:51:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:51:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:51:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 16:51:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 16:51:19 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2023-08-31 16:51:20 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2023-08-31 17:08:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 17:08:02 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-31 17:08:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 17:08:03 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-08-31 17:08:03 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-31 17:08:04 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-08-31 17:08:04 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-31 17:08:04 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-31 17:08:05 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-31 17:08:05 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-31 17:08:06 --> 404 Page Not Found: Eephp/index
ERROR - 2023-08-31 17:08:06 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-08-31 17:08:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 17:08:07 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-08-31 17:08:07 --> 404 Page Not Found: Installphp/index
ERROR - 2023-08-31 17:08:08 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-08-31 17:08:08 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-31 17:08:08 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-08-31 17:08:09 --> 404 Page Not Found: Css/install.php
ERROR - 2023-08-31 17:08:09 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-31 17:08:10 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-31 17:08:10 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-31 17:08:10 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-31 17:08:11 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-31 17:08:11 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-08-31 17:08:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 17:08:12 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-08-31 17:21:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 17:35:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 17:54:24 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-08-31 17:54:27 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2023-08-31 17:54:29 --> 404 Page Not Found: New/wp-admin
ERROR - 2023-08-31 17:54:33 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2023-08-31 17:54:34 --> 404 Page Not Found: Test/wp-admin
ERROR - 2023-08-31 17:54:36 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2023-08-31 17:54:38 --> 404 Page Not Found: Cms/wp-admin
ERROR - 2023-08-31 17:54:38 --> 404 Page Not Found: Web/wp-admin
ERROR - 2023-08-31 17:54:41 --> 404 Page Not Found: Site/wp-admin
ERROR - 2023-08-31 17:54:44 --> 404 Page Not Found: Oldsite/wp-admin
ERROR - 2023-08-31 18:00:05 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-31 18:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 19:26:38 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 19:26:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 19:46:10 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-08-31 20:11:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 20:12:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:12:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:17:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:17:27 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-31 21:17:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 21:17:28 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-08-31 21:17:29 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-31 21:17:29 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-08-31 21:17:29 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-31 21:17:30 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-31 21:17:30 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-31 21:17:31 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-31 21:17:31 --> 404 Page Not Found: Eephp/index
ERROR - 2023-08-31 21:17:32 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-08-31 21:17:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 21:17:32 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-08-31 21:17:33 --> 404 Page Not Found: Installphp/index
ERROR - 2023-08-31 21:17:33 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-08-31 21:17:34 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-31 21:17:34 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-08-31 21:17:35 --> 404 Page Not Found: Css/install.php
ERROR - 2023-08-31 21:17:35 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-31 21:17:36 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-31 21:17:36 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-31 21:17:37 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-31 21:17:37 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-31 21:17:38 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-08-31 21:17:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-31 21:17:38 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-08-31 21:25:51 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-31 21:47:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:49:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:49:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 21:57:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 21:57:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 22:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 22:38:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 23:06:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 23:16:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-31 23:16:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 23:16:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-31 23:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-31 23:33:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-31 23:33:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
