<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-24 01:29:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 01:29:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 01:31:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 01:31:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 01:31:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 01:31:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 01:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 01:33:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 02:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 02:11:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 02:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 02:17:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 02:17:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 02:21:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 02:21:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 02:32:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 02:35:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 02:35:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-24 02:46:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 02:46:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-24 03:08:11 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 03:08:11 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-24 03:13:49 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 03:13:49 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 04:55:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 05:03:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 05:03:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 05:05:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 05:06:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 05:06:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 07:14:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:14:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:15:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:15:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:16:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:16:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:17:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:18:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:18:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:18:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:19:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:19:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:20:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:21:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:21:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:22:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:22:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:23:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:23:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:24:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:25:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:25:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:25:53 --> Query error: Commands out of sync; you can't run this command now - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1695520553
WHERE `id` = '64f1fd837f870a0d9c77ad7ecad89f81d4f49e3b'
ERROR - 2023-09-24 07:25:53 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('d542ecae5a0193a5866e0643a85251b6') AS ci_session_lock
ERROR - 2023-09-24 07:25:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:26:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:26:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:27:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:28:34 --> Query error: Commands out of sync; you can't run this command now - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1695520714
WHERE `id` = '64f1fd837f870a0d9c77ad7ecad89f81d4f49e3b'
ERROR - 2023-09-24 07:28:34 --> Query error: Commands out of sync; you can't run this command now - Invalid query: SELECT RELEASE_LOCK('d542ecae5a0193a5866e0643a85251b6') AS ci_session_lock
ERROR - 2023-09-24 07:28:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:29:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:29:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:30:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:31:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:31:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:32:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:32:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:33:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:33:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:34:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:34:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:35:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:35:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:36:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 07:36:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:37:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:37:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:38:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:40:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:41:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:44:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:44:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:46:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:46:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:47:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:49:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:50:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:51:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:51:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:52:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:54:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:54:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:57:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 07:57:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:01:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:03:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:03:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:04:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:04:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:05:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:06:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:06:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:06:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:08:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:20:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 08:21:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:21:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:22:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:22:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:24:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 08:24:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:24:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:28:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 08:28:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:28:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 08:28:34 --> 404 Page Not Found: Log/index
ERROR - 2023-09-24 08:28:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:28:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:28:51 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:30:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:30:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:30:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:30:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:32:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:32:44 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 08:34:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:34:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:34:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:34:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:34:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:34:51 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:36:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:36:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:37:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:37:56 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:38:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:38:19 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:38:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:38:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:38:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:38:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:39:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:39:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:40:44 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:41:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:41:36 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:55:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:55:09 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:56:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 08:59:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 08:59:38 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 09:19:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 09:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 10:04:05 --> 404 Page Not Found: Env/index
ERROR - 2023-09-24 10:15:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 10:21:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 10:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 10:23:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 10:23:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 10:24:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 10:42:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:42:31 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 10:45:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:45:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 10:45:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:45:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 10:48:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:48:28 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 10:48:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:48:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:48:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 10:49:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:49:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 10:49:38 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:04:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:04:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:04:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:04:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:07:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:07:48 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:08:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:08:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:11:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:11:20 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:11:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:11:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:13:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:13:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:14:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 11:15:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:15:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:16:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:16:48 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:17:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:17:11 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:18:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:18:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:19:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:19:37 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:23:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:23:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 11:25:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 11:25:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 11:28:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 11:28:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 11:28:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:28:48 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:31:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:31:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:31:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:31:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:32:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:32:58 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:33:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:33:54 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:38:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:38:08 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:38:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:38:21 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:39:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:39:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:39:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:39:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:45:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:45:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:46:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:46:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:47:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:47:57 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:48:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:48:13 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:49:37 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-24 11:49:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:49:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:49:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:49:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:51:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:51:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:51:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:51:23 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:52:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:52:25 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:52:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:52:48 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:56:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:56:17 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:56:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:56:42 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:57:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:57:45 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:58:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:58:00 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:59:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:59:26 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 11:59:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 11:59:41 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 12:00:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 12:00:53 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 12:01:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 12:01:04 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 12:06:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 12:06:27 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 12:06:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 12:06:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 12:06:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 12:29:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:30:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:31:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:32:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:32:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 12:32:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 12:33:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 12:46:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 12:46:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 12:46:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 13:02:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 13:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 13:22:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 13:22:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 13:22:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 13:22:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 13:22:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 13:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-24 14:21:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 14:21:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 14:31:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 15:19:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 15:19:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 15:19:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 15:19:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 15:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 15:44:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 15:44:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 15:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 16:32:25 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-24 16:36:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 17:03:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 17:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 17:34:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 18:31:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 18:31:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 18:31:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 19:40:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:40:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 19:41:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 19:41:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 19:41:15 --> 404 Page Not Found: Log/index
ERROR - 2023-09-24 19:41:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 19:41:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 19:41:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 19:41:33 --> 404 Page Not Found: Log/index
ERROR - 2023-09-24 19:41:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:41:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:41:52 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 19:42:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:42:07 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 19:42:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:42:10 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 19:44:12 --> 404 Page Not Found: Assets/backend
ERROR - 2023-09-24 19:44:12 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-09-24 19:51:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 19:51:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:04:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:05:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:05:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:05:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:15:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:15:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:15:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 20:40:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:40:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:55:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:55:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:57:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:57:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 20:59:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 20:59:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 21:12:54 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-24 21:16:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 21:16:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 21:16:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 21:56:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 22:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-24 22:23:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 22:23:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-24 22:29:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 22:29:49 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-24 22:45:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 22:45:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 22:45:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-24 22:46:23 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-24 23:51:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-24 23:51:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
