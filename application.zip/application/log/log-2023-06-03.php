<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-03 00:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-03 00:36:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 00:39:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 08:36:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 08:47:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:16:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-03 10:47:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:48:03 --> 404 Page Not Found: Advisor-singlehtml/index
ERROR - 2023-06-03 10:48:04 --> 404 Page Not Found: Advisorshtml/index
ERROR - 2023-06-03 10:48:04 --> 404 Page Not Found: Advisors-2html/index
ERROR - 2023-06-03 10:48:05 --> 404 Page Not Found: Blog-2-columhtml/index
ERROR - 2023-06-03 10:48:05 --> 404 Page Not Found: Blog-3-columhtml/index
ERROR - 2023-06-03 10:48:06 --> 404 Page Not Found: Blog-single-with-sidebarhtml/index
ERROR - 2023-06-03 10:48:08 --> 404 Page Not Found: Blog-standardhtml/index
ERROR - 2023-06-03 10:48:08 --> 404 Page Not Found: Blog-singlehtml/index
ERROR - 2023-06-03 10:48:09 --> 404 Page Not Found: Blog-with-sidebarhtml/index
ERROR - 2023-06-03 10:50:24 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-06-03 10:50:43 --> 404 Page Not Found: Advisor-singlehtml/index
ERROR - 2023-06-03 10:50:44 --> 404 Page Not Found: Advisors-2html/index
ERROR - 2023-06-03 10:50:47 --> 404 Page Not Found: Advisorshtml/index
ERROR - 2023-06-03 10:50:50 --> 404 Page Not Found: Blog-2-columhtml/index
ERROR - 2023-06-03 10:50:55 --> 404 Page Not Found: Blog-single-with-sidebarhtml/index
ERROR - 2023-06-03 10:50:59 --> 404 Page Not Found: Blog-with-sidebarhtml/index
ERROR - 2023-06-03 10:50:59 --> 404 Page Not Found: Blog-singlehtml/index
ERROR - 2023-06-03 10:50:59 --> 404 Page Not Found: Blog-standardhtml/index
ERROR - 2023-06-03 10:51:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:51:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 10:52:00 --> 404 Page Not Found: Util/login.aspx
ERROR - 2023-06-03 10:52:00 --> 404 Page Not Found: Magento_version/index
ERROR - 2023-06-03 10:52:00 --> 404 Page Not Found: Installphp/index
ERROR - 2023-06-03 18:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-03 18:52:49 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-06-03 18:52:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-06-03 18:52:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:06:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:41:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:42:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-03 19:42:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:42:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:42:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 19:42:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-03 20:27:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 21:20:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 21:20:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-03 21:20:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-03 22:54:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 23:00:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-03 23:00:42 --> 404 Page Not Found: Faviconico/index
