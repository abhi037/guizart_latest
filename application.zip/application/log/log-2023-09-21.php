<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-21 00:01:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:01:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:10:36 --> 404 Page Not Found: Env/index
ERROR - 2023-09-21 00:10:37 --> 404 Page Not Found: Wp-configphp/index
ERROR - 2023-09-21 00:16:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:17:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:17:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:18:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:19:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 00:19:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:19:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:22:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:22:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:32:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:32:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:36:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:36:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 00:36:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 00:36:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 00:40:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:40:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:43:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:43:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 00:51:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:51:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 00:51:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 01:12:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 01:12:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 01:16:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 01:16:56 --> 404 Page Not Found: Env/index
ERROR - 2023-09-21 01:17:17 --> 404 Page Not Found: Env/index
ERROR - 2023-09-21 01:17:37 --> 404 Page Not Found: Envtxt/index
ERROR - 2023-09-21 01:17:57 --> 404 Page Not Found: Envtxt/index
ERROR - 2023-09-21 01:18:18 --> 404 Page Not Found: Env1/index
ERROR - 2023-09-21 01:18:38 --> 404 Page Not Found: Config/.env
ERROR - 2023-09-21 01:18:59 --> 404 Page Not Found: Envbackup/index
ERROR - 2023-09-21 01:19:19 --> 404 Page Not Found: Envdev/index
ERROR - 2023-09-21 01:19:39 --> 404 Page Not Found: Test/.env.php
ERROR - 2023-09-21 01:20:00 --> 404 Page Not Found: Test/.env.local
ERROR - 2023-09-21 01:20:20 --> 404 Page Not Found: Test/.env.test
ERROR - 2023-09-21 01:20:41 --> 404 Page Not Found: Admin/.env
ERROR - 2023-09-21 01:21:01 --> 404 Page Not Found: Admin1/.env
ERROR - 2023-09-21 01:21:22 --> 404 Page Not Found: Root/.env
ERROR - 2023-09-21 01:21:42 --> 404 Page Not Found: Data/.env
ERROR - 2023-09-21 01:22:03 --> 404 Page Not Found: Demo/.env
ERROR - 2023-09-21 01:22:23 --> 404 Page Not Found: Env/.env
ERROR - 2023-09-21 01:22:44 --> 404 Page Not Found: Home/.env
ERROR - 2023-09-21 01:23:04 --> 404 Page Not Found: Services/.env
ERROR - 2023-09-21 01:23:25 --> 404 Page Not Found: Service/.env
ERROR - 2023-09-21 01:23:45 --> 404 Page Not Found: Site/.env
ERROR - 2023-09-21 01:24:06 --> 404 Page Not Found: Local/.env
ERROR - 2023-09-21 01:24:26 --> 404 Page Not Found: Template/.env
ERROR - 2023-09-21 01:24:46 --> 404 Page Not Found: Temp/.env
ERROR - 2023-09-21 01:25:07 --> 404 Page Not Found: Upload/.env
ERROR - 2023-09-21 01:25:27 --> 404 Page Not Found: Web/.env
ERROR - 2023-09-21 01:25:48 --> 404 Page Not Found: Website/.env
ERROR - 2023-09-21 01:26:08 --> 404 Page Not Found: Win/.env
ERROR - 2023-09-21 01:26:28 --> 404 Page Not Found: Test/.env
ERROR - 2023-09-21 01:26:49 --> 404 Page Not Found: Test1/.env
ERROR - 2023-09-21 01:27:09 --> 404 Page Not Found: Test2/.env
ERROR - 2023-09-21 01:27:30 --> 404 Page Not Found: Shop/.env
ERROR - 2023-09-21 01:27:51 --> 404 Page Not Found: Shop1/.env
ERROR - 2023-09-21 01:28:11 --> 404 Page Not Found: Blog/.env
ERROR - 2023-09-21 01:28:31 --> 404 Page Not Found: Blog1/.env
ERROR - 2023-09-21 01:28:52 --> 404 Page Not Found: Work/.env
ERROR - 2023-09-21 01:29:33 --> 404 Page Not Found: Laravel/.env
ERROR - 2023-09-21 01:29:53 --> 404 Page Not Found: Laravel/.env
ERROR - 2023-09-21 01:30:13 --> 404 Page Not Found: Online/.env
ERROR - 2023-09-21 01:30:34 --> 404 Page Not Found: Testing/.env
ERROR - 2023-09-21 01:30:54 --> 404 Page Not Found: Php/.env
ERROR - 2023-09-21 01:31:15 --> 404 Page Not Found: Testing/.env
ERROR - 2023-09-21 01:31:35 --> 404 Page Not Found: Wp/.env
ERROR - 2023-09-21 01:58:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 01:58:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 02:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 02:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 02:11:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 02:11:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 02:13:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 02:13:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 02:35:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 03:23:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 04:03:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 04:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 05:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 05:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 05:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 05:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 05:22:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 05:22:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 06:18:07 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 06:23:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 06:23:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 06:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 06:27:14 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-21 06:27:15 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-21 06:27:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 06:28:47 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 06:28:47 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 06:39:08 --> 404 Page Not Found: Env/index
ERROR - 2023-09-21 06:39:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:44:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:44:59 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-09-21 06:45:03 --> 404 Page Not Found: Administrator/help
ERROR - 2023-09-21 06:45:07 --> 404 Page Not Found: Administrator/language
ERROR - 2023-09-21 06:45:10 --> 404 Page Not Found: Plugins/system
ERROR - 2023-09-21 06:45:13 --> 404 Page Not Found: Administrator/index
ERROR - 2023-09-21 06:45:17 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2023-09-21 06:45:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:45:28 --> 404 Page Not Found: Admin/view
ERROR - 2023-09-21 06:45:31 --> 404 Page Not Found: Admin/includes
ERROR - 2023-09-21 06:45:34 --> 404 Page Not Found: Images/editor
ERROR - 2023-09-21 06:45:40 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2023-09-21 06:45:44 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2023-09-21 06:45:47 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2023-09-21 06:45:50 --> 404 Page Not Found: Env/index
ERROR - 2023-09-21 06:45:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 06:45:57 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2023-09-21 06:46:00 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2023-09-21 06:46:03 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2023-09-21 06:46:05 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2023-09-21 06:46:08 --> 404 Page Not Found: Test/wp-admin
ERROR - 2023-09-21 06:46:16 --> 404 Page Not Found: Site/wp-admin
ERROR - 2023-09-21 08:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 08:21:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 08:21:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 08:26:11 --> 404 Page Not Found: Wp-content/_input_3_raiz0.php5
ERROR - 2023-09-21 08:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 08:27:31 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-09-21 08:28:01 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-21 08:28:37 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-09-21 08:29:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-21 08:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 08:32:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 08:33:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 08:33:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 08:34:01 --> 404 Page Not Found: XxXphp/index
ERROR - 2023-09-21 08:34:35 --> 404 Page Not Found: Components/Raiz0WorM_1695261760.php
ERROR - 2023-09-21 08:35:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 08:35:27 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-21 08:35:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-21 08:35:43 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-21 08:35:49 --> 404 Page Not Found: Components/com_sexycontactform
ERROR - 2023-09-21 08:36:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-21 08:36:10 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-21 08:36:17 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2023-09-21 08:37:27 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-21 08:38:00 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-09-21 08:38:44 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-09-21 09:07:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 09:34:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 09:37:27 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 09:37:27 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 09:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 10:11:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 10:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 10:41:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 10:41:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 11:11:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 11:11:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 11:34:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 12:09:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:09:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:15:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 12:15:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:15:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:25:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 12:25:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:25:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 12:45:38 --> 404 Page Not Found: Uploads/pages
ERROR - 2023-09-21 12:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 14:10:29 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 14:10:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 14:11:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 14:12:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 14:12:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 14:14:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 15:15:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 15:19:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 16:25:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 16:25:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 16:31:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 16:31:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 16:31:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 16:31:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 17:01:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 17:17:42 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-09-21 17:17:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 17:17:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 17:17:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 18:28:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 18:28:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 18:28:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 18:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 19:17:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:17:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:20:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:20:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:24:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:24:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 19:28:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:28:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:31:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:31:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 19:35:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:35:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:36:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 19:36:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:36:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-21 19:37:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 19:37:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-21 20:30:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 20:32:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 20:32:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 20:34:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:04:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:04:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 21:07:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:07:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 21:10:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:10:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 21:14:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:14:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 21:32:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 21:42:43 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-21 22:09:00 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-21 22:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 22:18:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 22:18:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 22:18:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 22:30:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 22:31:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 22:31:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 22:31:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-21 22:31:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 22:47:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 22:48:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-21 23:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 23:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 23:12:29 --> 404 Page Not Found: Robotstxt/index
