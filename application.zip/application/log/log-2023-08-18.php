<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-18 00:47:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 00:47:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 00:53:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 01:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 01:03:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 01:03:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 01:05:08 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-18 01:05:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 01:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 01:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 02:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 02:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 02:19:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 02:20:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-18 03:44:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 03:44:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 03:48:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:51:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:51:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:51:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:52:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:53:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:54:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:54:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:55:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 03:55:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:43:58 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-18 04:44:07 --> 404 Page Not Found: Sites/default
ERROR - 2023-08-18 04:44:24 --> 404 Page Not Found: Admin/controller
ERROR - 2023-08-18 04:49:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:49:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:50:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:50:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:51:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:52:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:53:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 04:54:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 06:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 06:36:14 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-18 08:13:37 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-08-18 08:36:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 08:36:42 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-18 08:36:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:36:47 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2023-08-18 08:36:49 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-18 08:36:53 --> 404 Page Not Found: Wp-content/patior
ERROR - 2023-08-18 08:36:55 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-18 08:36:57 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-18 08:36:59 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-18 08:37:01 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-18 08:37:03 --> 404 Page Not Found: Eephp/index
ERROR - 2023-08-18 08:37:05 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-08-18 08:37:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:37:09 --> 404 Page Not Found: Wp-content/install.php
ERROR - 2023-08-18 08:37:13 --> 404 Page Not Found: Installphp/index
ERROR - 2023-08-18 08:37:15 --> 404 Page Not Found: Wp-includes/install.php
ERROR - 2023-08-18 08:37:18 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-18 08:37:19 --> 404 Page Not Found: Cgi-bin/install.php
ERROR - 2023-08-18 08:37:23 --> 404 Page Not Found: Css/install.php
ERROR - 2023-08-18 08:37:25 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-18 08:37:27 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-18 08:37:30 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-18 08:37:32 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-18 08:37:34 --> 404 Page Not Found: Cgi-bin/cgi-bin
ERROR - 2023-08-18 08:37:36 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-08-18 08:37:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:37:40 --> 404 Page Not Found: Wp-content/dropdown.php
ERROR - 2023-08-18 08:37:42 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-08-18 08:37:44 --> 404 Page Not Found: Alfanewphp/index
ERROR - 2023-08-18 08:37:46 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-08-18 08:37:48 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-08-18 08:37:51 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-18 08:37:53 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-18 08:37:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:37:56 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-08-18 08:37:59 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-18 08:38:02 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:38:06 --> 404 Page Not Found: Rindexphp/index
ERROR - 2023-08-18 08:38:08 --> 404 Page Not Found: Tafphp/index
ERROR - 2023-08-18 08:38:10 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-18 08:38:13 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-18 08:38:14 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-18 08:38:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-18 08:38:19 --> 404 Page Not Found: Wp-admin/style.php
ERROR - 2023-08-18 08:38:21 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-08-18 08:38:23 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-08-18 08:38:26 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-08-18 08:38:28 --> 404 Page Not Found: Congphp/index
ERROR - 2023-08-18 08:38:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:38:32 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-18 08:38:33 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-18 08:38:36 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-18 08:48:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 08:56:35 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 08:56:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 09:00:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 09:01:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 09:22:55 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 09:36:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 09:50:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 09:51:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 09:52:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 10:08:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 10:08:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:09:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:14:02 --> 404 Page Not Found: Log/index
ERROR - 2023-08-18 10:15:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 10:15:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:15:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:15:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 10:15:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:16:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:17:12 --> 404 Page Not Found: Log/index
ERROR - 2023-08-18 10:17:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-18 10:19:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-18 10:22:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-18 10:26:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-18 10:33:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 10:33:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 10:38:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-08-18 10:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 11:02:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 11:02:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 11:02:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 11:47:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 11:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 12:00:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 12:01:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 12:01:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 12:36:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 12:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 13:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 13:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 13:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 13:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 13:19:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 13:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 14:09:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 14:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 14:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 14:25:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 14:27:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 14:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 15:23:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 15:23:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 15:23:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 15:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 15:59:03 --> 404 Page Not Found: Ioxi-rex4php7/index
ERROR - 2023-08-18 15:59:31 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-18 16:00:17 --> 404 Page Not Found: Cache-compatphp/index
ERROR - 2023-08-18 16:00:56 --> 404 Page Not Found: Wp-includes/Requests
ERROR - 2023-08-18 16:01:52 --> 404 Page Not Found: Wp-admin/ajax-actions.php
ERROR - 2023-08-18 16:02:19 --> 404 Page Not Found: Ajax-actionsphp/index
ERROR - 2023-08-18 16:02:47 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-18 16:03:10 --> 404 Page Not Found: Alfa-rex2php7/index
ERROR - 2023-08-18 16:03:42 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-18 16:04:05 --> 404 Page Not Found: Wp-headphp/index
ERROR - 2023-08-18 16:04:40 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-18 16:05:09 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-08-18 16:05:38 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-08-18 16:06:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 16:06:49 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-18 16:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 16:18:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 16:18:19 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-08-18 16:50:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 17:03:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-18 17:19:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 17:19:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-18 18:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 18:52:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:52:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:52:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:52:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:53:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:54:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 18:55:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 19:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 19:11:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 20:23:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 20:28:12 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-08-18 20:28:12 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-18 21:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-18 22:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:03:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 22:03:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-18 22:03:17 --> 404 Page Not Found: Log/index
ERROR - 2023-08-18 22:03:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:04:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:04:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:44:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:44:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:44:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:44:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:45:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-18 22:45:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
