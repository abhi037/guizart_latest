<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-28 00:10:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 00:12:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 00:12:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 00:12:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:03:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 01:03:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:03:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 01:04:41 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-28 01:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 01:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 01:35:09 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-28 01:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:35:10 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-28 01:35:11 --> 404 Page Not Found: Bc/index
ERROR - 2023-07-28 01:35:12 --> 404 Page Not Found: Bk/index
ERROR - 2023-07-28 01:35:15 --> 404 Page Not Found: New/index
ERROR - 2023-07-28 01:35:16 --> 404 Page Not Found: Main/index
ERROR - 2023-07-28 01:35:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 01:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 02:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 02:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 03:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 04:32:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 04:35:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 04:35:53 --> 404 Page Not Found: Uploads/lesson_files
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-07-28 04:41:19 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-28 04:41:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-07-28 05:31:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 05:31:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 06:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 07:04:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 07:04:16 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-07-28 07:38:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 07:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 07:48:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 07:50:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 07:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 07:58:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 08:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 08:32:54 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-07-28 10:05:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 10:22:02 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-28 10:22:31 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-28 10:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 12:00:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 12:06:37 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-07-28 12:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 12:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 13:08:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 15:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 16:21:37 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-07-28 17:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 17:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 17:14:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 17:37:39 --> 404 Page Not Found: Log In/index
ERROR - 2023-07-28 18:39:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 18:39:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 18:39:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-07-28 20:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-07-28 22:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 22:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-07-28 23:31:17 --> 404 Page Not Found: Wp-content/plugins
