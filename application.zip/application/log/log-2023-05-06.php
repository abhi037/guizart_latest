<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:00:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:06:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:07:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:08:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:11:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:45 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:13:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:22:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:24:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:34:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:36:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:38:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:39:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:39:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:40:37 --> Query error: Column 'quiz_id' cannot be null - Invalid query: INSERT INTO `quiz_result` (`quiz_id`, `student_id`, `auto_submission`, `submitted_time`) VALUES (NULL, '131', 0, '2023-05-06 00:40:37')
ERROR - 2023-05-06 00:40:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:40:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:40:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:40:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:41:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:42:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:44:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:47:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:49:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:50:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:51:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 00:52:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:02:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:02:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:03:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:12:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:13:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:16:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:17:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:20:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:22:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:23:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:25:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:27:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:30:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:33:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:23 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:37:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:37:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:39:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:40:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:31 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:41:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:42:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:43:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:45:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 01:46:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:46:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:46:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 01:47:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:07:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:07:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:08:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:08:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:15:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:15:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:17:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:20:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:20:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:21:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:23:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:25:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:22 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:26:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:27:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:27:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:30:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:32:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:35:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:36:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:39:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 123
ERROR - 2023-05-06 10:41:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:42:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:43:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 10:45:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:39:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 12:51:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:07:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:07:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:07:08 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 13:07:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:07:15 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:07:26 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:07:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:07:35 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:07:35 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:08:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:08:14 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:08:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:08:24 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:08:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:08:31 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:08:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:08:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:08:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:08:47 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:09:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:09:09 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:09:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:09:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:09:28 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 13:10:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:10:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:15:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:18:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:18:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:18:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:19:24 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 13:19:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:19:31 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:19:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:19:39 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:19:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:19:49 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:19:55 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:19:55 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:20:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-05-06 13:20:03 --> 404 Page Not Found: Uploads/user_image
ERROR - 2023-05-06 13:20:43 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-05-06 13:20:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:20:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:27:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:32:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:32:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:33:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:35:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:36:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:37:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:39 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:39:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:39:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:40:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:40:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:41:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:42:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:43:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:44:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:46:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:48:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:49:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:57:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 13:59:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:02:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:04:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:06:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:08:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:13:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 14:51:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:55:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:56:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:58:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:58:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 14:59:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:01:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:03:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:04:46 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 74
ERROR - 2023-05-06 15:04:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:04:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:05:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:07:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:08:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:08:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:09:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:09:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:10:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:11:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:11:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:12:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:12:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:14:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:14:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:15:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:15:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:17:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:17:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:17:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:19:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:19:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:21:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:21:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:23:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:25:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:25:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:26:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:26:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:29:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:33:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:35:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:36:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2023-05-06 15:39:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:39:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:40:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:40:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:40:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:41:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:42:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:42:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:44:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:44:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:45:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:45:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:46:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:47:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:50:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:52:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:52:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:53:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:53:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:56:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:56:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:56:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:57:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:57:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:57:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:58:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 15:59:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:00:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:01:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:51 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:05:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:32 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:53 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:06:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:07:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:08:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:09:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:48 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:18:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:19:06 --> Query error: Column 'quiz_id' cannot be null - Invalid query: INSERT INTO `quiz_result` (`quiz_id`, `student_id`, `auto_submission`, `submitted_time`) VALUES (NULL, '131', 0, '2023-05-06 16:19:06')
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:18 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:19:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:20:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 126
ERROR - 2023-05-06 16:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:22:04 --> Query error: Column 'quiz_id' cannot be null - Invalid query: INSERT INTO `quiz_result` (`quiz_id`, `student_id`, `auto_submission`, `submitted_time`) VALUES (NULL, '131', 0, '2023-05-06 16:22:04')
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 120
ERROR - 2023-05-06 16:22:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:23:01 --> Query error: Column 'quiz_id' cannot be null - Invalid query: INSERT INTO `quiz_result` (`quiz_id`, `student_id`, `auto_submission`, `submitted_time`) VALUES (NULL, '131', 0, '2023-05-06 16:23:01')
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:23:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:24:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:29 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:25:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:11 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:26:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:26:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:27:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:30 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:32:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:39:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:52:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:53:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:54:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:49 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:55:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:56:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:13 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 16:57:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:02:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:06 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:11:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:15:59 --> Severity: Notice --> Undefined variable: i2 C:\xampp\htdocs\quizart\application\views\frontend\default\quiz.php 119
ERROR - 2023-05-06 17:16:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:12:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home4/demouake/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2023-05-06 18:12:33 --> Unable to connect to the database
ERROR - 2023-05-06 18:12:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home4/demouake/public_html/system/core/Exceptions.php:271) /home4/demouake/public_html/system/core/Common.php 570
ERROR - 2023-05-06 18:12:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-06 18:13:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:13:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:13:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:14:51 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:14:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:14:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:14:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:14:58 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:15:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-06 18:15:14 --> Severity: Notice --> Undefined variable: instructor_list /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-05-06 18:15:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home4/demouake/public_html/application/views/frontend/user/my_messages.php 81
ERROR - 2023-05-06 18:15:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:16:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:16:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:16:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:16:49 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:16:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:17:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:17:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:17:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:17:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:17:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:57 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:20:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:21:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:24:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:00 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:26:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:26:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:29:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:29:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:30:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:30:10 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:32:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:33:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:36:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 18:37:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:38:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:38:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:39:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:39:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:39:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:40:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:40:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:40:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:41:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:41:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:41:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:41:56 --> Severity: error --> Exception: Order amount less than minimum amount allowed /home4/demouake/public_html/assets/razorpay-php/src/Request.php 123
ERROR - 2023-05-06 18:42:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:42:16 --> Severity: error --> Exception: Order amount less than minimum amount allowed /home4/demouake/public_html/assets/razorpay-php/src/Request.php 123
ERROR - 2023-05-06 18:42:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:42:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:42:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:42:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:42:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:43:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:43:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:43:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:43:19 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:43:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-06 18:45:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:45:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:45:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:46:14 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:46:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-06 18:46:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:46:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:46:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:46:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:46:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:46:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:47:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:47:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:48:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:48:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:48:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:48:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:48:24 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:48:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:48:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:48:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:49:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:51:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:51:19 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:51:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:51:23 --> Severity: Notice --> Undefined variable: order /home4/demouake/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-05-06 18:51:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:51:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:52:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:52:43 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:52:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:53:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:53:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:53:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:53:24 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 18:53:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:53:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:53:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:53:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:54:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:54:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:54:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:54:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:54:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:54:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:56:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 18:56:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:56:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:56:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 18:57:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 19:02:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 19:02:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:32 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 19:02:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 19:02:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:43 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 19:02:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 19:02:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 19:02:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:02:59 --> 404 Page Not Found: Log/index
ERROR - 2023-05-06 19:03:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:03:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 19:53:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-06 20:00:09 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-05-06 20:10:11 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-06 20:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-06 20:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-06 20:45:15 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-05-06 20:52:23 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-06 20:52:50 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-06 21:07:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 21:07:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:07:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:08:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:11 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:12 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:08:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:17 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:50 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-06 21:09:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:09:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:12:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 21:21:44 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2023-05-06 21:30:08 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-05-06 21:35:39 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-05-06 21:44:32 --> 404 Page Not Found: Atomxml/index
ERROR - 2023-05-06 21:49:29 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-05-06 21:49:49 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-05-06 22:36:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:36:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:36:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:36:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:36:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:38:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 22:38:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:38:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:38:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-06 22:38:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-06 23:02:53 --> 404 Page Not Found: Assets/frontend
