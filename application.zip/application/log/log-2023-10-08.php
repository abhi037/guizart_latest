<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-08 01:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 01:08:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 01:08:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 01:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 01:17:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 01:17:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 01:26:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 01:26:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 01:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 01:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 01:37:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 01:37:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 02:17:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 02:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 02:35:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 02:35:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 02:35:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 03:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 03:30:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 04:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 04:25:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 04:25:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 04:35:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 04:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 05:22:46 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-10-08 05:22:53 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-10-08 05:23:00 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-10-08 05:23:03 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-10-08 05:23:17 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-10-08 05:38:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 05:40:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 05:41:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 05:42:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:13:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:13:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 06:15:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:15:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 06:17:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:17:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-08 06:19:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 06:19:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 06:24:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:26:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 06:26:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 07:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 08:37:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 09:46:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 10:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 10:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 11:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 11:05:11 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 11:05:13 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 11:05:15 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 11:09:40 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 11:09:45 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 11:09:47 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 11:15:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 11:15:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 11:21:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 11:21:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 11:22:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 11:22:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 11:24:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 11:25:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 11:40:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 12:26:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-08 13:10:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 13:10:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 14:57:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Backupzip/index
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Quizartcoinzip/index
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Oldzip/index
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Htmlzip/index
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2023-10-08 15:51:55 --> 404 Page Not Found: Sitezip/index
ERROR - 2023-10-08 15:51:56 --> 404 Page Not Found: Archivezip/index
ERROR - 2023-10-08 16:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 16:08:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 16:08:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 16:10:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 16:10:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 16:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 16:13:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 16:14:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 16:14:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 16:14:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-08 16:19:06 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 16:19:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-08 16:34:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 18:36:43 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 18:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 18:36:50 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 18:36:56 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-10-08 18:37:10 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 18:37:17 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 18:37:24 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-08 19:46:29 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-08 19:46:30 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-08 20:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 20:43:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:48:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 20:52:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:53:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 20:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 20:55:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:55:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 20:57:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:58:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 20:58:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 21:00:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 21:03:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 21:03:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 21:03:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 21:04:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 21:41:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 21:41:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 22:19:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 22:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-08 22:50:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 22:50:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 23:00:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-08 23:00:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-08 23:00:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
