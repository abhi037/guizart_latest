<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-10 00:12:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 00:27:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 00:32:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 00:47:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 00:47:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 01:07:35 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 01:10:20 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-10 01:36:58 --> 404 Page Not Found: Wp-plainphp/index
ERROR - 2023-09-10 01:36:58 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2023-09-10 01:36:58 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 01:36:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 01:36:58 --> 404 Page Not Found: Fhqcysxvphp/index
ERROR - 2023-09-10 01:36:59 --> 404 Page Not Found: Alfacgiapi/perl.alfa
ERROR - 2023-09-10 01:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 01:54:07 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 01:54:07 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 01:57:26 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
ERROR - 2023-09-10 01:57:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 01:57:26 --> 404 Page Not Found: Wp-plainphp/index
ERROR - 2023-09-10 01:57:27 --> 404 Page Not Found: Alfacgiapi/perl.alfa
ERROR - 2023-09-10 01:57:27 --> 404 Page Not Found: Ovcbdlgcphp/index
ERROR - 2023-09-10 02:01:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 02:02:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 02:27:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 02:27:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 02:27:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 03:34:14 --> 404 Page Not Found: Log In/index
ERROR - 2023-09-10 04:17:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 04:17:53 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-09-10 04:19:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 04:19:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 04:19:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 05:40:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 06:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 06:13:21 --> 404 Page Not Found: Env/index
ERROR - 2023-09-10 06:13:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 06:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 06:18:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 06:19:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 06:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 06:40:38 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 06:40:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 07:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 07:31:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 08:39:47 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-09-10 08:39:47 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-09-10 08:39:47 --> 404 Page Not Found: Sftpjson/index
ERROR - 2023-09-10 08:49:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 09:02:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 09:02:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 09:02:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 09:18:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 09:18:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 09:42:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 10:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 10:49:59 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 10:49:59 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 11:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 11:39:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 12:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 12:07:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 12:07:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 14:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 14:08:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 14:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 14:27:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 14:27:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-09-10 15:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-09-10 16:27:01 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 16:27:01 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-09-10 17:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 17:01:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 19:20:49 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-09-10 19:21:59 --> 404 Page Not Found: 0zphp/index
ERROR - 2023-09-10 19:21:59 --> 404 Page Not Found: Fwphp/index
ERROR - 2023-09-10 19:21:59 --> 404 Page Not Found: 1php/index
ERROR - 2023-09-10 19:22:00 --> 404 Page Not Found: 404php/index
ERROR - 2023-09-10 19:22:00 --> 404 Page Not Found: 403php/index
ERROR - 2023-09-10 19:22:01 --> 404 Page Not Found: Initphp/index
ERROR - 2023-09-10 19:22:01 --> 404 Page Not Found: Wp_wrong_datlibphp/index
ERROR - 2023-09-10 19:22:02 --> 404 Page Not Found: Xleetphp/index
ERROR - 2023-09-10 19:22:02 --> 404 Page Not Found: Wp-admin/fx.php
ERROR - 2023-09-10 19:22:02 --> 404 Page Not Found: Alfaphp/index
ERROR - 2023-09-10 19:22:03 --> 404 Page Not Found: Docphp/index
ERROR - 2023-09-10 19:22:03 --> 404 Page Not Found: Marijuanaphp/index
ERROR - 2023-09-10 19:22:04 --> 404 Page Not Found: Miniphp/index
ERROR - 2023-09-10 19:22:04 --> 404 Page Not Found: Shellphp/index
ERROR - 2023-09-10 19:22:05 --> 404 Page Not Found: Smallphp/index
ERROR - 2023-09-10 19:22:05 --> 404 Page Not Found: Wsophp/index
ERROR - 2023-09-10 19:22:06 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-09-10 19:22:06 --> 404 Page Not Found: Hehephp/index
ERROR - 2023-09-10 19:22:06 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2023-09-10 19:22:07 --> 404 Page Not Found: DKIZphp/index
ERROR - 2023-09-10 19:22:07 --> 404 Page Not Found: Xmlphp/index
ERROR - 2023-09-10 19:22:08 --> 404 Page Not Found: Uploadphp/index
ERROR - 2023-09-10 19:22:08 --> 404 Page Not Found: Upphp/index
ERROR - 2023-09-10 19:22:09 --> 404 Page Not Found: Uphphp/index
ERROR - 2023-09-10 19:22:09 --> 404 Page Not Found: Wpxphp/index
ERROR - 2023-09-10 19:22:10 --> 404 Page Not Found: Iniphp/index
ERROR - 2023-09-10 19:22:10 --> 404 Page Not Found: Lufixphp/index
ERROR - 2023-09-10 19:22:10 --> 404 Page Not Found: Images/vuln.php
ERROR - 2023-09-10 19:22:11 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2023-09-10 19:22:11 --> 404 Page Not Found: Upsphp/index
ERROR - 2023-09-10 19:22:12 --> 404 Page Not Found: Srxphp/index
ERROR - 2023-09-10 19:22:12 --> 404 Page Not Found: Googlephp/index
ERROR - 2023-09-10 19:22:13 --> 404 Page Not Found: Mphp/index
ERROR - 2023-09-10 19:22:13 --> 404 Page Not Found: 503php/index
ERROR - 2023-09-10 19:22:13 --> 404 Page Not Found: Updatephp/index
ERROR - 2023-09-10 19:22:14 --> 404 Page Not Found: Lock360php/index
ERROR - 2023-09-10 19:22:14 --> 404 Page Not Found: Lockphp/index
ERROR - 2023-09-10 19:22:15 --> 404 Page Not Found: Priv8php/index
ERROR - 2023-09-10 19:22:15 --> 404 Page Not Found: Massphp/index
ERROR - 2023-09-10 19:22:16 --> 404 Page Not Found: 1337php/index
ERROR - 2023-09-10 19:22:16 --> 404 Page Not Found: 1877php/index
ERROR - 2023-09-10 19:22:17 --> 404 Page Not Found: Fmphp/index
ERROR - 2023-09-10 19:22:17 --> 404 Page Not Found: Cssphp/index
ERROR - 2023-09-10 19:22:17 --> 404 Page Not Found: Inboxphp/index
ERROR - 2023-09-10 19:22:18 --> 404 Page Not Found: Index2php/index
ERROR - 2023-09-10 19:22:18 --> 404 Page Not Found: Defaultphp/index
ERROR - 2023-09-10 19:22:19 --> 404 Page Not Found: Lydaphp/index
ERROR - 2023-09-10 19:22:19 --> 404 Page Not Found: Marphp/index
ERROR - 2023-09-10 19:22:20 --> 404 Page Not Found: Oluxphp/index
ERROR - 2023-09-10 19:22:20 --> 404 Page Not Found: Pluginsphp/index
ERROR - 2023-09-10 19:22:21 --> 404 Page Not Found: Wp-pluginsphp/index
ERROR - 2023-09-10 19:22:21 --> 404 Page Not Found: Shphp/index
ERROR - 2023-09-10 19:22:21 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-09-10 19:22:22 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2023-09-10 19:22:22 --> 404 Page Not Found: Symphp/index
ERROR - 2023-09-10 19:22:23 --> 404 Page Not Found: Teslaphp/index
ERROR - 2023-09-10 19:22:23 --> 404 Page Not Found: Foxphp/index
ERROR - 2023-09-10 19:22:24 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-09-10 19:22:24 --> 404 Page Not Found: Classwithtostringphp/index
ERROR - 2023-09-10 19:22:24 --> 404 Page Not Found: Anphp/index
ERROR - 2023-09-10 19:22:25 --> 404 Page Not Found: Zzphp/index
ERROR - 2023-09-10 19:22:25 --> 404 Page Not Found: Xphp/index
ERROR - 2023-09-10 19:22:26 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-09-10 19:22:26 --> 404 Page Not Found: Byphp/index
ERROR - 2023-09-10 19:22:27 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-09-10 19:22:27 --> 404 Page Not Found: Fxphp/index
ERROR - 2023-09-10 19:22:28 --> 404 Page Not Found: V3n0mphp/index
ERROR - 2023-09-10 19:22:28 --> 404 Page Not Found: Rootphp/index
ERROR - 2023-09-10 19:22:28 --> 404 Page Not Found: Tntphp/index
ERROR - 2023-09-10 19:22:29 --> 404 Page Not Found: Exitphp/index
ERROR - 2023-09-10 19:22:29 --> 404 Page Not Found: Leetphp/index
ERROR - 2023-09-10 19:22:30 --> 404 Page Not Found: Lufiphp/index
ERROR - 2023-09-10 19:22:30 --> 404 Page Not Found: Userphp/index
ERROR - 2023-09-10 19:22:31 --> 404 Page Not Found: Wso112233php/index
ERROR - 2023-09-10 19:22:31 --> 404 Page Not Found: Zphp/index
ERROR - 2023-09-10 19:22:31 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-09-10 19:22:32 --> 404 Page Not Found: Chphp/index
ERROR - 2023-09-10 19:22:32 --> 404 Page Not Found: Xoxphp/index
ERROR - 2023-09-10 19:22:33 --> 404 Page Not Found: Wp-filephp/index
ERROR - 2023-09-10 19:22:33 --> 404 Page Not Found: Minishellphp/index
ERROR - 2023-09-10 19:22:34 --> 404 Page Not Found: Madphp/index
ERROR - 2023-09-10 19:22:34 --> 404 Page Not Found: Anonphp/index
ERROR - 2023-09-10 19:22:35 --> 404 Page Not Found: Privatephp/index
ERROR - 2023-09-10 19:22:35 --> 404 Page Not Found: Gazaphp/index
ERROR - 2023-09-10 19:22:35 --> 404 Page Not Found: H4xorphp/index
ERROR - 2023-09-10 19:22:36 --> 404 Page Not Found: IndoXploitphp/index
ERROR - 2023-09-10 19:22:36 --> 404 Page Not Found: Font-editorphp/index
ERROR - 2023-09-10 19:22:37 --> 404 Page Not Found: Plugin-installphp/index
ERROR - 2023-09-10 19:22:37 --> 404 Page Not Found: Theme-installphp/index
ERROR - 2023-09-10 19:22:38 --> 404 Page Not Found: Endphp/index
ERROR - 2023-09-10 19:22:38 --> 404 Page Not Found: Accessphp/index
ERROR - 2023-09-10 19:22:39 --> 404 Page Not Found: Contentsphp/index
ERROR - 2023-09-10 19:22:39 --> 404 Page Not Found: Licensephp/index
ERROR - 2023-09-10 19:22:39 --> 404 Page Not Found: __1975php/index
ERROR - 2023-09-10 19:22:40 --> 404 Page Not Found: Killphp/index
ERROR - 2023-09-10 19:22:40 --> 404 Page Not Found: Xletttphp/index
ERROR - 2023-09-10 19:22:41 --> 404 Page Not Found: Shellxphp/index
ERROR - 2023-09-10 19:22:41 --> 404 Page Not Found: Lock0360php/index
ERROR - 2023-09-10 19:22:42 --> 404 Page Not Found: Indexsphp/index
ERROR - 2023-09-10 19:22:42 --> 404 Page Not Found: Hanna1337php/index
ERROR - 2023-09-10 19:22:43 --> 404 Page Not Found: Tonphp/index
ERROR - 2023-09-10 19:22:43 --> 404 Page Not Found: Balaphp/index
ERROR - 2023-09-10 19:22:44 --> 404 Page Not Found: Wp-admin/shell20211028.php
ERROR - 2023-09-10 19:22:44 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-09-10 19:22:45 --> 404 Page Not Found: Wp-includes/shell20211028.php
ERROR - 2023-09-10 19:22:45 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-09-10 19:22:46 --> 404 Page Not Found: Logphp/index
ERROR - 2023-09-10 19:22:46 --> 404 Page Not Found: Xl2023php/index
ERROR - 2023-09-10 19:22:46 --> 404 Page Not Found: Wsoyanzorngphp/index
ERROR - 2023-09-10 19:22:47 --> 404 Page Not Found: Alfphp/index
ERROR - 2023-09-10 19:22:47 --> 404 Page Not Found: Xmlrpc2php/index
ERROR - 2023-09-10 19:22:48 --> 404 Page Not Found: Evilphp/index
ERROR - 2023-09-10 19:22:48 --> 404 Page Not Found: Demophp/index
ERROR - 2023-09-10 19:22:49 --> 404 Page Not Found: Tmpshellphp/index
ERROR - 2023-09-10 19:22:49 --> 404 Page Not Found: Motophp/index
ERROR - 2023-09-10 19:22:50 --> 404 Page Not Found: Columnsphp/index
ERROR - 2023-09-10 19:22:50 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:22:50 --> 404 Page Not Found: Wp-includes/atom.php
ERROR - 2023-09-10 19:22:51 --> 404 Page Not Found: Utchihaphp/index
ERROR - 2023-09-10 19:22:51 --> 404 Page Not Found: Utchiha_uploaderphp/index
ERROR - 2023-09-10 19:22:52 --> 404 Page Not Found: Deadcode1975php/index
ERROR - 2023-09-10 19:22:52 --> 404 Page Not Found: Wpphp/index
ERROR - 2023-09-10 19:22:53 --> 404 Page Not Found: Wp-content/wp-conf.php
ERROR - 2023-09-10 19:22:53 --> 404 Page Not Found: Shellsphp/index
ERROR - 2023-09-10 19:22:53 --> 404 Page Not Found: Wp-admin/alfa.php
ERROR - 2023-09-10 19:22:54 --> 404 Page Not Found: Wp-includes/fw.php
ERROR - 2023-09-10 19:22:54 --> 404 Page Not Found: Wp-content/fw.php
ERROR - 2023-09-10 19:22:55 --> 404 Page Not Found: Wp-admin/fw.php
ERROR - 2023-09-10 19:22:55 --> 404 Page Not Found: Wp-22php/index
ERROR - 2023-09-10 19:22:56 --> 404 Page Not Found: Wp-admin/wso.php
ERROR - 2023-09-10 19:22:56 --> 404 Page Not Found: 1975php/index
ERROR - 2023-09-10 19:22:57 --> 404 Page Not Found: Wp-admin/1975.php
ERROR - 2023-09-10 19:22:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:22:57 --> 404 Page Not Found: Wp-content/index.php
ERROR - 2023-09-10 19:22:58 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:22:59 --> 404 Page Not Found: Emergencyphp/index
ERROR - 2023-09-10 19:22:59 --> 404 Page Not Found: Cpphp/index
ERROR - 2023-09-10 19:23:00 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:23:00 --> 404 Page Not Found: Marvinsphp/index
ERROR - 2023-09-10 19:23:01 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-09-10 19:23:01 --> 404 Page Not Found: Tmp/vuln.php
ERROR - 2023-09-10 19:23:01 --> 404 Page Not Found: F0xphp/index
ERROR - 2023-09-10 19:23:02 --> 404 Page Not Found: Images/F0x.php
ERROR - 2023-09-10 19:23:02 --> 404 Page Not Found: Templates/beez3
ERROR - 2023-09-10 19:23:03 --> 404 Page Not Found: Payloadphp/index
ERROR - 2023-09-10 19:23:03 --> 404 Page Not Found: Wp-admin/wp-trc.php
ERROR - 2023-09-10 19:23:04 --> 404 Page Not Found: Alfaindexphp/index
ERROR - 2023-09-10 19:23:04 --> 404 Page Not Found: Wp-content/alfa.php
ERROR - 2023-09-10 19:23:04 --> 404 Page Not Found: Wwwphp/index
ERROR - 2023-09-10 19:23:05 --> 404 Page Not Found: Sndphp/index
ERROR - 2023-09-10 19:23:05 --> 404 Page Not Found: Alfanewphp7/index
ERROR - 2023-09-10 19:23:06 --> 404 Page Not Found: Lalalaphp/index
ERROR - 2023-09-10 19:23:06 --> 404 Page Not Found: Mephp/index
ERROR - 2023-09-10 19:23:07 --> 404 Page Not Found: 0x55php/index
ERROR - 2023-09-10 19:23:07 --> 404 Page Not Found: Wsphp/index
ERROR - 2023-09-10 19:23:08 --> 404 Page Not Found: B1a3kphp/index
ERROR - 2023-09-10 19:23:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:08 --> 404 Page Not Found: Uploads/up.php
ERROR - 2023-09-10 19:23:09 --> 404 Page Not Found: Wp-content/up.php
ERROR - 2023-09-10 19:23:09 --> 404 Page Not Found: Bypphp/index
ERROR - 2023-09-10 19:23:10 --> 404 Page Not Found: Xxphp/index
ERROR - 2023-09-10 19:23:10 --> 404 Page Not Found: Wp-includes/class-json-ajax-session.php
ERROR - 2023-09-10 19:23:11 --> 404 Page Not Found: Wp-admin/wp-22.php
ERROR - 2023-09-10 19:23:11 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:12 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:23:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:14 --> 404 Page Not Found: Sites/all
ERROR - 2023-09-10 19:23:14 --> 404 Page Not Found: Geckophp/index
ERROR - 2023-09-10 19:23:15 --> 404 Page Not Found: Utchiha505php/index
ERROR - 2023-09-10 19:23:15 --> 404 Page Not Found: Fanphp/index
ERROR - 2023-09-10 19:23:16 --> 404 Page Not Found: Moonphp/index
ERROR - 2023-09-10 19:23:16 --> 404 Page Not Found: Update-corephp/index
ERROR - 2023-09-10 19:23:17 --> 404 Page Not Found: User-newphp/index
ERROR - 2023-09-10 19:23:17 --> 404 Page Not Found: Customizephp/index
ERROR - 2023-09-10 19:23:18 --> 404 Page Not Found: Xzourtphp/index
ERROR - 2023-09-10 19:23:18 --> 404 Page Not Found: Creditsphp/index
ERROR - 2023-09-10 19:23:18 --> 404 Page Not Found: Usersphp/index
ERROR - 2023-09-10 19:23:19 --> 404 Page Not Found: Edit-commentsphp/index
ERROR - 2023-09-10 19:23:19 --> 404 Page Not Found: Termphp/index
ERROR - 2023-09-10 19:23:20 --> 404 Page Not Found: Textphp/index
ERROR - 2023-09-10 19:23:20 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-09-10 19:23:21 --> 404 Page Not Found: Toolsphp/index
ERROR - 2023-09-10 19:23:21 --> 404 Page Not Found: Tronphp/index
ERROR - 2023-09-10 19:23:21 --> 404 Page Not Found: Homephp/index
ERROR - 2023-09-10 19:23:22 --> 404 Page Not Found: Wp-includes/home.php
ERROR - 2023-09-10 19:23:22 --> 404 Page Not Found: Wp-content/home.php
ERROR - 2023-09-10 19:23:23 --> 404 Page Not Found: Wp-admin/home.php
ERROR - 2023-09-10 19:23:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:24 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:23:24 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-10 19:23:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:25 --> 404 Page Not Found: Wp-includes/random_compat
ERROR - 2023-09-10 19:23:25 --> 404 Page Not Found: R00Tphp/index
ERROR - 2023-09-10 19:23:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:26 --> 404 Page Not Found: Wsuphp/index
ERROR - 2023-09-10 19:23:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:29 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:29 --> 404 Page Not Found: Wp-admin/wso112233.php
ERROR - 2023-09-10 19:23:30 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-10 19:23:30 --> 404 Page Not Found: 406php/index
ERROR - 2023-09-10 19:23:30 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-10 19:23:31 --> 404 Page Not Found: Wp-includes/sodium_compat
ERROR - 2023-09-10 19:23:31 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-10 19:23:32 --> 404 Page Not Found: 0xphp/index
ERROR - 2023-09-10 19:23:32 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:23:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:34 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:35 --> 404 Page Not Found: D7php/index
ERROR - 2023-09-10 19:23:35 --> 404 Page Not Found: Rxrphp/index
ERROR - 2023-09-10 19:23:36 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-09-10 19:23:36 --> 404 Page Not Found: Wp-content/cong.php
ERROR - 2023-09-10 19:23:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:37 --> 404 Page Not Found: Eephp/index
ERROR - 2023-09-10 19:23:37 --> 404 Page Not Found: Wp-includes/wp-class.php
ERROR - 2023-09-10 19:23:38 --> 404 Page Not Found: Xxlphp/index
ERROR - 2023-09-10 19:23:38 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-09-10 19:23:39 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-09-10 19:23:39 --> 404 Page Not Found: Wp-admin/wp_filemanager.php
ERROR - 2023-09-10 19:23:40 --> 404 Page Not Found: Wp-includes/wp_filemanager.php
ERROR - 2023-09-10 19:23:40 --> 404 Page Not Found: Wp-content/wp_filemanager.php
ERROR - 2023-09-10 19:23:41 --> 404 Page Not Found: Wp_filemanagerphp/index
ERROR - 2023-09-10 19:23:41 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-09-10 19:23:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 19:23:42 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-09-10 19:23:42 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-09-10 19:23:43 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-09-10 19:23:43 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-10 19:23:44 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-09-10 19:23:44 --> 404 Page Not Found: Wp-admin/users.php
ERROR - 2023-09-10 19:23:45 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-09-10 20:09:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 20:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 20:28:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 23:18:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 23:18:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 23:19:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-09-10 23:41:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
