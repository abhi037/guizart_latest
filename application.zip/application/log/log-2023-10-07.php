<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-07 00:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 00:22:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 00:31:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 00:32:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 00:32:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 00:32:10 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2023-10-07 00:37:39 --> 404 Page Not Found: Assets/kcfinder
ERROR - 2023-10-07 00:54:28 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2023-10-07 00:54:29 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2023-10-07 00:54:29 --> 404 Page Not Found: New/wp-admin
ERROR - 2023-10-07 00:54:30 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2023-10-07 00:54:31 --> 404 Page Not Found: Test/wp-admin
ERROR - 2023-10-07 00:54:31 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2023-10-07 00:54:32 --> 404 Page Not Found: Cms/wp-admin
ERROR - 2023-10-07 00:54:32 --> 404 Page Not Found: Web/wp-admin
ERROR - 2023-10-07 00:54:33 --> 404 Page Not Found: Site/wp-admin
ERROR - 2023-10-07 00:54:34 --> 404 Page Not Found: Oldsite/wp-admin
ERROR - 2023-10-07 00:57:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 01:19:31 --> 404 Page Not Found: Env/index
ERROR - 2023-10-07 01:19:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 01:28:08 --> 404 Page Not Found: Env/index
ERROR - 2023-10-07 01:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 01:35:08 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 01:35:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 02:04:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 02:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:41:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 02:41:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:41:28 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-10-07 02:41:29 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-07 02:41:39 --> 404 Page Not Found: Log In/index
ERROR - 2023-10-07 02:41:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:41:42 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-10-07 02:41:44 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-10-07 02:41:45 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-07 02:42:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 02:42:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 02:42:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 02:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 02:45:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 03:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 03:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 03:45:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 03:46:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 03:49:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 03:49:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 03:50:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 03:50:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 03:52:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 03:54:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 03:54:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 03:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 03:54:57 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 03:54:57 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 03:55:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 03:55:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 04:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 04:24:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:07 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:09 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:14 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:15 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:20 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:21 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:23 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:24 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:27 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:29 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:30 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:32 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:34 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:37 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:38 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:40 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:41 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:43 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:45 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:24:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:24:59 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:01 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:25:05 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:25:06 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:25:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:10 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 04:25:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:15 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:20 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:22 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:24 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:25 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:30 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:37 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:25:39 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-07 04:45:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 04:46:28 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-07 04:46:28 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 04:50:13 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 04:50:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 05:04:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 05:04:23 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2023-10-07 05:04:23 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-10-07 05:04:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Website/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: News/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Media/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-10-07 05:04:24 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2023-10-07 05:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 05:45:41 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 05:45:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 06:02:43 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 06:02:43 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 06:19:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 06:19:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 06:19:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 06:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 06:54:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 07:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 07:52:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 07:52:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 07:57:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:12:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:12:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 08:26:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 08:26:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 08:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 08:50:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:50:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 08:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 08:51:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:53:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:54:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 08:55:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 08:55:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 08:58:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 09:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 09:51:04 --> Severity: Notice --> Undefined offset: 0 /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 1094
ERROR - 2023-10-07 09:51:04 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-10-07 10:24:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 11:08:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 11:08:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 11:09:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 11:24:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 11:24:37 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 11:24:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 13:27:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 13:27:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 13:28:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 13:28:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 13:28:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 13:29:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 13:33:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 13:33:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 14:27:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 14:27:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 14:28:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 14:28:03 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 14:28:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 14:30:12 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 14:30:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 14:33:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 14:33:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 14:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 14:35:25 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-07 15:23:10 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-10-07 15:48:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 15:48:50 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-07 15:48:51 --> 404 Page Not Found: Contacthtml/index
ERROR - 2023-10-07 16:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 16:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 17:14:20 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-07 17:14:22 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-07 17:14:24 --> 404 Page Not Found: Administrator/index.php
ERROR - 2023-10-07 17:23:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 17:23:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 17:23:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 17:25:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 17:27:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-07 17:37:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 17:37:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-07 17:51:13 --> 404 Page Not Found: Env/index
ERROR - 2023-10-07 19:13:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 19:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 19:22:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 19:22:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 19:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-07 19:24:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 19:26:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 19:26:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 19:34:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 19:34:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 19:46:27 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-07 19:46:28 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-07 19:52:50 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-07 20:07:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:28:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:28:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 20:31:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:31:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 20:35:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:49:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:49:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 20:49:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 20:49:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:50:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-07 20:50:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-07 21:32:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
