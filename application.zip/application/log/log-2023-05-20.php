<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-20 12:48:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 12:48:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:48:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:50:06 --> 404 Page Not Found: Log/index
ERROR - 2023-05-20 12:50:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-20 12:50:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:23 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-20 12:50:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:51:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:51:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:52:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:53:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:57:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 12:57:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:57:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:57:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:57:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:58:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 12:58:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:58:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:58:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:58:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 12:59:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 12:59:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 12:59:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:00:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 13:00:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:00:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:00:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:00:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:01:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 13:01:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:01:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:01:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 13:02:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 13:02:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:02:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 13:03:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-20 15:06:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 21:18:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-20 22:45:45 --> 404 Page Not Found: Robotstxt/index
