<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-13 02:23:00 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 04:07:10 --> 404 Page Not Found: Wp-content/ave.php
ERROR - 2023-08-13 05:27:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 05:27:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 06:40:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 06:40:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 07:05:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 07:05:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 07:08:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 08:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 08:05:13 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-13 08:44:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:19 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-13 08:44:19 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-08-13 08:44:20 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-08-13 08:44:20 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-08-13 08:44:22 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-13 08:44:22 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-08-13 08:44:23 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:23 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-13 08:44:23 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-08-13 08:44:24 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-13 08:44:24 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:24 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-08-13 08:44:25 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:25 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-08-13 08:44:26 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-08-13 08:44:26 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-13 08:44:26 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-13 08:44:27 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-08-13 08:44:27 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-13 08:44:27 --> 404 Page Not Found: Wp-includes/theme-compat
ERROR - 2023-08-13 08:44:28 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 08:44:29 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-13 08:44:29 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-08-13 08:44:30 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-08-13 08:44:30 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-08-13 08:44:30 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-13 08:44:31 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-08-13 08:44:31 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:31 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-13 08:44:32 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-08-13 08:44:32 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-13 08:44:33 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:33 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-08-13 08:44:33 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-13 08:44:34 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-08-13 08:44:34 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 08:44:34 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 08:44:35 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:35 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 08:44:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:36 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:37 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:37 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:37 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:38 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:38 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-08-13 08:44:38 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:39 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:39 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:40 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:40 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:40 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-08-13 08:44:41 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:41 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:42 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:42 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:42 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:43 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-08-13 08:44:45 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 08:44:46 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-08-13 08:44:46 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-13 08:44:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:48 --> 404 Page Not Found: Wp-content/gecko-new.php
ERROR - 2023-08-13 08:44:48 --> 404 Page Not Found: Wp-admin/raizoworm.php
ERROR - 2023-08-13 08:44:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-13 08:44:49 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-08-13 08:44:49 --> 404 Page Not Found: Libraries/legacy
ERROR - 2023-08-13 08:44:50 --> 404 Page Not Found: Libraries/phpmailer
ERROR - 2023-08-13 08:44:50 --> 404 Page Not Found: Libraries/vendor
ERROR - 2023-08-13 08:48:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 09:49:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 09:49:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 09:54:24 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 09:54:24 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 10:27:35 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 10:27:35 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 11:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 11:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 11:23:11 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-13 11:23:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 11:23:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:23:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 12:24:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:28:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 12:28:45 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:29:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:50:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 12:50:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:50:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 12:52:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 13:28:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 13:57:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 14:19:22 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-13 14:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 15:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 16:28:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 16:28:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 16:31:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 16:32:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 16:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 16:32:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 16:39:53 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 16:39:53 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 16:49:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 16:54:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 16:54:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 16:56:13 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-13 16:57:16 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 16:57:16 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-13 17:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 18:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 18:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:15:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:24:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 18:48:21 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2023-08-13 19:12:36 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-08-13 19:12:36 --> 404 Page Not Found: Feed/index
ERROR - 2023-08-13 19:12:37 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-13 19:12:37 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-08-13 19:12:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-08-13 19:12:38 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-08-13 19:12:38 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-08-13 19:12:38 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-08-13 19:12:38 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-08-13 19:12:39 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-08-13 19:12:39 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-08-13 19:12:39 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-08-13 19:12:40 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-08-13 19:12:40 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-08-13 19:12:40 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-08-13 19:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 21:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-13 21:46:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 21:46:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-13 23:14:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:14:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:21:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:21:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:22:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:23:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-13 23:24:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
