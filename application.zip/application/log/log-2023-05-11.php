<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-11 05:20:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 05:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-11 08:21:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 09:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-05-11 09:40:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 09:50:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 10:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 11:22:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 11:22:14 --> 404 Page Not Found: Admin/login.php
ERROR - 2023-05-11 11:22:21 --> 404 Page Not Found: Admin/login
ERROR - 2023-05-11 11:22:28 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-05-11 11:22:33 --> 404 Page Not Found: Admin/login
ERROR - 2023-05-11 14:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-11 15:19:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 15:31:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 15:56:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:32 --> 404 Page Not Found: Log/index
ERROR - 2023-05-11 15:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-11 15:56:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 15:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:42 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 15:56:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:56:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:16 --> Severity: Notice --> Undefined variable: i2 /home4/demouake/public_html/application/views/frontend/default/quiz.php 119
ERROR - 2023-05-11 15:57:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 15:57:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:41 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 15:57:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 16:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 16:03:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 16:03:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 16:03:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 16:03:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 16:48:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 17:38:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 17:38:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 17:38:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 17:38:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 21:44:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 21:44:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-05-11 21:44:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 23:20:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 23:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-05-11 23:22:12 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-05-11 23:22:12 --> 404 Page Not Found: Assets/frontend
