<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-03 00:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 00:07:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:32:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:32:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:32:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 00:32:44 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 00:32:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 00:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-03 00:35:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 00:35:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 00:35:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 00:50:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:51:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:51:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:53:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 00:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 01:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:03:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:04:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:11:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:12:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:44:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:44:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:44:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 01:45:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 02:18:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 02:43:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 03:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 03:38:08 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 04:47:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 05:10:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 06:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 06:14:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 06:14:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 06:15:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 06:15:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-03 06:28:10 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 06:28:10 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 06:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 07:45:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-03 08:03:26 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 08:03:26 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 08:35:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 09:09:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:09:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 09:09:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 09:42:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:42:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:43:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:52:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:52:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:52:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:52:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 09:53:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 09:54:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 09:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-03 10:49:22 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 10:49:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 11:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 11:18:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-10-03 12:06:21 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 12:06:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-10-03 12:08:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 12:08:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:08:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:30:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 12:30:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:30:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:30:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 12:30:40 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 12:32:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 12:33:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 12:34:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:10 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Cloudphp/index
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Cgi-bin/cloud.php
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Css/cloud.php
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Img/cloud.php
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Images/cloud.php
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:11 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-admin/cloud.php
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Alfa-rexphp/index
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-includes/theme-compat
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-03 12:34:12 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Xmrlpcphp/index
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Css/xmrlpc.php
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Img/xmrlpc.php
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Images/xmrlpc.php
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-10-03 12:34:13 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-admin/xmrlpc.php
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Wp/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:15 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Blog/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:16 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-content/updates.php
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-content/gecko-new.php
ERROR - 2023-10-03 12:34:17 --> 404 Page Not Found: Wp-admin/raizoworm.php
ERROR - 2023-10-03 12:34:18 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-10-03 12:34:18 --> 404 Page Not Found: Updatesphp/index
ERROR - 2023-10-03 12:34:18 --> 404 Page Not Found: Libraries/legacy
ERROR - 2023-10-03 12:34:18 --> 404 Page Not Found: Libraries/phpmailer
ERROR - 2023-10-03 12:34:18 --> 404 Page Not Found: Libraries/vendor
ERROR - 2023-10-03 13:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 13:12:23 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 13:56:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 14:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 14:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 14:32:13 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-10-03 14:50:03 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-10-03 15:07:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 15:07:11 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 15:07:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 15:07:18 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 15:07:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 15:20:29 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2023-10-03 15:21:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 15:21:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 15:22:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 15:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 15:38:11 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-10-03 16:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 17:00:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 17:41:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 18:08:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 18:51:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 18:51:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 18:53:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 19:15:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 19:16:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 19:24:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 19:32:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 19:32:04 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 19:32:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 19:32:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 20:16:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 20:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 20:24:12 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-10-03 21:12:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:12:13 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:12:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:14:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-03 21:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 21:32:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:52:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:52:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:52:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:52:47 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 21:52:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:52:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:52:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:56:10 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 21:56:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:56:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:56:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:56:40 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 21:57:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:57:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:57:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:57:38 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 21:57:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:57:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:57:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:58:35 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 21:58:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 21:58:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 21:58:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:00:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:00:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:00:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:00:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:00:39 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 22:00:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:00:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:01:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:01:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:17:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 22:44:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:44:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:44:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:44:33 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:44:44 --> 404 Page Not Found: Log/index
ERROR - 2023-10-03 22:49:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:49:04 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-10-03 22:56:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 22:56:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:56:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-10-03 22:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-03 23:08:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-10-03 23:47:24 --> 404 Page Not Found: Robotstxt/index
