<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-19 04:19:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 07:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-06-19 07:32:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 07:32:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 07:32:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 07:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 07:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 08:41:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 14:21:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 14:21:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 15:08:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:08:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:47 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:48 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:09:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:09:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 15:10:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:10:03 --> 404 Page Not Found: Log/index
ERROR - 2023-06-19 15:10:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 15:19:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 15:19:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 19:09:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 19:09:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 19:09:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-06-19 19:09:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 19:09:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 19:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 20:52:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 20:53:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 20:53:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 20:54:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 20:54:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-06-19 20:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-06-19 20:54:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home4/demouake/public_html/application/views/frontend/default/home.php 142
