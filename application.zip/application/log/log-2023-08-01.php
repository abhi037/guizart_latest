<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-01 00:29:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 00:30:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:13:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:13:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:37:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:53:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:53:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 01:53:14 --> 404 Page Not Found: Public/home
ERROR - 2023-08-01 01:53:15 --> 404 Page Not Found: Public/home
ERROR - 2023-08-01 01:53:19 --> 404 Page Not Found: Static/admin
ERROR - 2023-08-01 01:53:20 --> 404 Page Not Found: Static/admin
ERROR - 2023-08-01 02:28:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:33:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:33:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 02:33:52 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 02:34:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:34:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 02:35:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:35:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:35:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:36:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:36:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:37:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:38:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 02:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 02:43:20 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 03:00:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 03:00:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 03:00:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 03:03:04 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 03:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 03:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 03:32:21 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-08-01 03:32:31 --> 404 Page Not Found: Sitemap/index
ERROR - 2023-08-01 03:32:35 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-08-01 03:32:38 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2023-08-01 03:32:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 03:32:48 --> 404 Page Not Found: Log In/index
ERROR - 2023-08-01 03:35:56 --> Severity: Notice --> Undefined variable: order /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/razorpay.php 31
ERROR - 2023-08-01 03:40:57 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 03:44:19 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-08-01 03:44:20 --> 404 Page Not Found: Alfanewphp/index
ERROR - 2023-08-01 03:44:21 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 03:44:22 --> 404 Page Not Found: Wp-consarphp/index
ERROR - 2023-08-01 03:44:23 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-01 03:44:24 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 03:44:25 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-01 03:44:56 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 03:44:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 03:49:42 --> 404 Page Not Found: Home/Log In
ERROR - 2023-08-01 04:02:49 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 06:00:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 06:50:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 06:50:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 06:50:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 06:54:54 --> 404 Page Not Found: Alfa-rexphp7/index
ERROR - 2023-08-01 06:54:55 --> 404 Page Not Found: Alfanewphp/index
ERROR - 2023-08-01 06:54:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 06:54:58 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-01 06:54:59 --> 404 Page Not Found: Wp-pphp7/index
ERROR - 2023-08-01 06:55:00 --> 404 Page Not Found: Wp-admin/repeater.php
ERROR - 2023-08-01 06:55:02 --> 404 Page Not Found: Wp-includes/repeater.php
ERROR - 2023-08-01 06:55:03 --> 404 Page Not Found: Wp-content/repeater.php
ERROR - 2023-08-01 06:55:04 --> 404 Page Not Found: Wsoyanzphp/index
ERROR - 2023-08-01 06:55:05 --> 404 Page Not Found: Yanzphp/index
ERROR - 2023-08-01 06:55:06 --> 404 Page Not Found: Wp-admin/js
ERROR - 2023-08-01 06:55:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 06:55:09 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 06:55:11 --> 404 Page Not Found: Cache-compatphp/index
ERROR - 2023-08-01 06:55:12 --> 404 Page Not Found: Ajax-actionsphp/index
ERROR - 2023-08-01 06:55:13 --> 404 Page Not Found: Wp-admin/ajax-actions.php
ERROR - 2023-08-01 06:55:14 --> 404 Page Not Found: Wp-consarphp/index
ERROR - 2023-08-01 06:55:16 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-01 06:55:17 --> 404 Page Not Found: Admin-postphp/index
ERROR - 2023-08-01 06:55:18 --> 404 Page Not Found: Wp-admin/maint
ERROR - 2023-08-01 06:55:19 --> 404 Page Not Found: Wp-admin/dropdown.php
ERROR - 2023-08-01 06:55:20 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-01 06:55:22 --> 404 Page Not Found: Dropdownphp/index
ERROR - 2023-08-01 06:55:25 --> 404 Page Not Found: Aboutphp/index
ERROR - 2023-08-01 06:55:26 --> 404 Page Not Found: Adminphp/index
ERROR - 2023-08-01 06:55:27 --> 404 Page Not Found: Aboutphp7/index
ERROR - 2023-08-01 06:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 07:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 08:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 08:03:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-01 08:37:15 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 08:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 08:45:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 08:45:57 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 08:46:00 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 08:46:01 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-01 08:46:02 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-01 08:46:04 --> 404 Page Not Found: Repeaterphp/index
ERROR - 2023-08-01 08:46:06 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 08:46:07 --> 404 Page Not Found: Rindexphp/index
ERROR - 2023-08-01 08:50:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 08:56:56 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 09:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 09:39:20 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 09:39:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 09:48:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 10:01:22 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2023-08-01 10:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 12:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 13:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 13:47:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:04:56 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2023-08-01 14:04:57 --> 404 Page Not Found: Wp-includes/index
ERROR - 2023-08-01 14:04:59 --> 404 Page Not Found: Wp-includes/css
ERROR - 2023-08-01 14:05:01 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-08-01 14:05:04 --> 404 Page Not Found: Wp-includes/IXR
ERROR - 2023-08-01 14:05:06 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-01 14:05:08 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 14:05:10 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 14:05:11 --> 404 Page Not Found: Wp-content/mu-plugins
ERROR - 2023-08-01 14:05:14 --> 404 Page Not Found: Wp-includes/Text
ERROR - 2023-08-01 14:05:15 --> 404 Page Not Found: Wp-includes/blocks
ERROR - 2023-08-01 14:05:17 --> 404 Page Not Found: Wp-includes/certificates
ERROR - 2023-08-01 14:05:19 --> 404 Page Not Found: Wp-includes/customize
ERROR - 2023-08-01 14:05:21 --> 404 Page Not Found: Wp-includes/fonts
ERROR - 2023-08-01 14:05:23 --> 404 Page Not Found: Wp-includes/images
ERROR - 2023-08-01 14:05:26 --> 404 Page Not Found: Well-knownold/index
ERROR - 2023-08-01 14:05:30 --> 404 Page Not Found: Images/index
ERROR - 2023-08-01 14:05:34 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2023-08-01 14:05:35 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-08-01 14:05:37 --> 404 Page Not Found: Wp-includes/pomo
ERROR - 2023-08-01 14:05:39 --> 404 Page Not Found: Wp-includes/rest-api
ERROR - 2023-08-01 14:05:40 --> 404 Page Not Found: Wp-includes/widgets
ERROR - 2023-08-01 14:05:42 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-01 14:05:44 --> 404 Page Not Found: Wp-admin/images
ERROR - 2023-08-01 14:05:46 --> 404 Page Not Found: Wp-admin/meta
ERROR - 2023-08-01 14:05:48 --> 404 Page Not Found: Wp-admin/network
ERROR - 2023-08-01 14:05:50 --> 404 Page Not Found: Wp-admin/user
ERROR - 2023-08-01 14:05:52 --> 404 Page Not Found: Wp-content/index
ERROR - 2023-08-01 14:05:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-08-01 14:05:56 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 14:05:58 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2023-08-01 14:05:59 --> 404 Page Not Found: Wp-admin/index
ERROR - 2023-08-01 14:06:01 --> 404 Page Not Found: Wp-content/upgrade
ERROR - 2023-08-01 14:18:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:18:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:18:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 14:18:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 14:18:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 14:48:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 14:48:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 15:05:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 15:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 15:40:15 --> 404 Page Not Found: Home/Log In
ERROR - 2023-08-01 15:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 16:40:12 --> 404 Page Not Found: Classapiphp/index
ERROR - 2023-08-01 16:41:17 --> 404 Page Not Found: Wp-content/shell20211028.php
ERROR - 2023-08-01 16:41:40 --> 404 Page Not Found: Shell20211028php/index
ERROR - 2023-08-01 17:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 18:19:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-01 19:30:00 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 19:30:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 19:46:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 20:26:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 20:31:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 20:36:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 21:18:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 21:18:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 21:18:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 21:19:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 21:19:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-01 21:29:33 --> 404 Page Not Found: Adminerphp/index
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-01 22:28:25 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 22:28:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-01 22:31:04 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-08-01 22:31:10 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-08-01 22:31:16 --> 404 Page Not Found: Admin/index.php
ERROR - 2023-08-01 23:11:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 23:11:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-01 23:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-01 23:54:43 --> 404 Page Not Found: Wp-content/themes
ERROR - 2023-08-01 23:55:09 --> 404 Page Not Found: Wp-content/themes
