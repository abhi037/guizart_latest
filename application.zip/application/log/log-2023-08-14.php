<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-14 00:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 00:05:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 00:05:24 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 00:16:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-14 01:12:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 01:12:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 02:47:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 02:47:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 03:12:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 03:12:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 03:13:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 03:13:01 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 03:13:02 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 04:25:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 04:25:39 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 04:27:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 05:39:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 05:39:05 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 05:39:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 05:55:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 06:06:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:30:33 --> 404 Page Not Found: Wp-admin/x.php
ERROR - 2023-08-14 06:30:51 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-08-14 06:30:52 --> 404 Page Not Found: Uplphp/index
ERROR - 2023-08-14 06:55:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 06:55:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:55:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:55:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:56:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:59:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 06:59:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 07:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 08:05:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-08-14 08:43:36 --> 404 Page Not Found: Ckfinder/userfiles
ERROR - 2023-08-14 08:48:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 08:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 08:56:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 08:56:49 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 08:56:51 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 08:56:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 09:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 09:51:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 09:52:00 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 10:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 12:37:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 12:37:34 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 12:42:35 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 13:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 13:52:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 14:16:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 14:16:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 14:26:13 --> 404 Page Not Found: Filemanager/dialog.php
ERROR - 2023-08-14 14:26:13 --> 404 Page Not Found: Admin/filemanager
ERROR - 2023-08-14 14:26:13 --> 404 Page Not Found: Js/filemanager
ERROR - 2023-08-14 14:26:14 --> 404 Page Not Found: Assets/filemanager
ERROR - 2023-08-14 14:26:14 --> 404 Page Not Found: Plugin/filemanager
ERROR - 2023-08-14 14:44:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 14:47:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 15:09:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 15:24:02 --> 404 Page Not Found: Themesphp/index
ERROR - 2023-08-14 15:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 17:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 18:26:33 --> 404 Page Not Found: Wp-includes/ID3
ERROR - 2023-08-14 18:26:34 --> 404 Page Not Found: Feed/index
ERROR - 2023-08-14 18:26:34 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-14 18:26:35 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2023-08-14 18:26:36 --> 404 Page Not Found: Web/wp-includes
ERROR - 2023-08-14 18:26:37 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2023-08-14 18:26:37 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2023-08-14 18:26:38 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2023-08-14 18:26:39 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2023-08-14 18:26:40 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2023-08-14 18:26:41 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2023-08-14 18:26:42 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2023-08-14 18:26:42 --> 404 Page Not Found: Test/wp-includes
ERROR - 2023-08-14 18:26:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2023-08-14 18:26:44 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2023-08-14 18:40:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 18:40:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 19:03:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 19:03:20 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 20:04:40 --> 404 Page Not Found: Nf_trackingphp/index
ERROR - 2023-08-14 20:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 20:30:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 21:50:35 --> 404 Page Not Found: Wp-admin/css
ERROR - 2023-08-14 22:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 22:09:39 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-14 22:09:39 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-14 22:09:40 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 22:09:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 23:09:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 23:09:30 --> 404 Page Not Found: Assets/frontend
ERROR - 2023-08-14 23:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-08-14 23:16:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 23:16:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 23:17:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: sub_category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 230
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_details /home/u208937329/domains/quizart.co.in/public_html/application/controllers/Home.php 231
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 9
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 11
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 13
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 15
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 17
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 37
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: sub_category_name /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 41
ERROR - 2023-08-14 23:23:34 --> Severity: Notice --> Undefined variable: courses /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 23:23:34 --> Severity: error --> Exception: Call to a member function result_array() on null /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/category_page.php 137
ERROR - 2023-08-14 23:35:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
ERROR - 2023-08-14 23:35:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/u208937329/domains/quizart.co.in/public_html/application/views/frontend/default/home.php 142
