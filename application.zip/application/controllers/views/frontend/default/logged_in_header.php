<?php
    $user_details = $this->user_model->get_user($this->session->userdata('user_id'))->row_array();
?>

<section class="menu-area">
  <div class="">
    <div class="row">
      <div class="col">
        <nav class="navbar navbar-expand-lg navbar-light">
          
          <ul class="mobile-header-buttons">
            <li><a class="mobile-nav-trigger" href="#mobile-primary-nav">Menu<span></span></a></li>
            <li><a class="mobile-search-trigger" href="#mobile-search">Search<span></span></a></li>
          </ul>
          
          <a href="<?php echo site_url(''); ?>" class="navbar-brand" href="#">
            <img src="<?php echo base_url().'assets/frontend/img/logo.png'; ?>" alt="" height="50">
          </a>
          
          <?php include 'menu.php'; ?>
          
          
          <form class="inline-form" action="<?php echo site_url('home/get_courses_by_search_string'); ?>" method="post" style="width: 100%;">
            <div class="input-group search-box mobile-search">
              <input type="text" name = 'search_string' class="form-control" placeholder="<?php echo get_phrase('search_for_quiz'); ?>">
              <div class="input-group-append">
                <button class="btn" type="submit"><i class="fas fa-search"></i></button>
              </div>
            </div>
          </form>
          
          <?php /* if (get_settings('allow_instructor') == 1): ?>
            <div class="instructor-box menu-icon-box">
            <?php include 'instructor_items.php'; ?>
            </div>
          <?php endif; */ ?>
          
          <?php //if (get_settings('allow_instructor') == 1): ?>
          <div class="instructor-box menu-icon-box">
            <div class="icon">
              <a href="<?php echo site_url('home/my_exam'); ?>" style="border: 1px solid transparent; margin: 10px 10px; font-size: 14px; width: 100%; border-radius: 0; min-width: 100px;"><?php echo get_phrase("Today's Paper"); ?></a>
            </div>
          </div>
          <?php // endif; ?>
          <?php /* ?>
                        <div class="wishlist-box menu-icon-box" id = "wishlist_items">
            <?php include 'wishlist_items.php'; ?>
                        </div>
            
                        <div class="cart-box menu-icon-box" id = "cart_items">
            <?php include 'cart_items.php'; ?>
                        </div>
          <?php */ ?>
          
          <?php //include 'notifications.php'; ?>
          
          
          <div class="user-box menu-icon-box">
            <div class="icon">
              <a href="">
                <?php
                if (file_exists('uploads/user_image/'.$user_details['id'].'.jpg')): ?>
                <img src="<?php echo base_url().'uploads/user_image/'.$user_details['id'].'.jpg';?>" alt="" class="img-fluid">
                <?php else: ?>
                <img src="<?php echo base_url().'uploads/user_image/placeholder.png';?>" alt="" class="img-fluid">
                <?php endif; ?>
              </a>
            </div>
            <div class="dropdown user-dropdown corner-triangle top-right">
              <ul class="user-dropdown-menu">
                
                <li class="dropdown-user-info">
                  <a href="">
                    <div class="clearfix">
                      <div class="user-image float-left">
                        <?php if (file_exists('uploads/user_image/'.$user_details['id'].'.jpg')): ?>
                        <img src="<?php echo base_url().'uploads/user_image/'.$user_details['id'].'.jpg';?>" alt="" class="img-fluid">
                        <?php else: ?>
                        <img src="<?php echo base_url().'uploads/user_image/placeholder.png';?>" alt="" class="img-fluid">
                        <?php endif; ?>
                      </div>
                      <div class="user-details">
                        <div class="user-name">
                          <span class="hi"><?php echo get_phrase('hi'); ?>,</span>
                          <?php echo $user_details['first_name'].' '.$user_details['last_name']; ?>
                        </div>
                        <div class="user-email">
                          <span class="email"><?php echo $user_details['email']; ?></span>
                          <span class="welcome">Welcome back</span>
                        </div>
                      </div>
                    </div>
                  </a>
                </li>
                
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_enroll'); ?>"><i class="far fa-gem"></i><?php echo get_phrase('enrolled_quiz'); ?></a></li>
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/previousExams'); ?>"><i class="far fa-gem"></i><?php echo get_phrase('previous_quizs'); ?></a></li>
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_referral'); ?>"><i class="far fa-gem"></i><?php echo get_phrase('my_referral'); ?></a></li>
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_messages'); ?>"><i class="far fa-envelope"></i><?php echo get_phrase('my_messages'); ?></a></li>
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/purchase_history'); ?>"><i class="fas fa-shopping-cart"></i><?php echo get_phrase('purchase_history'); ?></a></li>
                <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/profile/user_profile'); ?>"><i class="fas fa-user"></i><?php echo get_phrase('user_profile'); ?></a></li>
                <li class="dropdown-user-logout user-dropdown-menu-item"><a href="<?php echo site_url('login/logout/user'); ?>"><?php echo get_phrase('log_out'); ?></a></li>
              </ul>
            </div>
          </div>
          
          
          
          <span class="signin-box-move-desktop-helper"></span>
          <div class="sign-in-box btn-group d-none">
            
            <button type="button" class="btn btn-sign-in" data-toggle="modal" data-target="#signInModal">Log In</button>
            
            <button type="button" class="btn btn-sign-up" data-toggle="modal" data-target="#signUpModal">Sign Up</button>
            
          </div> <!--  sign-in-box end -->
          
          
        </nav>
        <!-- <nav class="navbar-expand-md navbar-dark custom-menu">
          
          <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item <?php echo is_active('/'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('/'); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item <?php echo is_active('about_us'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/pages/about_us'); ?>">About Us</a>
              </li>
              <li class="nav-item <?php echo is_active('our_team'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/pages/our_team'); ?>">Our team</a>
              </li>
              <li class="nav-item <?php echo is_active('achievements'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/pages/achievements'); ?>">Achievements</a>
              </li>
              <li class="nav-item <?php echo is_active('news_&_events'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/pages/news_&_events'); ?>">News and events</a>
              </li>
              <li class="nav-item <?php echo is_active('photogallery'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/photogallery'); ?>">Photo gallery</a>
              </li>
              <li class="nav-item <?php echo is_active('faqs'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/faqs'); ?>">FAQs</a>
              </li>
              <li class="nav-item <?php echo is_active('contact_us'); ?>">
                <a class="nav-link custom-link" href="<?php echo site_url('home/pages/contact_us'); ?>">Contact Us</a>
              </li>
            </ul>
          </div>
        </nav> -->
      </div>
    </div>
  </div>
</section>
