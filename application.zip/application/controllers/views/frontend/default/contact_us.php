<section class="page-header-area">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="page-title"><?php echo get_phrase('contact_us'); ?></h1>
            </div>
        </div>
    </div>
</section>

<section class="my-courses-area">
    <div class="container">
        <?php echo html_entity_decode(urldecode($data['content'])); ?>
    </div>
</section>


