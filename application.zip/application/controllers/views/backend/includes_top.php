<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-icons/entypo/css/entypo.css'); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/bootstrap.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-core.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-theme.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-forms.css'); ?>">

<script src="<?php echo base_url('assets/backend/js/jquery-1.11.0.min.js'); ?>"></script> 
 <!--<script src="<?php echo base_url('assets/backend/js/jquery-3.3.1.min.js'); ?>"></script> -->

<!--<script-->
<!--  src="https://code.jquery.com/jquery-3.4.1.min.js"-->
<!--  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="-->
<!--  crossorigin="anonymous"></script>-->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/backend/css/datatables.min.css'); ?>"/>


<!--<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/datatables/responsive/css/datatables.responsive.css'); ?>">-->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/select2/select2-bootstrap.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/select2/select2.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/selectboxit/jquery.selectBoxIt.css');?>">

<!-- font awesome 5 -->
<link rel="stylesheet" href="<?php echo base_url().'assets/frontend/css/fontawesome-all.min.css'; ?>">
<!-- font awesome 4 -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-icons/font-awesome-new/css/font-awesome.min.css');?>">

<!-- <link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-icons/simple-line-icon/css/simple-line-icons.css');?>"> -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/wysihtml5/bootstrap-wysihtml5.css');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/daterangepicker/daterangepicker-bs3.css');?>">
<!-- <link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-awesome-icon-picker/fontawesome-iconpicker.min.css');?>"> -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-awesome-icon-picker/fontawesome-four-iconpicker.min.css');?>">
<!-- <link href="https://use.fontawesome.com/releases/v5.0.8/css/all.css" rel="stylesheet"> -->
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/custom.css'); ?>">


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-175809190-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-175809190-1');
</script>